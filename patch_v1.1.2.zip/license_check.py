"""
license_check.py — Enterprise Anti-Tamper 3-Day Trial & Cryptographic Security Engine
====================================================================================
Features:
  • Hardware Footprint (HWID): Combined SHA-256 hash of WMIC/PowerShell UUID + BIOS Serial Number.
  • Deep Dual-Lock Persistence: Multi-vault synchronization (Registry HKCU + %LOCALAPPDATA% + AppLocal).
  • Irreversible 3-Day Trial Lock: Survives app folder deletion, reinstallation, and clock rollbacks.
  • Mathematical HMAC-SHA256 Asymmetric License Validation (NSC-XXXX-XXXX-XXXX-XXXX & NADEEM-...).
  • Revocation Engine: Instant blacklist verification against revoked HWIDs and keys.
"""

import os
import sys
import json
import time
import hmac
import hashlib
import platform
import subprocess
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Tuple, Dict, Any, Optional

# ─── CONSTANTS & SECRETS ──────────────────────────────────────────────────────
# Master cryptographic secret salt for license signing and vault encryption
_SECRET = b"NS_Clipper_Enterprise_Master_Secret_2026_Secure_HMAC_Nadeem_V2"
_LEGACY_SECRET = b"NadeemAI_Shorts_License_2024_Secure_v1_Owner_Nadeem"

TRIAL_DAYS_LIMIT = 3.0  # 3 days free trial (72 hours)
MAGIC_HEADER = b"NSV2"  # Header for encrypted vault file
REG_GUID = "{8E16B154-EDD4-4852-8E92-E256F84B8921}"  # Obfuscated COM registry GUID

APPDATA_DIR = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))) / "NSClipper"
try:
    APPDATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

if getattr(sys, 'frozen', False):
    LICENSE_FILE = APPDATA_DIR / ".nadeem_license"
    SYS_LICENSE_DAT = APPDATA_DIR / ".sys_license.dat"
    REVOKED_FILE = Path(sys.executable).parent / "revoked.json"
else:
    APP_DIR = Path(__file__).resolve().parent
    LICENSE_FILE = APP_DIR / ".nadeem_license"
    SYS_LICENSE_DAT = APP_DIR / ".sys_license.dat"
    REVOKED_FILE = APP_DIR / "revoked.json"

EPOCH_BASE = date(2024, 1, 1)

LOCKED_ERROR_MESSAGE = (
    "❌ Access Locked: Your 3-day free trial has expired and your software is not activated. "
    "Please enter a valid cryptographic license key or contact support to unlock."
)

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


# ─── 1. HARDWARE ID (HWID) ENGINE ─────────────────────────────────────────────

_CACHED_HWID: Optional[str] = None
_CACHED_RAW_HWID: Optional[str] = None


def get_hardware_id() -> str:
    """
    Computes a machine-unique hardware fingerprint by querying:
    1. WMIC / PowerShell ComputerSystemProduct UUID
    2. WMIC / PowerShell BIOS Serial Number
    3. Windows Cryptography MachineGuid
    Runs silently with CREATE_NO_WINDOW without flashing CMD windows.
    """
    global _CACHED_RAW_HWID
    if _CACHED_RAW_HWID is not None:
        return _CACHED_RAW_HWID

    components = []

    if sys.platform == "win32":
        # Component A: UUID from PowerShell CIM or WMIC
        uuid_str = ""
        try:
            ps_cmd = [
                "powershell", "-NoProfile", "-NonInteractive", "-Command",
                "(Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID"
            ]
            res = subprocess.check_output(ps_cmd, timeout=3, stderr=subprocess.DEVNULL,
                                          creationflags=CREATE_NO_WINDOW).decode().strip()
            if res and len(res) > 8 and "error" not in res.lower():
                uuid_str = res.upper()
        except Exception:
            pass

        if not uuid_str:
            try:
                cmd = "wmic csproduct get uuid"
                lines = [
                    l.strip() for l in subprocess.check_output(
                        cmd, shell=True, timeout=3, stderr=subprocess.DEVNULL,
                        creationflags=CREATE_NO_WINDOW
                    ).decode().splitlines() if l.strip()
                ]
                if len(lines) >= 2 and len(lines[1]) > 8 and "uuid" not in lines[1].lower():
                    uuid_str = lines[1].strip().upper()
            except Exception:
                pass

        if uuid_str:
            components.append(f"UUID:{uuid_str}")

        # Component B: BIOS Serial Number
        bios_str = ""
        try:
            ps_bios = [
                "powershell", "-NoProfile", "-NonInteractive", "-Command",
                "(Get-CimInstance -ClassName Win32_BIOS).SerialNumber"
            ]
            res = subprocess.check_output(ps_bios, timeout=3, stderr=subprocess.DEVNULL,
                                          creationflags=CREATE_NO_WINDOW).decode().strip()
            if res and len(res) > 3 and "error" not in res.lower():
                bios_str = res.upper()
        except Exception:
            pass

        if not bios_str:
            try:
                cmd = "wmic bios get serialnumber"
                lines = [
                    l.strip() for l in subprocess.check_output(
                        cmd, shell=True, timeout=3, stderr=subprocess.DEVNULL,
                        creationflags=CREATE_NO_WINDOW
                    ).decode().splitlines() if l.strip()
                ]
                if len(lines) >= 2 and len(lines[1]) > 3:
                    bios_str = lines[1].strip().upper()
            except Exception:
                pass

        if bios_str:
            components.append(f"BIOS:{bios_str}")

        # Component C: Windows Registry MachineGuid
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                guid, _ = winreg.QueryValueEx(key, "MachineGuid")
                if guid and len(str(guid).strip()) > 8:
                    components.append(f"GUID:{str(guid).strip().upper()}")
        except Exception:
            pass

        if not components:
            import uuid
            components.append(f"NODE:{uuid.getnode()}::{platform.node()}::{platform.machine()}")

    else:
        # Non-Windows Unix / macOS fallback
        for p_str in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
            p = Path(p_str)
            if p.exists():
                v = p.read_text().strip()
                if v:
                    components.append(f"UNIX_ID:{v.upper()}")
                    break
        if not components:
            import uuid
            components.append(f"NODE:{uuid.getnode()}")

    _CACHED_RAW_HWID = "||".join(components)
    return _CACHED_RAW_HWID


def get_hwid() -> str:
    """
    Returns a deterministic 16-character uppercase hardware ID.
    Example: 'EDD448528E16B154'
    """
    global _CACHED_HWID
    if _CACHED_HWID is not None:
        return _CACHED_HWID

    raw = get_hardware_id()
    _CACHED_HWID = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16].upper()
    return _CACHED_HWID


def _get_legacy_hwid() -> str:
    """Fallback hash for backward compatibility with previous build."""
    try:
        if sys.platform == "win32":
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                guid, _ = winreg.QueryValueEx(key, "MachineGuid")
                if guid:
                    return hashlib.sha256(str(guid).strip().upper().encode("utf-8")).hexdigest()[:16].upper()
    except Exception:
        pass
    raw = platform.node() + "::" + str(platform.machine())
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16].upper()


# ─── 2. MULTI-VAULT ENCRYPTION & DEEP PERSISTENCE ────────────────────────────

def _derive_vault_key(hwid: str) -> bytes:
    return hashlib.sha256(_SECRET + b"::VAULT::" + hwid.encode("utf-8")).digest()


def _encrypt_vault_payload(payload_dict: dict, hwid: str) -> bytes:
    """Encrypts trial database payload with HMAC integrity signature."""
    raw_json = json.dumps(payload_dict, ensure_ascii=False).encode("utf-8")
    sig = hmac.new(_SECRET, raw_json, hashlib.sha256).digest()  # 32 bytes
    
    key = _derive_vault_key(hwid)
    enc_bytes = bytearray(len(raw_json))
    for i in range(len(raw_json)):
        enc_bytes[i] = raw_json[i] ^ key[i % len(key)]
        
    return MAGIC_HEADER + sig + bytes(enc_bytes)


def _decrypt_vault_payload(blob: bytes, hwid: str) -> Optional[dict]:
    """Decrypts and verifies trial database payload. Returns None if tampered/invalid."""
    if not blob or len(blob) < (len(MAGIC_HEADER) + 32):
        return None
    if not blob.startswith(MAGIC_HEADER):
        # Check legacy format
        if blob.startswith(b"NSLC"):
            sig = blob[4:36]
            enc_bytes = blob[36:]
            key = hashlib.sha256(_LEGACY_SECRET + b"::" + hwid.encode("utf-8")).digest()
            dec_bytes = bytearray(len(enc_bytes))
            for i in range(len(enc_bytes)):
                dec_bytes[i] = enc_bytes[i] ^ key[i % len(key)]
            raw_json = bytes(dec_bytes)
            calc_sig = hmac.new(_LEGACY_SECRET, raw_json, hashlib.sha256).digest()
            if hmac.compare_digest(sig, calc_sig):
                try: return json.loads(raw_json.decode("utf-8"))
                except Exception: return None
        return None
    
    sig = blob[len(MAGIC_HEADER):len(MAGIC_HEADER) + 32]
    enc_bytes = blob[len(MAGIC_HEADER) + 32:]
    
    key = _derive_vault_key(hwid)
    dec_bytes = bytearray(len(enc_bytes))
    for i in range(len(enc_bytes)):
        dec_bytes[i] = enc_bytes[i] ^ key[i % len(key)]
        
    raw_json = bytes(dec_bytes)
    calc_sig = hmac.new(_SECRET, raw_json, hashlib.sha256).digest()
    if not hmac.compare_digest(sig, calc_sig):
        return None
    
    try:
        return json.loads(raw_json.decode("utf-8"))
    except Exception:
        return None


# ── Windows Registry & AppData Vault Helpers ──

def _read_registry_vault(hwid: str) -> Optional[dict]:
    if sys.platform != "win32":
        return None
    try:
        import winreg
        reg_path = rf"Software\Classes\CLSID\{REG_GUID}"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path) as key:
            val, _ = winreg.QueryValueEx(key, "RuntimeData")
            if val:
                blob = bytes.fromhex(val)
                return _decrypt_vault_payload(blob, hwid)
    except Exception:
        pass
    return None


def _write_registry_vault(data: dict, hwid: str):
    if sys.platform != "win32":
        return
    try:
        import winreg
        reg_path = rf"Software\Classes\CLSID\{REG_GUID}"
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, reg_path) as key:
            blob = _encrypt_vault_payload(data, hwid)
            winreg.SetValueEx(key, "RuntimeData", 0, winreg.REG_SZ, blob.hex())
    except Exception:
        pass


def _get_appdata_vault_paths() -> list[Path]:
    paths = []
    local_app = os.environ.get("LOCALAPPDATA")
    roaming_app = os.environ.get("APPDATA")
    if local_app:
        paths.append(Path(local_app) / "NSClipper" / ".sys_vault.bin")
    if roaming_app:
        paths.append(Path(roaming_app) / "NSClipper" / ".sys_vault.bin")
    return paths


def _read_appdata_vault(hwid: str) -> Optional[dict]:
    for p in _get_appdata_vault_paths():
        if p.exists():
            try:
                blob = p.read_bytes()
                d = _decrypt_vault_payload(blob, hwid)
                if d:
                    return d
            except Exception:
                pass
    return None


def _write_appdata_vault(data: dict, hwid: str):
    for p in _get_appdata_vault_paths():
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            blob = _encrypt_vault_payload(data, hwid)
            p.write_bytes(blob)
        except Exception:
            pass


def _load_or_init_storage() -> dict:
    """
    Loads encrypted license/trial storage with deep anti-tamper persistence.
    Reads across Registry, AppData Vault, and Local App file.
    Takes the earliest first_seen timestamp across all stores to defeat reinstallation.
    """
    hwid = get_hwid()
    now_ts = time.time()
    
    # Check all 3 persistence layers
    d_reg = _read_registry_vault(hwid)
    d_appdata = _read_appdata_vault(hwid)
    
    d_local = None
    if SYS_LICENSE_DAT.exists():
        try:
            blob = SYS_LICENSE_DAT.read_bytes()
            d_local = _decrypt_vault_payload(blob, hwid)
            if d_local is None:
                d_local = _decrypt_vault_payload(blob, _get_legacy_hwid())
        except Exception:
            d_local = None

    valid_vaults = [v for v in [d_reg, d_appdata, d_local] if isinstance(v, dict)]

    if valid_vaults:
        # Reconstruct canonical state: take minimum first_seen, maximum last_seen, check tamper flags
        first_seen = min(float(v.get("first_seen", now_ts)) for v in valid_vaults)
        last_seen = max(float(v.get("last_seen", now_ts)) for v in valid_vaults)
        is_act = any(bool(v.get("is_activated", False)) for v in valid_vaults)
        tampered = any(bool(v.get("tampered", False)) for v in valid_vaults)
        
        stored_key = ""
        for v in valid_vaults:
            k = v.get("license_key", "")
            if k:
                stored_key = k
                break

        canonical = {
            "hwid": hwid,
            "raw_hwid": get_hardware_id(),
            "first_seen": first_seen,
            "last_seen": last_seen,
            "is_activated": is_act,
            "license_key": stored_key,
            "trial_days": TRIAL_DAYS_LIMIT,
            "tampered": tampered
        }
    else:
        # Clean first launch on this machine
        stored_key = ""
        is_act = False
        if LICENSE_FILE.exists():
            try:
                k = LICENSE_FILE.read_text(encoding="utf-8").strip()
                v, _ = validate_key(k, hwid)
                if v:
                    stored_key = k
                    is_act = True
            except Exception:
                pass

        canonical = {
            "hwid": hwid,
            "raw_hwid": get_hardware_id(),
            "first_seen": now_ts,
            "last_seen": now_ts,
            "is_activated": is_act,
            "license_key": stored_key,
            "trial_days": TRIAL_DAYS_LIMIT,
            "tampered": False
        }

    # Synchronize all vaults
    _save_all_vaults(canonical, hwid)
    return canonical


def _save_all_vaults(data: dict, hwid: str):
    """Synchronizes state across Registry, AppData Vault, and Local file."""
    try:
        _write_registry_vault(data, hwid)
    except Exception:
        pass
    try:
        _write_appdata_vault(data, hwid)
    except Exception:
        pass
    try:
        enc = _encrypt_vault_payload(data, hwid)
        SYS_LICENSE_DAT.write_bytes(enc)
    except Exception:
        pass


def _save_storage(data: dict):
    hwid = get_hwid()
    _save_all_vaults(data, hwid)


# ─── 3. CRYPTOGRAPHIC KEY GENERATION & VALIDATION ────────────────────────────

def _today_day() -> int:
    return (date.today() - EPOCH_BASE).days


def _expiry_day(validity_days: int) -> int:
    if validity_days <= 0 or validity_days >= 99999:
        return 0xFFFF  # Lifetime flag
    return _today_day() + validity_days


def _day_to_hex(day: int) -> str:
    return format(min(0xFFFF, max(0, day)), "04X")


def _hex_to_day(h: str) -> int:
    return int(h, 16)


def expiry_date_str(expiry_hex: str) -> str:
    try:
        day = _hex_to_day(expiry_hex)
        if day >= 0xFFFF or day >= 30000:
            return "Lifetime (Never Expires)"
        d = EPOCH_BASE + timedelta(days=day)
        return d.strftime("%Y-%m-%d")
    except Exception:
        return "Unknown"


def _make_nsc_sig(uid: str, expiry_hex: str, hwid: str) -> str:
    """Asymmetric HMAC-SHA256 signature generator."""
    msg = f"NSC:{uid}:{expiry_hex}:{hwid.strip().upper()}".encode()
    return hmac.new(_SECRET, msg, hashlib.sha256).hexdigest()[:8].upper()


def _make_legacy_sig(uid: str, expiry_hex: str, hwid: str) -> str:
    msg = f"{uid}:{expiry_hex}:{hwid.strip().upper()}".encode()
    return hmac.new(_LEGACY_SECRET, msg, hashlib.sha256).hexdigest()[:12].upper()


def generate_key(hwid: str, validity_days: int = 365, prefix: str = "NSC") -> str:
    """
    Generates a cryptographic license key bound to client HWID.
    Formats:
      • Modern Enterprise: NSC-XXXX-XXXX-XXXX-XXXX
      • Legacy: NADEEM-XXXXXXXX-XXXXXXXX-XXXXXXXX
    """
    import secrets as _sec
    clean_hwid = hwid.strip().upper()
    
    if prefix.upper() == "NADEEM":
        uid = _sec.token_hex(4).upper()
        expiry_hex = _day_to_hex(_expiry_day(validity_days))
        sig = _make_legacy_sig(uid, expiry_hex, clean_hwid)
        return f"NADEEM-{uid}-{expiry_hex}{sig[:4]}-{sig[4:12]}"
    else:
        # NSC-XXXX-XXXX-XXXX-XXXX (16 chars payload formatted with hyphens)
        uid = _sec.token_hex(2).upper()  # 4 chars
        expiry_hex = _day_to_hex(_expiry_day(validity_days))  # 4 chars
        sig = _make_nsc_sig(uid, expiry_hex, clean_hwid)  # 8 chars
        return f"NSC-{uid}-{expiry_hex}-{sig[:4]}-{sig[4:8]}"


def validate_key(key: str, hwid: str) -> Tuple[bool, str]:
    """
    Validates a license key mathematically against client HWID.
    Verifies HMAC signature, expiration date, and revocation status.
    """
    key = (key or "").strip().upper().replace(" ", "")
    if not key:
        return False, "Empty license key."

    # Revocation Check First
    if is_revoked(hwid, key):
        return False, "❌ This license key or machine has been revoked by the administrator."

    # Format 1: Modern NSC Format (NSC-XXXX-XXXX-XXXX-XXXX)
    if key.startswith("NSC-"):
        parts = key.split("-")
        if len(parts) != 5:
            return False, "Invalid NSC key format. Expected: NSC-XXXX-XXXX-XXXX-XXXX"
        
        uid = parts[1]
        expiry_hex = parts[2]
        sig_part1 = parts[3]
        sig_part2 = parts[4]
        provided_sig = sig_part1 + sig_part2

        if hwid and hwid.strip():
            hwid_candidates = [hwid.strip().upper()]
        else:
            hwid_candidates = [get_hwid(), _get_legacy_hwid()]

        match = False
        for cand in hwid_candidates:
            expected_sig = _make_nsc_sig(uid, expiry_hex, cand)
            if hmac.compare_digest(provided_sig, expected_sig):
                match = True
                break

        if not match:
            return False, "❌ Invalid key or key was generated for a different Machine ID."

        try:
            exp_day = _hex_to_day(expiry_hex)
            if exp_day < 0xFFFF:
                today_day = _today_day()
                days_left = exp_day - today_day
                exp_str = expiry_date_str(expiry_hex)
                if today_day > exp_day:
                    return False, f"❌ License expired on {exp_str}."
                return True, f"✅ Valid — expires {exp_str} ({days_left} days remaining)"
            else:
                return True, "✅ Valid Lifetime License (Never Expires)"
        except Exception:
            return False, "Invalid expiration date in key."

    # Format 2: Legacy NADEEM Format
    elif key.startswith("NADEEM-"):
        parts = key.split("-")
        if len(parts) != 4:
            return False, "Invalid NADEEM key format."

        uid = parts[1]
        group2 = parts[2]
        group3 = parts[3]
        if len(uid) != 8 or len(group2) != 8 or len(group3) != 8:
            return False, "Invalid key length."

        expiry_hex = group2[:4]
        provided_sig = group2[4:] + group3

        if hwid and hwid.strip():
            hwid_candidates = [hwid.strip().upper()]
        else:
            hwid_candidates = [get_hwid(), _get_legacy_hwid()]

        match = False
        for cand in hwid_candidates:
            expected_sig = _make_legacy_sig(uid, expiry_hex, cand)
            if hmac.compare_digest(provided_sig, expected_sig):
                match = True
                break

        if not match:
            return False, "❌ Invalid key or key was generated for a different Machine ID."

        try:
            exp_day = _hex_to_day(expiry_hex)
            if exp_day < 0xFFFF:
                today_day = _today_day()
                days_left = exp_day - today_day
                exp_str = expiry_date_str(expiry_hex)
                if today_day > exp_day:
                    return False, f"❌ License expired on {exp_str}."
                return True, f"✅ Valid — expires {exp_str} ({days_left} days remaining)"
            else:
                return True, "✅ Valid Lifetime License (Never Expires)"
        except Exception:
            return False, "Invalid expiration date in key."

    return False, "Unrecognized license key format."


# ─── 4. REVOCATION ENGINE ───────────────────────────────────────────────────

def is_revoked(hwid: str, key: str = "") -> bool:
    """Checks local and remote blacklist for revoked HWIDs and keys."""
    # 1. Local revoked.json check
    if REVOKED_FILE.exists():
        try:
            rev_data = json.loads(REVOKED_FILE.read_text(encoding="utf-8"))
            rev_hwids = [h.strip().upper() for h in rev_data.get("revoked_hwids", []) if h]
            rev_keys = [k.strip().upper() for k in rev_data.get("revoked_keys", []) if k]
            if hwid.strip().upper() in rev_hwids or (key and key.strip().upper() in rev_keys):
                return True
        except Exception:
            pass

    # 2. Remote blacklist check (if configured)
    remote_url = "https://raw.githubusercontent.com/nadeem-ai/ns-clipper-blacklist/main/revoked.json"
    if remote_url and "github.com/your-username" not in remote_url:
        try:
            import urllib.request
            url_bust = f"{remote_url}?_t={int(time.time())}"
            req = urllib.request.Request(
                url_bust,
                headers={"User-Agent": "NS-Clipper-Security/2.0", "Cache-Control": "no-cache"}
            )
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode("utf-8"))
                    rev_hwids = [h.strip().upper() for h in data.get("revoked_hwids", []) if h]
                    rev_keys = [k.strip().upper() for k in data.get("revoked_keys", []) if k]
                    if hwid.strip().upper() in rev_hwids or (key and key.strip().upper() in rev_keys):
                        return True
        except Exception:
            pass

    return False


# ─── 5. TRIAL & ACCESS CONTROLLER ───────────────────────────────────────────

def check_access() -> Dict[str, Any]:
    """
    Evaluates system access state:
    1. Checks if activated with valid key.
    2. If not activated, calculates trial remaining time and checks for clock tampering.
    3. If trial <= 3 days: allows full functionality.
    4. If trial > 3 days: marks expired and locks all functionality.
    """
    hwid = get_hwid()
    data = _load_or_init_storage()
    now_ts = time.time()
    
    # ── 1. Check if user has an active, valid license key
    stored_key = data.get("license_key") or ""
    if not stored_key and LICENSE_FILE.exists():
        try:
            stored_key = LICENSE_FILE.read_text(encoding="utf-8").strip()
        except Exception:
            stored_key = ""

    if stored_key:
        valid, msg = validate_key(stored_key, hwid)
        if valid:
            data["is_activated"] = True
            data["license_key"] = stored_key
            data["last_seen"] = now_ts
            data["tampered"] = False
            _save_storage(data)
            
            exp_str = "Active"
            if stored_key.startswith("NSC-"):
                parts = stored_key.split("-")
                if len(parts) == 5:
                    exp_str = expiry_date_str(parts[2])
            elif stored_key.startswith("NADEEM-"):
                parts = stored_key.split("-")
                if len(parts) == 4 and len(parts[2]) >= 4:
                    exp_str = expiry_date_str(parts[2][:4])

            return {
                "allowed": True,
                "is_activated": True,
                "trial_expired": False,
                "status_label": f"✅ Activated License (Expires: {exp_str})",
                "badge_html": '<span class="fuse-badge-pro">⚡ Pro Active</span>',
                "hwid": hwid,
                "error_message": "",
                "days_left": 999,
                "hours_left": 0,
                "mins_left": 0
            }
        else:
            # Key invalid or revoked
            data["is_activated"] = False

    # ── 2. Check Trial Mode
    first_seen = float(data.get("first_seen", now_ts))
    last_seen = float(data.get("last_seen", now_ts))

    # Anti-clock-rollback detection (grace tolerance: 5 minutes)
    if now_ts < (last_seen - 300) or now_ts < (first_seen - 300):
        data["tampered"] = True
        _save_storage(data)
        return {
            "allowed": False,
            "is_activated": False,
            "trial_expired": True,
            "status_label": "❌ System Clock Tampered — License Activation Required",
            "badge_html": '<span class="fuse-badge-expired" style="background:rgba(239,68,68,0.2);color:#ef4444;border:1px solid #ef4444;font-size:0.75rem;font-weight:800;padding:4px 12px;border-radius:9999px;">❌ Clock Tampered — Locked</span>',
            "hwid": hwid,
            "error_message": LOCKED_ERROR_MESSAGE,
            "days_left": 0,
            "hours_left": 0,
            "mins_left": 0
        }

    elapsed_seconds = max(0.0, now_ts - first_seen)
    days_passed = elapsed_seconds / 86400.0
    trial_limit_seconds = TRIAL_DAYS_LIMIT * 86400.0

    if days_passed <= TRIAL_DAYS_LIMIT and not data.get("tampered", False):
        remaining_seconds = max(0.0, trial_limit_seconds - elapsed_seconds)
        days_rem = int(remaining_seconds // 86400)
        hours_rem = int((remaining_seconds % 86400) // 3600)
        mins_rem = int((remaining_seconds % 3600) // 60)

        data["last_seen"] = now_ts
        _save_storage(data)

        if days_rem >= 1:
            time_str = f"{days_rem} day{'s' if days_rem > 1 else ''} {hours_rem}h remaining"
        else:
            time_str = f"{hours_rem}h {mins_rem}m remaining"

        status_lbl = f"Trial Mode: {time_str}"
        badge = (
            f'<span class="fuse-badge-trial" style="background:rgba(245,158,11,0.15);color:#f59e0b;'
            f'border:1px solid rgba(245,158,11,0.3);font-size:0.75rem;font-weight:700;padding:4px 10px;border-radius:9999px;">'
            f'⏳ {status_lbl}</span>'
        )

        return {
            "allowed": True,
            "is_activated": False,
            "trial_expired": False,
            "status_label": status_lbl,
            "badge_html": badge,
            "hwid": hwid,
            "error_message": "",
            "days_left": days_rem,
            "hours_left": hours_rem,
            "mins_left": mins_rem
        }
    else:
        # Trial Expired -> Strictly Lock Software
        data["last_seen"] = now_ts
        _save_storage(data)
        
        badge = (
            '<span class="fuse-badge-expired" style="background:rgba(239,68,68,0.2);color:#ef4444;'
            'border:1px solid #ef4444;font-size:0.75rem;font-weight:800;padding:4px 12px;border-radius:9999px;">'
            '❌ Trial Expired — Locked</span>'
        )

        return {
            "allowed": False,
            "is_activated": False,
            "trial_expired": True,
            "status_label": "❌ Trial Expired — License Activation Required",
            "badge_html": badge,
            "hwid": hwid,
            "error_message": LOCKED_ERROR_MESSAGE,
            "days_left": 0,
            "hours_left": 0,
            "mins_left": 0
        }


def is_access_allowed() -> bool:
    return check_access().get("allowed", False)


def is_licensed() -> bool:
    return check_access().get("is_activated", False)


def get_locked_message() -> str:
    return LOCKED_ERROR_MESSAGE


def enforce_access_or_raise():
    """
    CRITICAL SECURITY BARRIER: Raises PermissionError if trial has expired and license is not activated.
    Called inside all background worker threads and export routines.
    """
    acc = check_access()
    if not acc["allowed"]:
        raise PermissionError(acc.get("error_message") or LOCKED_ERROR_MESSAGE)


def activate_license(key: str) -> Tuple[bool, str]:
    """Validates and permanently activates a license key for this machine."""
    hwid = get_hwid()
    valid, msg = validate_key(key, hwid)
    if not valid:
        valid, msg = validate_key(key, _get_legacy_hwid())
        
    if not valid:
        return False, msg

    try:
        clean_key = key.strip().upper()
        try:
            LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
            LICENSE_FILE.write_text(clean_key, encoding="utf-8")
        except Exception:
            pass
        
        data = _load_or_init_storage()
        data["is_activated"] = True
        data["license_key"] = clean_key
        data["tampered"] = False
        data["last_seen"] = time.time()
        _save_storage(data)
        
        return True, f"🎉 License Activated Successfully!\n{msg}"
    except Exception as e:
        return False, f"Failed to save license: {e}"


def get_stored_key() -> str:
    if LICENSE_FILE.exists():
        try:
            return LICENSE_FILE.read_text(encoding="utf-8").strip()
        except Exception:
            pass
    # Local directory fallback if running in dev or portable mode
    local_lic = (Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent) / ".nadeem_license"
    if local_lic.exists() and local_lic != LICENSE_FILE:
        try:
            return local_lic.read_text(encoding="utf-8").strip()
        except Exception:
            pass
    data = _load_or_init_storage()
    return data.get("license_key", "")


def get_license_info() -> dict:
    acc = check_access()
    stored = get_stored_key()
    return {
        "status": acc.get("status_label", "Unknown"),
        "key": stored,
        "valid": acc.get("allowed", False),
        "is_activated": acc.get("is_activated", False),
        "trial_expired": acc.get("trial_expired", False),
        "days_left": acc.get("days_left", 0),
        "badge_html": acc.get("badge_html", ""),
        "hwid": acc.get("hwid", get_hwid())
    }


# Initial access check when module is imported
_initial_state = check_access()
try:
    print(f"[Security Engine] HWID: {_initial_state['hwid']} | Status: {_initial_state['status_label']}")
except Exception:
    pass
