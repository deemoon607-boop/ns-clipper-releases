"""
config.py — Persistent API Key Storage with Auto-Rotation & Atomic Force-Flush
==============================================================================
Multiple keys per service — auto-rotates on rate limit / error.
Atomic file writes with fsync ensure zero locking collisions and instant disk sync.
"""

import sys, os, json, re
from pathlib import Path

APP_VERSION = "1.1.2"
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/deemoon607-boop/ns-clipper-releases/refs/heads/main/version.json"

def get_update_manifest_url() -> str:
    """Returns base update manifest URL appended with dynamic cache-busting timestamp."""
    import time
    sep = "&" if "?" in UPDATE_MANIFEST_URL else "?"
    return f"{UPDATE_MANIFEST_URL}{sep}t={int(time.time())}"

if getattr(sys, 'frozen', False):
    APPDATA_DIR = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))) / "NS_Clipper"
    try:
        APPDATA_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    CONFIG_PATH = str(APPDATA_DIR / "config.json")
    # Initialize from bundled template if not yet created in AppData
    if not os.path.exists(CONFIG_PATH):
        bundled_cfg = os.path.join(os.path.dirname(sys.executable), "config.json")
        if os.path.exists(bundled_cfg):
            try:
                import shutil
                shutil.copy2(bundled_cfg, CONFIG_PATH)
            except Exception:
                pass
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    CONFIG_PATH = os.path.join(BASE_DIR, "config.json")

def get_config_path() -> Path:
    """Returns absolute path to active config.json file."""
    return Path(CONFIG_PATH)

_DEFAULT = {
    "groq_keys":        [],
    "gemini_keys":      [],
    "deepgram_keys":    [],
    "openai_keys":      [],
    "anthropic_keys":   [],
    "deepseek_keys":    [],
    "elevenlabs_keys":  [],
    "replicate_keys":   [],
    "runware_keys":     [],
    "together_keys":    [],
    "huggingface_keys": [],
    "modal_endpoint":   "",
    "pixabay_keys":     [],
    "pexels_keys":      [],
    "heygen_keys":      [],
    "transcription_model": "Whisper Large V3 Turbo",
    "scoring_model":    "Local Smart AI Scorer (Offline 🛡️)",
    "output_folder":    "",
    "default_voice_backend": "Edge TTS — Free",
    "default_voice_mode": "Natural",
}

# ── Load / Save ───────────────────────────────────────────────────────────────

def load() -> dict:
    """Always reads the freshest on-disk config from active path."""
    cfg_path = get_config_path()
    if cfg_path.exists():
        try:
            data = json.loads(cfg_path.read_text(encoding="utf-8"))
            return {**_DEFAULT, **data}
        except Exception:
            pass

    return dict(_DEFAULT)


def save(cfg: dict, config_path: Path = None):
    """
    Atomic write with explicit OS force-flush (fsync) and file replacement.
    Guarantees no file locking collisions and instant disk persistence.
    """
    target_path = config_path or get_config_path()
    try:
        target_path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    temp_path = target_path.with_suffix(".json.tmp")
    payload = json.dumps(cfg, indent=2, ensure_ascii=False)

    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass

        if target_path.exists():
            try:
                os.replace(temp_path, target_path)
            except Exception:
                target_path.unlink(missing_ok=True)
                temp_path.rename(target_path)
        else:
            temp_path.rename(target_path)
    except Exception as e:
        print(f"[config] Atomic save error on {target_path}: {e}")
        try:
            target_path.write_text(payload, encoding="utf-8")
        except Exception as e2:
            print(f"[config] Fallback direct write failed: {e2}")
    finally:
        if temp_path.exists():
            try:
                temp_path.unlink(missing_ok=True)
            except Exception:
                pass


def get(key: str, default=None):
    return load().get(key, default)


def set_value(key: str, value):
    cfg = load()
    cfg[key] = value
    save(cfg)


def set(key: str, value):
    set_value(key, value)


# ── Key sanitization and helpers ─────────────────────────────────────────────

def sanitize_key(k: str) -> str:
    """Strips quotes, invisible unicode characters, newlines, carriage returns, whitespace, and placeholder strings."""
    if not k:
        return ""
    k = str(k).strip().replace("\r", "").replace("\n", "").replace("\t", "").replace("\0", "")
    # Remove surrounding single/double quotes or backticks
    k = k.strip("'\"` \t\r\n")
    # Remove zero-width and invisible unicode characters
    k = re.sub(r'[\u200B-\u200D\uFEFF\u00A0]', '', k)
    k = k.strip()
    # Ignore placeholder strings
    if k.lower().startswith("enter ") or "..." in k or k.lower() == "none":
        return ""
    return k


def parse_keys(raw: str | list) -> list[str]:
    """Parse comma/newline separated raw text or list into sanitized unique keys."""
    if isinstance(raw, list):
        items = raw
    elif isinstance(raw, str):
        items = raw.replace(",", "\n").replace(";", "\n").splitlines()
    else:
        return []

    clean_keys = []
    for item in items:
        sk = sanitize_key(item)
        if sk and sk not in clean_keys:
            clean_keys.append(sk)
    return clean_keys


def get_groq_keys()        -> list[str]: return parse_keys(load().get("groq_keys",        []))
def get_gemini_keys()      -> list[str]: return parse_keys(load().get("gemini_keys",      []))
def get_deepgram_keys()    -> list[str]: return parse_keys(load().get("deepgram_keys",    []))
def get_elevenlabs_keys()  -> list[str]: return parse_keys(load().get("elevenlabs_keys",  []))
def get_openai_keys()      -> list[str]: return parse_keys(load().get("openai_keys",      []))
def get_anthropic_keys()   -> list[str]: return parse_keys(load().get("anthropic_keys",   []))
def get_deepseek_keys()    -> list[str]: return parse_keys(load().get("deepseek_keys",    []))
def get_replicate_keys()   -> list[str]: return parse_keys(load().get("replicate_keys",   []))
def get_runware_keys()     -> list[str]: return parse_keys(load().get("runware_keys",     []))
def get_together_keys()    -> list[str]: return parse_keys(load().get("together_keys",    []))
def get_huggingface_keys() -> list[str]: return parse_keys(load().get("huggingface_keys", []))
def get_modal_endpoint()   -> str:       return sanitize_key(load().get("modal_endpoint", ""))
def get_pixabay_keys()     -> list[str]: return parse_keys(load().get("pixabay_keys",     []))
def get_pexels_keys()      -> list[str]: return parse_keys(load().get("pexels_keys",      []))
def get_heygen_keys()      -> list[str]: return parse_keys(load().get("heygen_keys",      []))


def is_key_set(service: str) -> bool:
    cfg_data = load()
    service_key_map = {
        "replicate": "replicate_keys",
        "runware": "runware_keys",
        "together": "together_keys",
        "huggingface": "huggingface_keys",
        "modal": "modal_endpoint",
        "pexels": "pexels_keys",
        "pixabay": "pixabay_keys",
        "groq": "groq_keys",
        "gemini": "gemini_keys",
        "deepgram": "deepgram_keys",
        "openai": "openai_keys",
        "anthropic": "anthropic_keys",
        "deepseek": "deepseek_keys",
        "elevenlabs": "elevenlabs_keys",
        "heygen": "heygen_keys",
    }
    k = service_key_map.get(service.lower(), f"{service.lower()}_keys")
    val = cfg_data.get(k)
    if isinstance(val, list):
        return len(parse_keys(val)) > 0
    if isinstance(val, str):
        return bool(sanitize_key(val))
    return False


def save_single_key(service: str, value: str) -> bool:
    cfg_data = load()
    service_key_map = {
        "replicate": "replicate_keys",
        "runware": "runware_keys",
        "together": "together_keys",
        "huggingface": "huggingface_keys",
        "modal": "modal_endpoint",
        "pexels": "pexels_keys",
        "pixabay": "pixabay_keys",
        "groq": "groq_keys",
        "gemini": "gemini_keys",
        "deepgram": "deepgram_keys",
        "openai": "openai_keys",
        "anthropic": "anthropic_keys",
        "deepseek": "deepseek_keys",
        "elevenlabs": "elevenlabs_keys",
        "heygen": "heygen_keys",
    }
    k = service_key_map.get(service.lower(), f"{service.lower()}_keys")
    if k == "modal_endpoint":
        cfg_data[k] = sanitize_key(value)
    else:
        cfg_data[k] = parse_keys(value)
    save(cfg_data)
    return True


def save_all_keys(keys_dict: dict, output_folder: str = None) -> bool:
    """Batch-save multiple API keys and export destination folder atomically."""
    cfg_data = load()
    for service, val in keys_dict.items():
        k = f"{service.lower()}_keys" if not service.endswith("_keys") and service != "modal_endpoint" else service
        if k == "modal_endpoint":
            cfg_data[k] = sanitize_key(val)
        else:
            cfg_data[k] = parse_keys(val)
    if output_folder is not None:
        cfg_data["output_folder"] = str(output_folder).strip()
    save(cfg_data)
    return True


def delete_single_key(service: str) -> bool:
    return save_single_key(service, "")


def get_output_folder() -> str:
    f = load().get("output_folder", "")
    if f and Path(f).exists():
        return f
    default_dir = Path(__file__).parent / "workspace" / "exports"
    default_dir.mkdir(parents=True, exist_ok=True)
    return str(default_dir)


def set_output_folder(path: str):
    set_value("output_folder", path)


def keys_to_display(keys: list[str]) -> str:
    if not keys: return ""
    return "\n".join(
        k[:8] + "..." + k[-4:] if len(k) > 12 else k for k in keys
    )

