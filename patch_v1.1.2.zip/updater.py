"""
updater.py — In-App Over-The-Air (OTA) Auto-Updater Engine
===========================================================
Enables lightweight patch updates (<10-30MB) without requiring
users to re-download the full 1.5GB application installer.
"""

import os
import sys
import json
import time
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from typing import Optional, Callable, Dict, Any

import httpx
import requests
import config as cfg

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def _parse_version(v_str: str) -> tuple:
    """Convert version string '1.2.3' to tuple (1, 2, 3) for safe comparison."""
    clean = v_str.strip().lstrip("vV")
    parts = []
    for p in clean.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def check_for_updates(current_version: str = None, manifest_url: str = None) -> Dict[str, Any]:
    """
    Query the remote manifest to check for software updates.
    Appends dynamic timestamp parameter & no-cache headers to bypass CDN/GitHub caching.
    Returns dictionary with update info and changelog.
    """
    curr_v = current_version or cfg.APP_VERSION
    url = manifest_url or getattr(cfg, "UPDATE_MANIFEST_URL", "")

    result = {
        "update_available": False,
        "current_version": curr_v,
        "latest_version": curr_v,
        "changelog": "",
        "download_url": "",
        "mandatory": False,
        "message": "You are on the latest version."
    }

    if not url:
        return result

    # Append a dynamic microsecond/second timestamp parameter to bust raw.githubusercontent cache
    sep = "&" if "?" in url else "?"
    cache_buster_url = f"{url}{sep}t={int(time.time() * 1000)}"

    headers = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
    }

    try:
        data = None
        status_code = 0
        try:
            with httpx.Client(timeout=10.0, follow_redirects=True, headers=headers) as client:
                resp = client.get(cache_buster_url)
                status_code = resp.status_code
                if status_code == 200:
                    data = resp.json()
        except Exception:
            # Fallback to requests if httpx encounters an issue
            resp = requests.get(cache_buster_url, timeout=10, headers=headers)
            status_code = resp.status_code
            if status_code == 200:
                data = resp.json()

        if status_code == 200 and isinstance(data, dict):
            latest_v = data.get("version") or data.get("latest_version") or curr_v
            result["latest_version"] = str(latest_v)
            result["changelog"] = data.get("changelog") or data.get("release_notes") or "No release notes provided."
            result["download_url"] = data.get("download_url", "")
            result["mandatory"] = data.get("mandatory", False)

            if _parse_version(str(latest_v)) > _parse_version(str(curr_v)):
                result["update_available"] = True
                result["message"] = f"New version v{latest_v} available!"
            else:
                result["message"] = "You have the latest version installed."
        else:
            result["message"] = f"Update server returned status {status_code}."
    except Exception as e:
        result["message"] = f"Could not check for updates: {e}"

    return result


def download_patch(
    download_url: str,
    dest_dir: str = None,
    progress_cb: Optional[Callable[[int, int], None]] = None
) -> str:
    """
    Download update patch zip with chunked progress reporting.
    Returns path to downloaded patch file.
    """
    if not dest_dir:
        dest_dir = tempfile.gettempdir()
    os.makedirs(dest_dir, exist_ok=True)
    out_file = os.path.join(dest_dir, "ns_clipper_patch.zip")

    try:
        with httpx.Client(timeout=120.0, follow_redirects=True) as client:
            with client.stream("GET", download_url) as resp:
                resp.raise_for_status()
                total_size = int(resp.headers.get("content-length", 0))
                downloaded = 0

                with open(out_file, "wb") as f:
                    for chunk in resp.iter_bytes(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if progress_cb and total_size > 0:
                                percent = int((downloaded / total_size) * 100)
                                progress_cb(min(100, percent), downloaded)
    except Exception:
        import requests
        with requests.get(download_url, stream=True, timeout=120, allow_redirects=True) as resp:
            resp.raise_for_status()
            total_size = int(resp.headers.get("content-length", 0))
            downloaded = 0
            with open(out_file, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if progress_cb and total_size > 0:
                            percent = int((downloaded / total_size) * 100)
                            progress_cb(min(100, percent), downloaded)

    return out_file


def is_admin_required(target_dir: str = None) -> bool:
    """
    Checks whether write permissions exist in target installation directory.
    Returns True if administrator elevation / UAC is required.
    """
    if not target_dir:
        if getattr(sys, "frozen", False):
            target_dir = str(Path(sys.executable).parent)
        else:
            target_dir = str(Path(__file__).parent)
    try:
        test_file = Path(target_dir) / f".write_test_{os.getpid()}.tmp"
        test_file.write_text("test", encoding="utf-8")
        test_file.unlink(missing_ok=True)
        return False
    except (PermissionError, OSError):
        return True


def get_update_result_file() -> Path:
    """Returns path to the shared temporary update result JSON file."""
    return Path(tempfile.gettempdir()) / "ns_clipper_update_result.json"


def read_last_update_result() -> Optional[Dict[str, Any]]:
    """Reads and consumes the result of the last update attempt if present."""
    p = get_update_result_file()
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            p.unlink(missing_ok=True)
            return data
        except Exception:
            try:
                p.unlink(missing_ok=True)
            except Exception:
                pass
    return None


def prepare_patch_backup(patch_zip_path: str, target_dir: str) -> str:
    """
    Creates a selective backup in %LOCALAPPDATA%/NS_Clipper/update_backups/
    Backs up ONLY the specific files being replaced by the patch ZIP.
    Retains the 2 most recent backups and returns the backup directory path.
    """
    local_app = os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))
    backup_root = Path(local_app) / "NS_Clipper" / "update_backups"
    backup_root.mkdir(parents=True, exist_ok=True)

    timestamp_str = time.strftime("%Y%m%d_%H%M%S")
    current_backup_dir = backup_root / f"backup_{timestamp_str}"
    current_backup_dir.mkdir(parents=True, exist_ok=True)

    target_path = Path(target_dir)

    try:
        with zipfile.ZipFile(patch_zip_path, "r") as z:
            for item in z.infolist():
                if item.is_dir():
                    continue
                rel_path = item.filename.replace("/", os.sep).replace("\\", os.sep)
                # Ensure we never backup sensitive user configs or vaults
                if any(x in rel_path.lower() for x in ["config.json", ".env", ".nadeem_license", ".sys_vault", "admin_keys_vault", "social_tokens"]):
                    continue
                src_file = target_path / rel_path
                if src_file.exists() and src_file.is_file():
                    dest_file = current_backup_dir / rel_path
                    dest_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(str(src_file), str(dest_file))
    except Exception as e:
        print(f"[updater] Warning during backup creation: {e}")

    # Retain only the last 2 backup directories
    try:
        all_backups = sorted(
            [d for d in backup_root.iterdir() if d.is_dir() and d.name.startswith("backup_")],
            key=lambda d: d.stat().st_mtime
        )
        while len(all_backups) > 2:
            oldest = all_backups.pop(0)
            shutil.rmtree(str(oldest), ignore_errors=True)
    except Exception:
        pass

    return str(current_backup_dir)


def apply_patch_and_restart(patch_zip_path: str, target_dir: str = None) -> tuple[bool, str]:
    """
    Generate and launch a standalone detached updater with:
    1. Automatic UAC Administrator Elevation if target directory is protected
    2. Pre-update selective backup of replaced files
    3. ZIP archive integrity validation
    4. Post-extraction verification of expected files and application executable
    5. Automatic Rollback from backup if extraction or validation fails
    6. Structured result recording to %TEMP%/ns_clipper_update_result.json
    7. Clean restart of application
    """
    if not target_dir:
        if getattr(sys, "frozen", False):
            target_dir = str(Path(sys.executable).parent)
            main_exe = sys.executable
        else:
            target_dir = str(Path(__file__).parent)
            main_exe = sys.executable  # python executable

    patch_path = os.path.abspath(patch_zip_path)
    target_path = os.path.abspath(target_dir)
    app_pid = os.getpid()

    # 1. Verify patch zip file exists and is valid
    if not os.path.exists(patch_path):
        return False, f"Patch file not found: {patch_path}"
    try:
        with zipfile.ZipFile(patch_path, "r") as z:
            if z.testzip() is not None:
                return False, "Patch ZIP archive is corrupted."
            zip_files = [f.filename for f in z.infolist() if not f.is_dir()]
    except Exception as e:
        return False, f"Invalid patch ZIP archive: {e}"

    # 2. Create selective backup before applying update
    backup_dir = prepare_patch_backup(patch_path, target_path)

    # 3. Prepare result file path
    result_path = str(get_update_result_file())
    # Clear any previous result file
    try:
        get_update_result_file().unlink(missing_ok=True)
    except Exception:
        pass

    # 4. Generate standalone PowerShell updater script
    temp_dir = tempfile.gettempdir()
    ps_script_path = os.path.join(temp_dir, "ns_clipper_update_runner.ps1")

    # Serialize files list for PowerShell array
    zip_files_ps = "@(" + ", ".join(f'"{f}"' for f in zip_files) + ")"
    is_frozen_str = "$true" if getattr(sys, "frozen", False) else "$false"
    py_script_path = os.path.join(target_path, "main_desktop.py")

    ps_content = f'''# NS Clipper Elevated OTA Update Runner
$ErrorActionPreference = "Stop"
$patchPath   = "{patch_path.replace('"', '`"')}"
$targetPath  = "{target_path.replace('"', '`"')}"
$backupPath  = "{backup_dir.replace('"', '`"')}"
$resultPath  = "{result_path.replace('"', '`"')}"
$mainExe     = "{main_exe.replace('"', '`"')}"
$pyScript    = "{py_script_path.replace('"', '`"')}"
$isFrozen    = {is_frozen_str}
$appPid      = {app_pid}
$expectedFiles = {zip_files_ps}

function Write-Result($success, $msg, $err) {{
    $res = @{{
        success = $success
        timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        message = $msg
        error = $err
    }} | ConvertTo-Json
    [System.IO.File]::WriteAllText($resultPath, $res, [System.Text.Encoding]::UTF8)
}}

try {{
    # Step 1: Wait for application process to close
    Write-Host "[Updater] Waiting for app process ($appPid) to terminate..."
    $timeoutSeconds = 20
    $elapsed = 0
    while ($elapsed -lt $timeoutSeconds) {{
        $proc = Get-Process -Id $appPid -ErrorAction SilentlyContinue
        if (-not $proc) {{ break }}
        Start-Sleep -Milliseconds 500
        $elapsed += 0.5
    }}

    # Force kill if still lingering
    $proc = Get-Process -Id $appPid -ErrorAction SilentlyContinue
    if ($proc) {{
        Stop-Process -Id $appPid -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
    }}

    # Step 2: Validate ZIP before extraction
    if (-not (Test-Path -Path $patchPath)) {{
        throw "Patch file disappeared before extraction: $patchPath"
    }}

    # Step 3: Extract Patch to Target Directory with retries
    Write-Host "[Updater] Extracting patch to: $targetPath"
    $extracted = $false
    for ($i = 0; $i -lt 15; $i++) {{
        try {{
            Expand-Archive -Path $patchPath -DestinationPath $targetPath -Force
            $extracted = $true
            break
        }} catch {{
            Start-Sleep -Milliseconds 600
        }}
    }}
    if (-not $extracted) {{
        throw "Failed to extract patch archive into target directory after 15 attempts."
    }}

    # Step 4: Validate extraction completeness
    foreach ($rel in $expectedFiles) {{
        $normRel = $rel -replace "/", "\\"
        $fullPath = Join-Path $targetPath $normRel
        if (-not (Test-Path -Path $fullPath)) {{
            throw "Expected file missing after extraction: $normRel"
        }}
    }}

    if ($isFrozen -and (-not (Test-Path -Path $mainExe))) {{
        throw "Main application executable missing after extraction: $mainExe"
    }}

    # Step 5: Success -> Record result and cleanup patch
    Write-Result $true "Software updated successfully!" ""
    Remove-Item -Path $patchPath -Force -ErrorAction SilentlyContinue
    Write-Host "[Updater] Update successful!"

}} catch {{
    # Step 6: Rollback on failure
    $errMessage = $_.Exception.Message
    Write-Host "[Updater] ERROR encountered: $errMessage"
    Write-Host "[Updater] Initiating automatic rollback from backup: $backupPath"

    try {{
        if (Test-Path -Path $backupPath) {{
            Copy-Item -Path "$backupPath\\*" -Destination $targetPath -Recurse -Force -ErrorAction SilentlyContinue
        }}
    }} catch {{
        Write-Host "[Updater] Rollback error: $_"
    }}

    Write-Result $false "Update failed and was restored from backup." $errMessage
}}

# Step 7: Relaunch application
try {{
    if ($isFrozen) {{
        Start-Process -FilePath $mainExe
    }} else {{
        Start-Process -FilePath $mainExe -ArgumentList "`"$pyScript`""
    }}
}} catch {{
    Write-Host "[Updater] Could not restart application: $_"
}}
'''

    with open(ps_script_path, "w", encoding="utf-8") as f:
        f.write(ps_content)

    # 5. Launch elevated or standard process
    admin_needed = is_admin_required(target_path)
    try:
        if admin_needed:
            # Use PowerShell Start-Process with -Verb RunAs for UAC prompt
            cmd = [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                f"Start-Process powershell.exe -ArgumentList '-NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File \"{ps_script_path}\"' -Verb RunAs"
            ]
            subprocess.Popen(cmd, creationflags=CREATE_NO_WINDOW)
        else:
            cmd = [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Normal",
                "-File", ps_script_path
            ]
            subprocess.Popen(
                cmd,
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                close_fds=True
            )
        return True, "Update process initiated successfully."
    except Exception as e:
        err_str = str(e)
        if "cancel" in err_str.lower() or "1223" in err_str:
            return False, "Update cancelled: administrator permission was not granted."
        return False, f"Failed to launch update process: {e}"

