# Auto-generated OTA Live Hotpatch Loader
import sys, os
from pathlib import Path
app_dir = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent.parent
if str(app_dir) not in sys.path:
    sys.path.insert(0, str(app_dir))
try:
    for i, finder in enumerate(list(sys.meta_path)):
        if 'PathFinder' in getattr(finder, '__name__', str(finder)):
            sys.meta_path.insert(0, sys.meta_path.pop(i))
            break
except Exception:
    pass
