"""
gemini_service.py â€” Google Gemini 2.5 Flash powered AI features
================================================================
Powers three main capabilities:
  1. Transcription with word-level timestamps (audio â†’ timed SRT)
  2. Caption style detection from reference video frames
  3. Reel styling suggestions (hook, pacing, overlay recommendations)

Model: gemini-3.6-flash
Requires: GEMINI_API_KEY in config
"""

from __future__ import annotations
import base64
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

import config as cfg

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
GEMINI_MODEL = "gemini-2.5-flash"

_API_BASE    = "https://generativelanguage.googleapis.com/v1beta/models"

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_key(override_key: str = None) -> str:
    if override_key:
        clean = cfg.sanitize_key(override_key)
        if clean:
            return clean
    keys = cfg.get_gemini_keys()
    if not keys:
        raise RuntimeError("No Gemini API key found. Add one in Settings → API Keys.")
    clean = cfg.sanitize_key(keys[0])
    if not clean:
        raise RuntimeError("Invalid or empty Gemini API key. Add one in Settings → API Keys.")
    return clean


def _call_gemini(parts: list, system: str = "", temperature: float = 0.2, api_key: str = None) -> str:
    """Send a multimodal request to Gemini and return the text response."""
    import urllib.request
    key = _get_key(api_key)
    url = f"{_API_BASE}/{GEMINI_MODEL}:generateContent?key={key}"

    body: dict = {
        "contents": [{"role": "user", "parts": parts}],
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": 8192,
        },
    }
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}

    data = json.dumps(body).encode()
    req  = urllib.request.Request(url, data=data,
                                  headers={"Content-Type": "application/json"},
                                  method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read())
            return result["candidates"][0]["content"]["parts"][0]["text"]
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Gemini API error {e.code}: {e.read().decode()[:400]}")


def _extract_audio_b64(video_path: str, max_sec: int = 3600) -> tuple[str, str]:
    """
    Extract audio from video (mp3, max_sec), return (base64_str, mime_type).
    Falls back to full video if ffmpeg fails.
    """
    tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    tmp.close()
    cmd = [
        "ffmpeg", "-y", "-i", video_path,
        "-t", str(max_sec),
        "-vn", "-ar", "16000", "-ac", "1",
        "-b:a", "64k", tmp.name,
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True, creationflags=CREATE_NO_WINDOW)
        audio_bytes = Path(tmp.name).read_bytes()
        Path(tmp.name).unlink(missing_ok=True)
        return base64.b64encode(audio_bytes).decode(), "audio/mpeg"
    except Exception:
        Path(tmp.name).unlink(missing_ok=True)
        raise


def _extract_frame_b64(video_path: str, ts: float = 1.0) -> str:
    """Extract one JPEG frame from video at ts seconds, return base64."""
    tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
    tmp.close()
    subprocess.run([
        "ffmpeg", "-y", "-ss", str(ts), "-i", video_path,
        "-vframes", "1", "-q:v", "2", tmp.name,
    ], check=True, capture_output=True, creationflags=CREATE_NO_WINDOW)
    img_b64 = base64.b64encode(Path(tmp.name).read_bytes()).decode()
    Path(tmp.name).unlink(missing_ok=True)
    return img_b64


# ─────────────────────────────────────────────────────────────────────────────
# 1. Transcription with Word-Level Timestamps
# ─────────────────────────────────────────────────────────────────────────────

def transcribe_with_timing(
    video_path: str,
    language: Optional[str] = None,
    max_sec: int = 3600,
    log=None,
    api_key: Optional[str] = None,
) -> list[dict]:
    """
    Transcribe audio using Gemini 2.5 Flash with word-level timestamps.

    Returns list of segment dicts:
        {"start": float, "end": float, "text": str, "words": [...]}

    Each word: {"word": str, "start": float, "end": float}
    """
    def _log(m):
        if log:
            try:
                log(str(m))
            except Exception:
                try:
                    log(str(m).encode('ascii', 'replace').decode('ascii'))
                except Exception:
                    pass

    _log(f"[Gemini] Extracting audio from {Path(video_path).name}...")
    audio_b64, mime = _extract_audio_b64(video_path, max_sec)

    lang_note = f"The spoken language is {language}. " if language else "Auto-detect the language. "

    # Simplified prompt - no word-level timing to avoid token overflow on long videos
    prompt = (
        f"{lang_note}"
        "Transcribe ALL the audio. "
        "Return ONLY a valid JSON array of segment objects - nothing else, no markdown. "
        "Format: [{\"start\": 0.0, \"end\": 4.5, \"text\": \"sentence here\"}, ...]. "
        "Each segment should be 1-2 sentences. Cover the entire audio completely."
    )

    _log(f"[Gemini] Sending to {GEMINI_MODEL} for transcription...")
    parts = [
        {"inline_data": {"mime_type": mime, "data": audio_b64}},
        {"text": prompt},
    ]
    raw = _call_gemini(parts, temperature=0.1, api_key=api_key)

    segments = _parse_segments_robust(raw, log=_log)
    _log(f"[Gemini] [OK] Got {len(segments)} segments.")
    return segments


def transcribe_words(
    video_path: str,
    language: Optional[str] = None,
    max_sec: int = 600,
    log=None,
) -> list[dict]:
    """
    Gemini 3.5 Flash: parse audio → per-word timestamps.

    Returns flat list: [{word, start, end}, ...]
    Powers the 60fps karaoke caption overlay in the browser.
    """
    def _log(m):
        if log: log(m)

    _log(f"[Gemini Words] Extracting audio from {Path(video_path).name}...")
    audio_b64, mime = _extract_audio_b64(video_path, max_sec)

    lang_note = f"Language: {language}. " if language else "Auto-detect language. "

    prompt = (
        f"{lang_note}"
        "Listen to this audio very carefully. "
        "Your task: output a JSON array where EVERY SINGLE SPOKEN WORD has its own entry "
        "with the EXACT start and end time in seconds (2 decimal places). "
        "Return ONLY valid JSON — no markdown, no explanation, no extra text. "
        'Format exactly: [{"word": "Hello", "start": 0.10, "end": 0.45}, ...] '
        "Include every word including 'um', 'uh', filler words. "
        "Do not skip any words. Cover the entire audio."
    )

    _log(f"[Gemini Words] Sending to {GEMINI_MODEL} for word-level timestamps...")
    parts = [
        {"inline_data": {"mime_type": mime, "data": audio_b64}},
        {"text": prompt},
    ]
    raw = _call_gemini(parts, temperature=0.0)

    words = _parse_segments_robust(raw, log=_log)

    # Validate & clean
    clean = []
    for w in words:
        if not isinstance(w, dict):
            continue
        word_text = str(w.get("word") or w.get("text") or "").strip()
        if not word_text:
            continue
        start = float(w.get("start", 0))
        end   = float(w.get("end", start + 0.3))
        if end <= start:
            end = start + 0.3
        clean.append({"word": word_text, "start": round(start, 2), "end": round(end, 2)})

    _log(f"[Gemini Words] ✅ {len(clean)} words timestamped.")
    return clean


def _parse_segments_robust(raw: str, log=None) -> list[dict]:
    """
    Multi-strategy JSON parser — handles:
      - Markdown code fences (```json ... ```)
      - Trailing commas
      - Truncated / incomplete JSON
      - Mixed text + JSON
    """
    def _log(m):
        if log: log(m)

    # Strategy 1: strip markdown fences, try direct parse
    cleaned = re.sub(r'```(?:json)?\s*', '', raw).replace('```', '').strip()
    for attempt in [cleaned, raw]:
        match = re.search(r'\[.*\]', attempt, re.DOTALL)
        if match:
            candidate = match.group()
            # Fix trailing commas before ] or }
            candidate = re.sub(r',\s*([}\]])', r'\1', candidate)
            try:
                return json.loads(candidate)
            except json.JSONDecodeError:
                pass

    # Strategy 2: try to repair truncated JSON by closing open structure
    match = re.search(r'\[', cleaned)
    if match:
        fragment = cleaned[match.start():]
        # Remove trailing commas and incomplete last object
        fragment = re.sub(r',\s*\{[^}]*$', '', fragment).rstrip(',').rstrip()
        if not fragment.endswith(']'):
            fragment += ']'
        try:
            result = json.loads(fragment)
            _log(f"[Gemini] âš ï¸ Repaired truncated JSON â€” got {len(result)} segments.")
            return result
        except json.JSONDecodeError:
            pass

    # Strategy 3: extract individual segment objects with regex
    objects = re.findall(
        r'\{\s*"start"\s*:\s*([\d.]+)\s*,\s*"end"\s*:\s*([\d.]+)\s*,\s*"text"\s*:\s*"([^"]+)"',
        raw
    )
    if objects:
        _log(f"[Gemini] âš ï¸ Used regex fallback â€” extracted {len(objects)} segments.")
        return [{"start": float(s), "end": float(e), "text": t} for s, e, t in objects]

    # Strategy 4: plain text fallback â€” split on newlines, assign fake timestamps
    _log("[Gemini] âš ï¸ JSON parse failed completely â€” using plain text fallback.")
    lines = [l.strip() for l in raw.splitlines() if l.strip() and not l.strip().startswith('[')]
    segments = []
    t = 0.0
    for line in lines[:200]:
        words = len(line.split())
        dur = max(1.0, words * 0.4)
        segments.append({"start": round(t, 2), "end": round(t + dur, 2), "text": line})
        t += dur
    return segments



def segments_to_srt(segments: list[dict]) -> str:
    """Convert Gemini segment list to SRT string."""
    def _ts(sec: float) -> str:
        h  = int(sec // 3600)
        m  = int((sec % 3600) // 60)
        s  = int(sec % 60)
        ms = int(round((sec - int(sec)) * 1000))
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    lines = []
    for i, seg in enumerate(segments, 1):
        text = str(seg.get("text", "")).strip()
        if not text:
            continue
        lines += [
            str(i),
            f"{_ts(float(seg['start']))} --> {_ts(float(seg['end']))}",
            text,
            "",
        ]
    return "\n".join(lines)


def transcribe_to_srt(video_path: str, language: Optional[str] = None,
                      max_sec: int = 300, log=None) -> tuple[str, str]:
    """
    Full pipeline: video â†’ Gemini â†’ SRT string + full text.
    Returns: (srt_string, full_text)
    """
    segments = transcribe_with_timing(video_path, language, max_sec, log)
    srt      = segments_to_srt(segments)
    text     = " ".join(s.get("text", "").strip() for s in segments)
    return srt, text


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 2. Caption Style Detection from Reference Video
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

CAPTION_STYLES = [
    "Classic", "TikTok Bold", "Black Box", "Neon Cyan", "Yellow Shadow",
    "Minimal Clean", "Viral Red", "Fire Orange", "Royal Purple", "Matrix Green",
    "Luxury Gold", "Neon Pink", "Ice Blue", "Dark Pill", "Gold Pill",
    "Red Alert", "Cinematic White", "Cinematic Italic", "Comic Bold", "White Stroke",
]


def detect_caption_style(video_path: str, log=None) -> dict:
    """
    Analyse a reference video frame with Gemini Vision.
    Returns full style dict: font, size, color, stroke, shadow, bg, position, etc.
    """
    def _log(m):
        if log: log(m)

    _log("[Gemini] Extracting reference frame for caption analysis...")
    img_b64 = _extract_frame_b64(video_path, ts=2.0)

    styles_list = ", ".join(CAPTION_STYLES)
    prompt = (
        "Look at the captions/subtitles in this video frame carefully and extract EVERY visual detail. "
        f"Also pick the closest style name from this list: [{styles_list}]. "
        "Return ONLY valid JSON with these exact fields (no explanation):\n"
        "{\n"
        '  \"style\": \"<closest style name from list>\",\n'
        '  \"position\": \"<Bottom Edge|Lower Third|Center Focus|top>\",\n'
        '  \"font_family\": \"<font name e.g. Arial, Impact, Montserrat, Oswald>\",\n'
        '  \"font_size_px\": <int e.g. 28>,\n'
        '  \"font_weight\": \"<bold|normal|900|800|700>\",\n'
        '  \"font_style\": \"<normal|italic>\",\n'
        '  \"text_color\": \"<hex e.g. #ffffff>\",\n'
        '  \"uppercase\": <true|false>,\n'
        '  \"letter_spacing\": \"<e.g. 0px|2px>\",\n'
        '  \"stroke_color\": \"<hex or none>\",\n'
        '  \"stroke_width\": \"<e.g. 0px|2px|3px>\",\n'
        '  \"shadow\": \"<CSS text-shadow or none>\",\n'
        '  \"background_color\": \"<hex or transparent>\",\n'
        '  \"background_opacity\": <float 0.0-1.0>,\n'
        '  \"background_radius\": \"<e.g. 0px|4px|8px>\",\n'
        '  \"active_color\": \"<highlight color for active word e.g. #ffff00>\",\n'
        '  \"confidence\": <float 0.0-1.0>,\n'
        '  \"notes\": \"<one sentence describing captions>\",\n'
        "}"
    )

    _log(f"[Gemini] Analysing full caption style with {GEMINI_MODEL}...")
    parts = [
        {"inline_data": {"mime_type": "image/jpeg", "data": img_b64}},
        {"text": prompt},
    ]
    raw = _call_gemini(parts, temperature=0.1)

    match = re.search(r'\{.*\}', raw, re.DOTALL)
    if not match:
        return {"style": "Classic", "position": "Bottom Edge",
                "font_size_px": 28, "confidence": 0.0,
                "notes": "Could not parse Gemini response."}

    result = json.loads(match.group())
    _log(f"[Gemini] Detected: {result.get('style')} | {result.get('font_family','?')} "
         f"{result.get('font_size_px','?')}px color={result.get('text_color','?')}")
    return result



# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 3. Reel Styling Suggestions
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def suggest_reel_style(
    transcript_text: str,
    video_path: Optional[str] = None,
    niche: str = "general",
    log=None,
) -> dict:
    """
    Analyse transcript + optional video frame with Gemini.
    Returns styling recommendations dict:
    {
        hook_line, caption_style, caption_position, aspect_ratio,
        music_mood, watermark_suggestion, animation_effects,
        pacing_advice, viral_score_estimate, reasoning
    }
    """
    def _log(m):
        if log: log(m)

    _log(f"[Gemini] Generating reel styling suggestions for {niche} content...")

    parts = []

    # Optionally include a video frame for visual context
    if video_path and Path(video_path).exists():
        try:
            img_b64 = _extract_frame_b64(video_path, ts=1.0)
            parts.append({"inline_data": {"mime_type": "image/jpeg", "data": img_b64}})
        except Exception:
            pass

    styles_list = ", ".join(CAPTION_STYLES)
    prompt = f"""
You are a viral short-form video expert. Analyse this transcript and suggest optimal reel styling.

TRANSCRIPT:
{transcript_text[:2000]}

NICHE: {niche}

Return ONLY a JSON object with these exact keys:
{{
  "hook_line": "<the most attention-grabbing opening line from the transcript (or suggested)>",
  "caption_style": "<pick one: {styles_list}>",
  "caption_position": "<top|bottom>",
  "aspect_ratio": "<9:16 (Portrait)|1:1 (Square)|4:5 (Instagram)|16:9 (Landscape)>",
  "music_mood": "<energetic|calm|dramatic|upbeat|cinematic|none>",
  "watermark_suggestion": "<suggested watermark text or empty string>",
  "animation_effects": ["<Ken Burns|Shake|Zoom In|Zoom Out|none>"],
  "pacing_advice": "<1-2 sentence advice on clip length and cuts>",
  "viral_score_estimate": <float 1.0-10.0>,
  "reasoning": "<2-3 sentences explaining your style choices>"
}}
"""
    parts.append({"text": prompt})

    raw = _call_gemini(parts, temperature=0.3)

    match = re.search(r'\{.*\}', raw, re.DOTALL)
    if not match:
        return {
            "hook_line": "", "caption_style": "TikTok Bold",
            "caption_position": "bottom", "aspect_ratio": "9:16 (Portrait)",
            "music_mood": "energetic", "watermark_suggestion": "",
            "animation_effects": [], "pacing_advice": "Keep clips under 60 seconds.",
            "viral_score_estimate": 5.0,
            "reasoning": "Could not parse Gemini response."
        }

    result = json.loads(match.group())
    _log(f"[Gemini] âœ… Viral score estimate: {result.get('viral_score_estimate',0)}/10")
    return result


def format_reel_suggestions(data: dict) -> str:
    """Format the reel suggestions dict as a readable text block."""
    lines = [
        f"ðŸŽ¯ Hook Line:        {data.get('hook_line', '')}",
        f"ðŸŽ¨ Caption Style:    {data.get('caption_style', '')}",
        f"ðŸ“ Position:         {data.get('caption_position', '')}",
        f"ðŸ“ Aspect Ratio:     {data.get('aspect_ratio', '')}",
        f"ðŸŽµ Music Mood:       {data.get('music_mood', '')}",
        f"ðŸ’§ Watermark:        {data.get('watermark_suggestion', '(none)')}",
        f"âœ¨ Animations:       {', '.join(data.get('animation_effects', [])) or 'none'}",
        f"âš¡ Pacing:           {data.get('pacing_advice', '')}",
        f"ðŸ”¥ Viral Score:      {data.get('viral_score_estimate', 0)}/10",
        f"",
        f"ðŸ’¡ Reasoning: {data.get('reasoning', '')}",
    ]
    return "\n".join(lines)


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 4. Gemini Viral Moment Detection
#    Gemini WATCHES the video and decides which moments are viral
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

_FILES_API_BASE = "https://generativelanguage.googleapis.com/upload/v1beta/files"
_FILES_GET_BASE = "https://generativelanguage.googleapis.com/v1beta/files"


def _upload_video_to_gemini(video_path: str, log=None) -> str:
    """
    Upload a video file to the Gemini Files API.
    Returns the file URI (e.g. 'files/abc123').
    Polls until the file is ACTIVE (processed).
    """
    import urllib.request, urllib.parse, time, mimetypes

    def _log(m):
        if log: log(m)

    key       = _get_key()
    path      = Path(video_path)
    file_size = path.stat().st_size
    mime_type = mimetypes.guess_type(str(path))[0] or "video/mp4"

    _log(f"[Gemini Files API] Uploading {path.name} ({file_size/1024/1024:.1f} MB)...")

    # Step 1: Initiate resumable upload
    init_url = f"{_FILES_API_BASE}?key={key}"
    init_headers = {
        "X-Goog-Upload-Protocol":  "resumable",
        "X-Goog-Upload-Command":   "start",
        "X-Goog-Upload-Header-Content-Length": str(file_size),
        "X-Goog-Upload-Header-Content-Type":   mime_type,
        "Content-Type": "application/json",
    }
    meta = json.dumps({"file": {"display_name": path.name}}).encode()
    req  = urllib.request.Request(init_url, data=meta, headers=init_headers, method="POST")
    with urllib.request.urlopen(req, timeout=60) as resp:
        upload_url = resp.headers.get("X-Goog-Upload-URL")
        if not upload_url:
            raise RuntimeError("Gemini Files API did not return upload URL")

    # Step 2: Upload the file bytes
    _log("[Gemini Files API] Sending video bytes...")
    with open(video_path, "rb") as f:
        video_data = f.read()

    upload_req = urllib.request.Request(
        upload_url,
        data=video_data,
        headers={
            "Content-Length": str(file_size),
            "X-Goog-Upload-Offset": "0",
            "X-Goog-Upload-Command": "upload, finalize",
        },
        method="POST",
    )
    with urllib.request.urlopen(upload_req, timeout=300) as resp:
        result = json.loads(resp.read())
        file_name = result.get("file", {}).get("name", "")
        if not file_name:
            raise RuntimeError(f"Upload failed: {result}")

    # Step 3: Poll until ACTIVE
    _log("[Gemini Files API] Waiting for video to process...")
    for _ in range(30):
        check_url = f"https://generativelanguage.googleapis.com/v1beta/{file_name}?key={key}"
        with urllib.request.urlopen(check_url, timeout=30) as resp:
            info = json.loads(resp.read())
            state = info.get("state", "")
            if state == "ACTIVE":
                uri = info.get("uri", f"https://generativelanguage.googleapis.com/v1beta/{file_name}")
                _log(f"[Gemini Files API] âœ… Video ready: {file_name}")
                return file_name  # e.g. "files/abc123"
            elif state == "FAILED":
                raise RuntimeError("Gemini video processing failed.")
        time.sleep(3)

    raise RuntimeError("Gemini video processing timed out.")


def _delete_gemini_file(file_name: str):
    """Clean up uploaded file from Gemini Files API."""
    import urllib.request
    try:
        key = _get_key()
        url = f"https://generativelanguage.googleapis.com/v1beta/{file_name}?key={key}"
        req = urllib.request.Request(url, method="DELETE")
        urllib.request.urlopen(req, timeout=15)
    except Exception:
        pass


def _call_gemini_with_file(file_name: str, prompt: str,
                            mime_type: str = "video/mp4",
                            temperature: float = 0.2) -> str:
    """Call Gemini generateContent referencing an uploaded Files API file."""
    import urllib.request
    key = _get_key()
    url = f"{_API_BASE}/{GEMINI_MODEL}:generateContent?key={key}"

    body = {
        "contents": [{
            "role": "user",
            "parts": [
                {"file_data": {"mime_type": mime_type, "file_uri": f"https://generativelanguage.googleapis.com/v1beta/{file_name}"}},
                {"text": prompt},
            ],
        }],
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": 8192,
        },
    }
    data = json.dumps(body).encode()
    req  = urllib.request.Request(url, data=data,
                                  headers={"Content-Type": "application/json"},
                                  method="POST")
    with urllib.request.urlopen(req, timeout=180) as resp:
        result = json.loads(resp.read())
        return result["candidates"][0]["content"]["parts"][0]["text"]


VIRAL_TYPES = [
    "funny", "emotional", "shocking", "motivational",
    "educational", "controversial", "satisfying", "suspenseful",
]


def find_viral_moments(
    video_path: str,
    n_clips: int = 5,
    niche: str = "general",
    viral_types: list | None = None,
    min_duration: float = 15.0,
    max_duration: float = 90.0,
    log=None,
) -> list[dict]:
    """
    Gemini 3.6 Flash WATCHES the video and identifies viral moments.

    Returns list of dicts:
    {
        "start": float,        # seconds
        "end": float,          # seconds
        "score": float,        # 1.0â€“10.0
        "hook": str,           # the opening line / attention grabber
        "reason": str,         # why this moment is viral
        "viral_type": str,     # funny / emotional / shocking / etc.
        "emotion": str,        # dominant emotion
        "clip_title": str,     # suggested short title
    }
    """
    def _log(m):
        if log: log(m)

    if not Path(video_path).exists():
        raise FileNotFoundError(f"Video not found: {video_path}")

    types_note = ""
    if viral_types:
        types_note = f"Focus on these types of moments: {', '.join(viral_types)}. "

    prompt = f"""You are an expert viral video editor and content strategist.
Watch this entire video carefully â€” every second matters.

Your task: Identify the TOP {n_clips} most viral-worthy moments in this video.

NICHE: {niche}
{types_note}
CLIP LENGTH: Each clip should be {min_duration}â€“{max_duration} seconds long.

For each moment, consider:
- Sarcasm, irony, unexpected twists
- Emotional peaks (laughter, shock, tears, excitement)
- Visual comedic timing and reaction shots
- Narrative hooks that make viewers stop scrolling
- Quotable one-liners or memorable statements
- Pacing changes â€” sudden fast cuts or dramatic pauses
- The "did he just say that?" factor

Return ONLY a valid JSON array â€” no markdown, no explanation:
[
  {{
    "start": <seconds as float>,
    "end": <seconds as float>,
    "score": <float 1.0-10.0>,
    "hook": "<the opening line or moment that grabs attention>",
    "reason": "<1-2 sentences: why this moment will go viral>",
    "viral_type": "<funny|emotional|shocking|motivational|educational|controversial|satisfying|suspenseful>",
    "emotion": "<dominant emotion the viewer will feel>",
    "clip_title": "<catchy short title for this clip, under 60 chars>"
  }},
  ...
]

Return exactly {n_clips} moments, sorted by score descending (highest first)."""

    file_name = None
    try:
        file_name = _upload_video_to_gemini(video_path, log=_log)
        _log(f"[Gemini] ðŸŽ¬ Analysing video for viral moments...")
        raw = _call_gemini_with_file(file_name, prompt, temperature=0.3)
        moments = _parse_segments_robust(raw, log=_log)

        # Validate and enrich
        valid = []
        for m in moments:
            if not isinstance(m, dict):
                continue
            start = float(m.get("start", 0))
            end   = float(m.get("end", start + 30))
            if end <= start:
                end = start + 30
            valid.append({
                "start":      round(start, 2),
                "end":        round(end, 2),
                "score":      float(m.get("score", 7.0)),
                "hook":       str(m.get("hook", "")),
                "reason":     str(m.get("reason", "")),
                "viral_type": str(m.get("viral_type", "general")),
                "emotion":    str(m.get("emotion", "")),
                "clip_title": str(m.get("clip_title", f"Clip {len(valid)+1}")),
            })

        valid.sort(key=lambda x: x["score"], reverse=True)
        _log(f"[Gemini] âœ… Found {len(valid)} viral moments.")
        return valid[:n_clips]

    finally:
        if file_name:
            _delete_gemini_file(file_name)


def format_viral_moments(moments: list[dict], video_path: str = "") -> str:
    """Format viral moments for display in the UI results box."""
    if not moments:
        return "No viral moments found."

    lines = [
        f"ðŸŽ¬ Gemini found {len(moments)} viral moment(s) in: {Path(video_path).name if video_path else 'video'}",
        "=" * 60,
        "",
    ]
    for i, m in enumerate(moments, 1):
        start = m.get("start", 0)
        end   = m.get("end", 0)
        dur   = end - start
        lines += [
            f"#{i}  ðŸ”¥ Score: {m.get('score', 0):.1f}/10   [{_fmt_ts(start)} â†’ {_fmt_ts(end)}]  ({dur:.0f}s)",
            f"    ðŸ“Œ {m.get('clip_title', '')}",
            f"    ðŸŽ­ Type: {m.get('viral_type', '')}   Emotion: {m.get('emotion', '')}",
            f"    ðŸª Hook: \"{m.get('hook', '')}\"",
            f"    ðŸ’¡ Why: {m.get('reason', '')}",
            "",
        ]
    return "\n".join(lines)


def _fmt_ts(sec: float) -> str:
    m = int(sec // 60)
    s = int(sec % 60)
    return f"{m:02d}:{s:02d}"


# ─────────────────────────────────────────────────────────────────────────────
# 5. Find Viral Moments from Pasted Transcript (text-only, no video upload)
# ─────────────────────────────────────────────────────────────────────────────

import re as _re


def _parse_srt_timestamps(srt_text: str) -> list[dict]:
    """
    Parse SRT file text into list of {start, end, text} dicts.
    Returns empty list if not valid SRT.
    """
    def _ts_to_sec(ts: str) -> float:
        # 00:01:23,456
        ts = ts.strip().replace(",", ".")
        parts = ts.split(":")
        try:
            h, m, s = float(parts[0]), float(parts[1]), float(parts[2])
            return h * 3600 + m * 60 + s
        except Exception:
            return 0.0

    pattern = _re.compile(
        r'\d+\s*\n(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*\n([\s\S]*?)(?=\n\n|\Z)',
        _re.MULTILINE
    )
    results = []
    for m in pattern.finditer(srt_text):
        results.append({
            "start": _ts_to_sec(m.group(1)),
            "end":   _ts_to_sec(m.group(2)),
            "text":  m.group(3).replace("\n", " ").strip(),
        })
    return results


def _estimate_timestamps(plain_text: str, words_per_sec: float = 2.3) -> list[dict]:
    """
    Estimate timestamps from plain text using average speech rate.
    Groups into segments of ~20 words each.
    """
    words = plain_text.split()
    segments, t, chunk = [], 0.0, []
    for w in words:
        chunk.append(w)
        if len(chunk) >= 20:
            dur = len(chunk) / words_per_sec
            segments.append({
                "start": round(t, 2),
                "end":   round(t + dur, 2),
                "text":  " ".join(chunk),
            })
            t += dur
            chunk = []
    if chunk:
        dur = len(chunk) / words_per_sec
        segments.append({"start": round(t, 2), "end": round(t + dur, 2), "text": " ".join(chunk)})
    return segments


NICHE_MOODS = [
    "funny / comedy", "angry / rant", "motivational / inspiring",
    "emotional / sad", "shocking / surprising", "educational",
    "controversial / debate", "satisfying", "suspenseful",
    "romantic", "fitness / gym", "finance / money",
    "gaming", "tech", "food / cooking", "travel",
]


def find_viral_from_transcript(
    transcript_text: str,
    n_clips: int = 5,
    niche: str = "general",
    mood: str = "funny / comedy",
    log=None,
) -> list[dict]:
    """
    Gemini reads the pasted transcript and finds the most viral moments.
    Works with both plain text and SRT (with real timestamps).

    Returns list of dicts with start/end/score/hook/reason/clip_title.
    """
    def _log(m):
        if log: log(m)

    if not transcript_text or not transcript_text.strip():
        raise ValueError("Transcript is empty.")

    # Detect SRT vs plain text
    is_srt = bool(_re.search(r'\d{2}:\d{2}:\d{2}[,\.]\d{3}\s*-->', transcript_text))
    if is_srt:
        segments = _parse_srt_timestamps(transcript_text)
        _log(f"[Gemini] Detected SRT format — {len(segments)} timed segments.")
        # Build a annotated transcript with timestamps for Gemini
        annotated = "\n".join(
            f"[{_fmt_ts(s['start'])}–{_fmt_ts(s['end'])}] {s['text']}"
            for s in segments
        )
        timing_note = (
            "The transcript includes timestamps in [MM:SS–MM:SS] format. "
            "Use these EXACT timestamps for start/end values (in seconds as floats)."
        )
    else:
        segments = _estimate_timestamps(transcript_text)
        _log(f"[Gemini] Plain text — estimated {len(segments)} segments at 2.3 words/sec.")
        annotated = "\n".join(
            f"[{_fmt_ts(s['start'])}–{_fmt_ts(s['end'])}] {s['text']}"
            for s in segments
        )
        timing_note = (
            "Timestamps are estimated from word count at average speech speed. "
            "Use the provided [MM:SS] markers for start/end."
        )

    _log(f"[Gemini] Analysing transcript for {mood} viral moments in {niche} niche...")

    prompt = f"""You are a viral content editor and social media strategist.

Read this transcript carefully and find the TOP {n_clips} most viral-worthy moments.

NICHE: {niche}
TARGET MOOD / VIBE: {mood}

{timing_note}

TRANSCRIPT:
{annotated[:12000]}

For each viral moment, find a continuous passage (not just one line) that would make a great short-form video clip.

Return ONLY a valid JSON array — no markdown, no explanation:
[
  {{
    "start": <start time in seconds as float>,
    "end": <end time in seconds as float>,
    "score": <float 1.0-10.0>,
    "hook": "<the exact opening words from the transcript that grab attention>",
    "reason": "<1-2 sentences: why this specific passage will go viral for {mood} content>",
    "viral_type": "<funny|emotional|shocking|motivational|educational|controversial|satisfying|suspenseful|angry|romantic>",
    "emotion": "<dominant emotion viewers will feel>",
    "clip_title": "<catchy title for this clip, under 60 chars>"
  }},
  ...
]

Sort by score descending. Return exactly {n_clips} moments."""

    _log(f"[Gemini] Sending to {GEMINI_MODEL}...")
    parts = [{"text": prompt}]
    raw   = _call_gemini(parts, temperature=0.3)
    moments = _parse_segments_robust(raw, log=_log)

    valid = []
    for m in moments:
        if not isinstance(m, dict):
            continue
        start = float(m.get("start", 0))
        end   = float(m.get("end", start + 40))
        if end <= start:
            end = start + 40
        valid.append({
            "start":      round(start, 2),
            "end":        round(end, 2),
            "score":      float(m.get("score", 7.0)),
            "hook":       str(m.get("hook", "")),
            "reason":     str(m.get("reason", "")),
            "viral_type": str(m.get("viral_type", "general")),
            "emotion":    str(m.get("emotion", "")),
            "clip_title": str(m.get("clip_title", f"Clip {len(valid)+1}")),
        })

    valid.sort(key=lambda x: x["score"], reverse=True)
    _log(f"[Gemini] ✅ Found {len(valid)} viral moments from transcript.")
    return valid[:n_clips]

