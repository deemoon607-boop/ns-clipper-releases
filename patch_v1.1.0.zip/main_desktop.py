"""
main_desktop.py — Standalone Desktop App Entry Point for NS Clipper (PyQt6 Native)
==================================================================================
Runs the 100% native PyQt6 desktop application for NS Clipper.
No web servers, no local ports, no browsers — instant native startup.
Zero-configuration plug & play — internal FFmpeg binaries injected dynamically into PATH.
"""

import sys
import os
from pathlib import Path

# ── Dynamic Runtime Path & Bundled Binary Environment Setup ──────────────────
if getattr(sys, 'frozen', False):
    APP_DIR = Path(sys.executable).parent
    os.chdir(str(APP_DIR))
    # Elevate APP_DIR to top of sys.path and prioritize loose file finder over FrozenImporter
    if str(APP_DIR) not in sys.path:
        sys.path.insert(0, str(APP_DIR))
    try:
        for i, finder in enumerate(list(sys.meta_path)):
            if 'PathFinder' in getattr(finder, '__name__', str(finder)):
                sys.meta_path.insert(0, sys.meta_path.pop(i))
                break
    except Exception:
        pass
else:
    APP_DIR = Path(__file__).resolve().parent
    os.chdir(str(APP_DIR))

# Forcefully inject internal bundle directories to the top of PATH environment
# This guarantees bundled ffmpeg.exe and ffprobe.exe are always found on any clean PC.
extra_paths = []
if hasattr(sys, '_MEIPASS'):
    extra_paths.append(str(Path(sys._MEIPASS)))
    extra_paths.append(str(Path(sys._MEIPASS) / "bin"))
extra_paths.append(str(APP_DIR / "_internal"))
extra_paths.append(str(APP_DIR / "_internal" / "bin"))
extra_paths.append(str(APP_DIR))
extra_paths.append(str(APP_DIR / "bin"))

curr_path = os.environ.get("PATH", "")
for ep in extra_paths:
    if os.path.exists(ep) and ep not in curr_path:
        curr_path = ep + os.pathsep + curr_path
os.environ["PATH"] = curr_path

# Handle stdout / stderr safely in windowed mode
if sys.stdout is None:
    try:
        sys.stdout = open(APP_DIR / "ns_clipper.log", "a", encoding="utf-8", buffering=1)
    except Exception:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
else:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr is None:
    try:
        sys.stderr = open(APP_DIR / "ns_clipper_err.log", "a", encoding="utf-8", buffering=1)
    except Exception:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")
else:
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

os.environ["PYTHONIOENCODING"] = "utf-8"

import app_qt

def main():
    app_qt.main()

if __name__ == "__main__":
    main()

