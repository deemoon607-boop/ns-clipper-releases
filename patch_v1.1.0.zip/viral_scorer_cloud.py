"""
viral_scorer_cloud.py — Cloud-based Viral Clip Scoring
=======================================================
Uses Groq, Gemini, OpenAI, Claude, DeepSeek, or local heuristic NLP engine.
Same output format as viral_scorer.py — all downstream code unchanged.

Supports multiple API keys with automatic rotation on rate limits and failover.
"""

import json
import re
import time
import random
import urllib.request
from dataclasses import dataclass, asdict
from typing import Optional

from transcribe import TranscriptResult, Segment, fmt_time
import config as cfg

# ── Provider → Model mapping for cascading dropdowns ─────────────────────────

PROVIDER_MODELS = {
    "Google Gemini": [
        "Gemini 2.5 Flash (Google Fast ⚡)",
        "Gemini 2.0 Flash (Recommended)",
        "Gemini 1.5 Flash (Stable)",
    ],
    "Groq Cloud": [
        "Llama 3.3 70B Versatile",
        "Llama 3.1 8B Instant",
        "Qwen 3.8 27B (Groq Fast ⚡)",
        "Groq Compound AI (Ultra Smart ⚡)",
        "GPT-OSS 120B (Groq High Cap ⚡)",
        "GPT-OSS 20B (Groq Instant ⚡)",
        "Qwen 3.6 27B (Groq Reasoning ⚡)",
    ],
    "OpenAI": [
        "GPT-5.6 Sol (Flagship Intelligence)",
        "GPT-5.6 Terra (Balanced Production)",
        "GPT-5.6 Luna (High-Throughput & Low-Cost)",
        "GPT-4o (Multimodal Standard)",
    ],
    "Anthropic Claude": [
        "Claude Sonnet 5 (Frontier Reasoning & Hooks)",
        "Claude Opus 5 (Deep Analysis Flagship)",
        "Claude Fable 5 (Long-Horizon Logic)",
        "Claude 3.5 Sonnet (Creator Standard)",
    ],
    "DeepSeek": [
        "DeepSeek-V3 (deepseek-chat - High Intelligence / Low Cost)",
        "DeepSeek-R1 (deepseek-reasoner - Chain-of-Thought)",
    ],
    "Local / Offline": [
        "Local Smart AI Scorer (Offline 🛡️)",
    ],
}

# Keys are what the user sees in UI dropdowns.
# Values are (backend, actual_api_model_id)

MODEL_ROUTES = {
    # ── Google Gemini ────────────────────────────────────────────────────────
    "Gemini 2.5 Flash (Google Fast ⚡)":                          ("gemini",   "gemini-2.5-flash"),
    "Gemini 2.0 Flash (Recommended)":                            ("gemini",   "gemini-2.0-flash"),
    "Gemini 1.5 Flash (Stable)":                                 ("gemini",   "gemini-1.5-flash"),
    # ── Groq Cloud ───────────────────────────────────────────────────────────
    "Llama 3.3 70B Versatile":                                   ("groq",     "llama-3.3-70b-versatile"),
    "Llama 3.1 8B Instant":                                      ("groq",     "llama-3.1-8b-instant"),
    "Qwen 3.8 27B (Groq Fast ⚡)":                                ("groq",     "qwen/qwen3.8-27b"),
    "Groq Compound AI (Ultra Smart ⚡)":                          ("groq",     "groq/compound-mini"),
    "GPT-OSS 120B (Groq High Cap ⚡)":                             ("groq",     "openai/gpt-oss-120b"),
    "GPT-OSS 20B (Groq Instant ⚡)":                              ("groq",     "openai/gpt-oss-20b"),
    "Qwen 3.6 27B (Groq Reasoning ⚡)":                           ("groq",     "qwen/qwen3.6-27b"),
    # ── OpenAI ───────────────────────────────────────────────────────────────
    "GPT-5.6 Sol (Flagship Intelligence)":                       ("openai",   "gpt-5.6-sol"),
    "GPT-5.6 Terra (Balanced Production)":                       ("openai",   "gpt-5.6-terra"),
    "GPT-5.6 Luna (High-Throughput & Low-Cost)":                 ("openai",   "gpt-5.6-luna"),
    "GPT-4o (Multimodal Standard)":                              ("openai",   "gpt-4o"),
    # ── Anthropic Claude ─────────────────────────────────────────────────────
    "Claude Sonnet 5 (Frontier Reasoning & Hooks)":              ("claude",   "claude-sonnet-5"),
    "Claude Opus 5 (Deep Analysis Flagship)":                    ("claude",   "claude-opus-5"),
    "Claude Fable 5 (Long-Horizon Logic)":                       ("claude",   "claude-fable-5"),
    "Claude 3.5 Sonnet (Creator Standard)":                      ("claude",   "claude-3-5-sonnet-20241022"),
    # ── DeepSeek ─────────────────────────────────────────────────────────────
    "DeepSeek-V3 (deepseek-chat - High Intelligence / Low Cost)":("deepseek", "deepseek-chat"),
    "DeepSeek-R1 (deepseek-reasoner - Chain-of-Thought)":        ("deepseek", "deepseek-reasoner"),
    # ── Local Heuristic ──────────────────────────────────────────────────────
    "Local Smart AI Scorer (Offline 🛡️)":                         ("local",    "heuristic"),
}

UI_MODEL_NAMES = [m for mlist in PROVIDER_MODELS.values() for m in mlist]


# ─────────────────────────────────────────────────────────────────────────────
# Data structures (identical to viral_scorer.py)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ClipCandidate:
    rank: int
    start: float
    end: float
    duration: float
    score: float
    title: str
    hook: str
    reasoning: str
    transcript_text: str

    def time_range(self) -> str:
        return f"{fmt_time(self.start)} --> {fmt_time(self.end)}"

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
# Key rotation helpers
# ─────────────────────────────────────────────────────────────────────────────

class KeyRotator:
    """Cycles through a list of API keys, moving to the next on rate-limit errors."""

    def __init__(self, keys: list[str]):
        clean = []
        for k in keys:
            if not k:
                continue
            sk = str(k).strip().replace("\r", "").replace("\n", "").replace("\t", "").replace('"', '').replace("'", "")
            if sk and sk not in clean:
                clean.append(sk)
        self.keys = clean
        self._idx = 0

    def __len__(self):
        return len(self.keys)

    def current(self) -> str:
        if not self.keys:
            raise ValueError("No API keys configured. Please add keys in Settings.")
        return self.keys[self._idx % len(self.keys)]

    def rotate(self):
        self._idx = (self._idx + 1) % max(len(self.keys), 1)
        return self.current()

    def try_call(self, fn, max_retries: int = None):
        """
        Call fn(key) cycling through all keys on rate-limit errors.
        fn should be a callable that accepts an API key string.
        """
        if not self.keys:
            raise ValueError("No API keys configured.")

        max_retries = max_retries or len(self.keys)
        last_error = None

        for attempt in range(max_retries):
            key = self.current()
            try:
                return fn(key)
            except Exception as e:
                err = str(e).lower()
                if any(x in err for x in ["rate", "limit", "quota", "429", "exhausted", "413", "tokens"]):
                    print(f"[KeyRotator] Key {self._idx+1} hit rate limit, rotating...")
                    self.rotate()
                    time.sleep(1)
                    last_error = e
                else:
                    raise

        raise RuntimeError(f"All {len(self.keys)} keys exhausted. Last error: {last_error}")


# ─────────────────────────────────────────────────────────────────────────────
# Prompts
# ─────────────────────────────────────────────────────────────────────────────

_DYNAMIC_SMART_HOOK_PROMPT = """You are an elite short-form video viral clip curator and editor for TikTok, YouTube Shorts, and Instagram Reels.
Your mission is to extract the HIGHEST-RETENTION viral moments using the pure "HOOK-TO-CLIMAX" narrative arc.

CRITICAL RULES — STRICT DYNAMIC DURATION & ZERO DURATION BIAS:
1. DURATION IS 100% VARIABLE (12s to 120s+):
   - Extract clips STRICTLY based on the natural length of the hook and conclusion. A clip can be 12s, 18s, 27s, 40s, or 75s.
   - NEVER force or round clips to match a fixed duration like 45s, 55s, or 60s. Any fixed duration bias is strictly prohibited.
   - If a killer insight, hilarious joke, or punchy revelation takes only 12 to 20 seconds, output EXACTLY that duration.
   - If a deep story or explanation takes 45s–90s+ (up to {max_dur}s), preserve the full context without cutting early.
   - NEVER add extra filler sentences before or after just to make a clip longer.

2. THE "HOOK-TO-CLIMAX" EXTRACTION FRAMEWORK:
   - Exact Start (The Hook): Start precisely at the word/sentence where the curiosity gap, controversial claim, shocking question, or punchy statement begins. Strip out conversational filler.
   - Exact End (The Punchline / Climax): Identify the exact sentence where the speaker's core claim/insight ends, and set `end` immediately at that closing word. Do NOT drag into the next conversational topic.
   - Micro-Hooks Allowed: If a punchy moment is 12–25 seconds long, output that exact natural window.

3. VIRALITY SCORING & HOOK EXPLANATION:
   - "score": Virality rating from 1.0 to 10.0 (be selective, 9+ for top-tier master hooks).
   - "title": Punchy, high-CTR 6-10 word title.
   - "hook": 1-sentence description of the opening retention hook.
   - "reasoning": 2 sentences explaining why this cut hooks and retains viewers

CRITICAL JSON OUTPUT REQUIREMENT:
Return ONLY a valid, parseable JSON array. No markdown wraps, no reasoning text outside JSON.
Example format:
[
  {
    "start": 12.4,
    "end": 44.8,
    "score": 9.4,
    "title": "Why 99% Of People Fail At This",
    "hook": "Stop doing this one mistake right now.",
    "reasoning": "Opens with an immediate pattern interrupt and delivers the punchline cleanly at 44.8s."
  }
]"""

_FIXED_DURATION_PROMPT = """You are an elite short-form video editor for TikTok, YouTube Shorts, and Instagram Reels.
Find the top viral moments in this transcript around {clip_dur}s in duration.
Return a valid JSON array of objects with:
- "start": start time in seconds (float)
- "end": end time in seconds (float)
- "score": virality score from 1.0 to 10.0 (float)
- "title": punchy high-CTR title
- "hook": 1-sentence description of why the opening hooks viewers
- "reasoning": 2-3 sentences explaining why it is viral

Return ONLY a valid JSON array. No text before or after.
Example:
[
  {
    "start": 12.4,
    "end": 58.2,
    "score": 9.2,
    "title": "Why Most People Fail At This",
    "hook": "Opens with a counterintuitive statement that grabs attention immediately",
    "reasoning": "2-3 sentences explaining why it is viral"
  },
  ...
]"""

_BATCH_TEMPLATE = """Analyze these {n} video transcript segments for viral potential. For each segment, provide the exact matching video title, a strong 1-sentence hook, virality score, and brief reasoning.

{segs}

Return a JSON array of exactly {n} objects in the same order:
[
  {{
    "index": 0,
    "title": "Exact Catchy Video Title Matching The Segment",
    "score": 8.5,
    "hook": "One-sentence attention hook",
    "reasoning": "2-3 sentences explaining why it is viral"
  }},
  ...
]"""


# ─────────────────────────────────────────────────────────────────────────────
# Backend call implementations
# ─────────────────────────────────────────────────────────────────────────────

def _normalize_groq_model(model_name: str) -> str:
    m = model_name.lower().strip()
    if "3.3" in m or "70b" in m or "llama-3.3" in m:
        return "llama-3.3-70b-versatile"
    if "3.1" in m or "8b" in m or "instant" in m:
        return "llama-3.1-8b-instant"
    if "compound" in m:
        return "groq/compound-mini"
    if "3.6" in m:
        return "qwen/qwen3.6-27b"
    if "qwen" in m or "3.8" in m:
        return "qwen/qwen3.8-27b"
    if "120" in m:
        return "openai/gpt-oss-120b"
    if "20" in m:
        return "openai/gpt-oss-20b"
    return "llama-3.3-70b-versatile"


def _call_groq(key: str, api_model: str, messages: list[dict]) -> str:
    from groq import Groq
    key = str(key).strip().replace("\r", "").replace("\n", "").replace('"', '').replace("'", "")
    api_model = _normalize_groq_model(api_model)
    client = Groq(api_key=key, timeout=25.0)

    models_to_try = [api_model]
    for fallback in ["llama-3.3-70b-versatile", "groq/compound-mini", "qwen/qwen3.8-27b", "openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.6-27b", "llama-3.1-8b-instant"]:
        if fallback not in models_to_try:
            models_to_try.append(fallback)

    last_err = None
    for model_id in models_to_try:
        try:
            resp = client.chat.completions.create(
                model=model_id,
                messages=messages,
                temperature=0.2,
                max_tokens=3000,
            )
            content = (resp.choices[0].message.content or "").strip()
            if not content:
                continue
            _parse_json_response(content)
            return content
        except Exception as e:
            last_err = e
            err_str = str(e).lower()
            if "429" in err_str or "rate" in err_str:
                time.sleep(1.5)
            continue
    raise last_err or RuntimeError("Groq models returned empty content.")


def _call_gemini(key: str, api_model: str, messages: list[dict]) -> str:
    key = str(key).strip().replace("\r", "").replace("\n", "").replace('"', '').replace("'", "")
    system = next((m["content"] for m in messages if m["role"] == "system"), "")
    user   = next((m["content"] for m in messages if m["role"] == "user"), "")
    full   = f"{system}\n\n{user}" if system else user

    norm_model = "gemini-2.5-flash"
    if "2.0" in api_model:
        norm_model = "gemini-2.0-flash"
    elif "1.5" in api_model:
        norm_model = "gemini-1.5-flash"
    elif "2.5" in api_model:
        norm_model = "gemini-2.5-flash"

    models_to_try = [norm_model, "gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-flash-8b", "gemini-1.5-pro"]
    last_err = None
    for mid in models_to_try:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{mid}:generateContent?key={key}"
            body = {
                "contents": [{"role": "user", "parts": [{"text": full}]}],
                "generationConfig": {
                    "temperature": 0.2,
                    "maxOutputTokens": 4096,
                }
            }
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=30) as r:
                res_data = json.loads(r.read().decode("utf-8"))
                text = res_data["candidates"][0]["content"]["parts"][0]["text"].strip()
                if text:
                    _parse_json_response(text)
                    return text
        except Exception as e:
            last_err = e

        try:
            from google import genai
            client = genai.Client(api_key=key)
            resp   = client.models.generate_content(model=mid, contents=full)
            text = (resp.text or "").strip()
            if text:
                _parse_json_response(text)
                return text
        except Exception as e:
            last_err = e
            continue

    raise last_err or RuntimeError("Gemini cloud models unavailable.")


def _call_openai(key: str, api_model: str, messages: list[dict]) -> str:
    key = str(key).strip().replace("\r", "").replace("\n", "").replace('"', '').replace("'", "")
    url = "https://api.openai.com/v1/chat/completions"
    models_to_try = [api_model]
    for fb in ["gpt-4o", "gpt-4-turbo"]:
        if fb not in models_to_try:
            models_to_try.append(fb)

    last_err = None
    for mid in models_to_try:
        try:
            body = {
                "model": mid,
                "messages": messages,
                "temperature": 0.2,
                "max_tokens": 3000,
            }
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                url, data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {key}"
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=35) as r:
                res_data = json.loads(r.read().decode("utf-8"))
                content = res_data["choices"][0]["message"]["content"].strip()
                if content:
                    _parse_json_response(content)
                    return content
        except Exception as e:
            last_err = e
            continue
    raise last_err or RuntimeError("OpenAI models returned empty content.")


def _call_claude(key: str, api_model: str, messages: list[dict]) -> str:
    key = str(key).strip().replace("\r", "").replace("\n", "").replace('"', '').replace("'", "")
    url = "https://api.anthropic.com/v1/messages"
    system_msg = next((m["content"] for m in messages if m["role"] == "system"), "")
    user_msgs = [m for m in messages if m["role"] != "system"]
    if not user_msgs:
        user_msgs = [{"role": "user", "content": system_msg}]
        system_msg = ""

    models_to_try = [api_model, "claude-3-5-sonnet-20241022", "claude-3-5-sonnet-latest"]
    last_err = None
    for mid in models_to_try:
        try:
            body = {
                "model": mid,
                "max_tokens": 3500,
                "messages": user_msgs,
            }
            if system_msg:
                body["system"] = system_msg
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                url, data=data,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": key,
                    "anthropic-version": "2023-06-01"
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=35) as r:
                res_data = json.loads(r.read().decode("utf-8"))
                parts = res_data.get("content", [])
                text = "".join(p.get("text", "") for p in parts if p.get("type") == "text").strip()
                if text:
                    _parse_json_response(text)
                    return text
        except Exception as e:
            last_err = e
            continue
    raise last_err or RuntimeError("Anthropic Claude models returned empty content.")


def _call_deepseek(key: str, api_model: str, messages: list[dict]) -> str:
    key = str(key).strip().replace("\r", "").replace("\n", "").replace('"', '').replace("'", "")
    url = "https://api.deepseek.com/chat/completions"
    models_to_try = [api_model, "deepseek-chat", "deepseek-reasoner"]
    last_err = None
    for mid in models_to_try:
        try:
            body = {
                "model": mid,
                "messages": messages,
                "temperature": 0.2,
                "max_tokens": 3500,
            }
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                url, data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {key}"
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=35) as r:
                res_data = json.loads(r.read().decode("utf-8"))
                content = res_data["choices"][0]["message"]["content"].strip()
                if content:
                    _parse_json_response(content)
                    return content
        except Exception as e:
            last_err = e
            continue
    raise last_err or RuntimeError("DeepSeek models returned empty content.")


def _clean_str(text: str) -> str:
    if not isinstance(text, str):
        return str(text)
    return (
        text.replace("\u2011", "-")
            .replace("\u2012", "-")
            .replace("\u2013", "-")
            .replace("\u2014", "--")
            .replace("\u2018", "'")
            .replace("\u2019", "'")
            .replace("\u201c", '"')
            .replace("\u201d", '"')
            .replace("\u2026", "...")
    )


def _parse_json_response(raw: str) -> list[dict]:
    """Extract JSON array from LLM response robustly, stripping any think tags or markdown blocks."""
    cleaned = _clean_str(raw)
    cleaned = re.sub(r"<think>.*?</think>", "", cleaned, flags=re.DOTALL).strip()
    cleaned = re.sub(r"<reasoning>.*?</reasoning>", "", cleaned, flags=re.DOTALL).strip()
    
    # 1. Try markdown json code block
    code_block = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", cleaned, re.DOTALL)
    if code_block:
        try:
            return json.loads(code_block.group(1))
        except Exception:
            pass
            
    # 2. Try raw json array [ ... ]
    match = re.search(r"\[\s*\{.*?\}\s*\]", cleaned, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except Exception:
            pass

    # 3. Try single json object { "start": ... }
    obj_match = re.search(r"\{\s*\"start\".*?\}", cleaned, re.DOTALL)
    if obj_match:
        try:
            return [json.loads(obj_match.group())]
        except Exception:
            pass

    # 4. Fallback search
    match = re.search(r"\[.*\]", cleaned, re.DOTALL)
    if not match:
        raise ValueError(f"No JSON array found in response:\n{cleaned[:300]}")
    return json.loads(match.group())


# ─────────────────────────────────────────────────────────────────────────────
# Local Smart NLP Heuristic Scorer (Offline / Zero-Key Engine)
# ─────────────────────────────────────────────────────────────────────────────

def _score_heuristic_local(
    result: TranscriptResult,
    clip_dur: float,
    min_dur: float,
    max_dur: float,
    top_n: int = 5,
    dynamic_hook_mode: bool = True
) -> list[ClipCandidate]:
    if not result or not result.segments:
        return []

    VIRAL_HOOK_TRIGGERS = [
        "secret", "nobody tells you", "never", "always", "the truth about", "mistake",
        "shocking", "insane", "how to", "why you should", "stop doing", "money",
        "changed my life", "listen to this", "what happens if", "do not", "the real reason",
        "incredible", "crazy", "number one", "first thing", "biggest problem", "watch this",
        "actually", "everyone thinks", "guaranteed", "you won't believe"
    ]

    candidates = []
    total_dur = result.duration
    target_dur = max(min_dur, min(max_dur, clip_dur if clip_dur > 0 else 35.0))

    for i, seg in enumerate(result.segments):
        txt = seg.text.strip().lower()
        score = 6.8
        
        for trig in VIRAL_HOOK_TRIGGERS:
            if trig in txt:
                score += 1.6
                break
        
        if "?" in seg.text:
            score += 0.8
        if "!" in seg.text:
            score += 0.5
        
        seg_dur = max(0.5, seg.end - seg.start)
        words_count = len(seg.text.split())
        wps = words_count / seg_dur
        if wps > 2.1:
            score += 0.6

        start_t = seg.start
        end_t = min(total_dur, start_t + target_dur)
        
        for s in result.segments[i:]:
            if s.end >= start_t + min_dur:
                end_t = s.end
                if s.end >= start_t + target_dur or (s.end - start_t) >= max_dur:
                    break
        
        actual_dur = end_t - start_t
        if actual_dur < min_dur * 0.8 or actual_dur > max_dur * 1.2:
            continue

        clip_texts = [s.text.strip() for s in result.segments if s.start >= start_t and s.end <= end_t]
        full_clip_text = " ".join(clip_texts)

        first_sentence = seg.text.strip().split(".")[0].split("?")[0].strip()
        title = f"{first_sentence.title()[:45]}" if first_sentence else f"Viral Moment #{int(start_t)}s"
        hook_desc = f"Opens with high-curiosity hook: \"{first_sentence[:60]}...\""

        candidates.append(ClipCandidate(
            rank=0,
            start=round(start_t, 2),
            end=round(end_t, 2),
            duration=round(actual_dur, 2),
            score=round(min(10.0, score), 1),
            title=title,
            hook=hook_desc,
            reasoning="Strong rhetorical opening, dense pacing, and clear climactic insight.",
            transcript_text=full_clip_text
        ))

    unique_cand = _deduplicate(candidates, min_gap=8.0)
    unique_cand.sort(key=lambda x: -x.score)
    final_clips = unique_cand[:top_n]
    for idx, c in enumerate(final_clips):
        c.rank = idx + 1
    return final_clips


def _build_windows(result: TranscriptResult, clip_duration: float, step_ratio: float = 0.5) -> list[dict]:
    step = clip_duration * step_ratio
    total = result.duration
    windows = []
    t = 0.0
    while t < total - clip_duration * 0.4:
        win_end = min(t + clip_duration, total)
        words = []
        for seg in result.segments:
            for w in seg.words:
                if w.start >= t and w.end <= win_end:
                    words.append(w.word)
            if not seg.words and seg.end >= t and seg.start <= win_end:
                words.append(seg.text.strip())
        text = " ".join(words).strip()
        if len(text) > 30:
            windows.append({"start": round(t, 2), "end": round(win_end, 2), "text": text})
        t += step
    return windows


def _snap_to_transcript_boundaries(st: float, et: float, segments: list) -> tuple[float, float]:
    if not segments:
        return round(st, 2), round(et, 2)

    best_st = st
    min_st_diff = 4.0
    for s in segments:
        s_start = getattr(s, 'start', s.get('start', 0) if isinstance(s, dict) else 0)
        diff = abs(s_start - st)
        if diff < min_st_diff:
            min_st_diff = diff
            best_st = s_start

    best_et = et
    min_et_diff = 4.0
    for s in segments:
        s_end = getattr(s, 'end', s.get('end', 0) if isinstance(s, dict) else 0)
        diff = abs(s_end - et)
        if diff < min_et_diff:
            min_et_diff = diff
            best_et = s_end

    if best_et <= best_st:
        best_et = best_st + max(5.0, et - st)

    return round(best_st, 2), round(best_et, 2)


def _deduplicate(candidates: list[ClipCandidate], min_gap: float = 5.0) -> list[ClipCandidate]:
    kept = []
    for c in sorted(candidates, key=lambda x: -x.score):
        overlap = any(
            min(c.end, k.end) - max(c.start, k.start) > min_gap
            for k in kept
        )
        if not overlap:
            kept.append(c)
    return kept


# ─────────────────────────────────────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────────────────────────────────────

def score_viral_clips_cloud(
    result: TranscriptResult,
    ui_model_name: str = "Gemini 2.5 Flash (Google Fast ⚡)",
    clip_duration: float = 60.0,
    top_n: int = 5,
    auto_mode: bool = False,
    dynamic_hook_mode: bool = True,
    min_dur: float = 10.0,
    max_dur: float = 300.0,
    user_prompt: str = "",
    batch_size: int = 6,
    min_score: float = 5.0,
    groq_keys: list[str] = None,
    gemini_keys: list[str] = None,
    openai_keys: list[str] = None,
    claude_keys: list[str] = None,
    deepseek_keys: list[str] = None,
    progress_cb=None,
) -> list[ClipCandidate]:
    """
    Cloud-based viral scoring across Gemini, Groq, OpenAI, Claude, DeepSeek & Local NLP.
    """
    def log(msg):
        clean_msg = _clean_str(str(msg))
        try:
            print(clean_msg)
        except Exception:
            pass
        if progress_cb:
            try:
                progress_cb(clean_msg)
            except Exception:
                pass

    if not result or not result.segments:
        raise ValueError("Transcript contains 0 segments. Please transcribe a valid video first.")

    # Resolve model name to backend + model id
    if ui_model_name not in MODEL_ROUTES:
        for k in MODEL_ROUTES:
            if any(term in ui_model_name.lower() for term in ("gemini", "groq", "openai", "claude", "deepseek", "llama", "qwen", "gpt")):
                if k.lower() in ui_model_name.lower() or ui_model_name.lower() in k.lower():
                    ui_model_name = k
                    break
        if ui_model_name not in MODEL_ROUTES:
            ui_model_name = list(MODEL_ROUTES.keys())[0]

    backend, api_model = MODEL_ROUTES[ui_model_name]

    if backend == "local":
        log("🛡️ Running Local Smart AI Scorer (Offline NLP Engine)...")
        return _score_heuristic_local(result, clip_duration, min_dur, max_dur, top_n, dynamic_hook_mode)

    # Key lists
    g_keys = [k.strip() for k in (groq_keys if groq_keys is not None else cfg.get_groq_keys()) if k.strip()]
    m_keys = [k.strip() for k in (gemini_keys if gemini_keys is not None else cfg.get_gemini_keys()) if k.strip()]
    o_keys = [k.strip() for k in (openai_keys if openai_keys is not None else cfg.get_openai_keys()) if k.strip()]
    c_keys = [k.strip() for k in (claude_keys if claude_keys is not None else cfg.get_anthropic_keys()) if k.strip()]
    d_keys = [k.strip() for k in (deepseek_keys if deepseek_keys is not None else cfg.get_deepseek_keys()) if k.strip()]

    # Smart auto-switch if user selected backend without keys
    active_keys = []
    if backend == "gemini":
        active_keys = m_keys
    elif backend == "groq":
        active_keys = g_keys
    elif backend == "openai":
        active_keys = o_keys
    elif backend == "claude":
        active_keys = c_keys
    elif backend == "deepseek":
        active_keys = d_keys

    if not active_keys:
        if m_keys:
            log(f"[Info] No {backend} key found -> Auto-switching to Gemini Cloud...")
            backend, api_model, active_keys = "gemini", "gemini-3.5-flash", m_keys
        elif g_keys:
            log(f"[Info] No {backend} key found -> Auto-switching to Groq Cloud...")
            backend, api_model, active_keys = "groq", "llama-3.3-70b-versatile", g_keys
        elif o_keys:
            log(f"[Info] No {backend} key found -> Auto-switching to OpenAI...")
            backend, api_model, active_keys = "openai", "gpt-4o", o_keys
        elif c_keys:
            log(f"[Info] No {backend} key found -> Auto-switching to Claude...")
            backend, api_model, active_keys = "claude", "claude-3-5-sonnet-20241022", c_keys
        elif d_keys:
            log(f"[Info] No {backend} key found -> Auto-switching to DeepSeek...")
            backend, api_model, active_keys = "deepseek", "deepseek-chat", d_keys

    if not active_keys:
        log("[Notice] No cloud API keys configured -> Running Local Smart AI Scorer (Offline Engine)...")
        return _score_heuristic_local(result, clip_duration, min_dur, max_dur, top_n, dynamic_hook_mode)

    rotator = KeyRotator(active_keys)
    if backend == "gemini":
        call_fn = lambda key, msgs: _call_gemini(key, api_model, msgs)
    elif backend == "groq":
        call_fn = lambda key, msgs: _call_groq(key, api_model, msgs)
    elif backend == "openai":
        call_fn = lambda key, msgs: _call_openai(key, api_model, msgs)
    elif backend == "claude":
        call_fn = lambda key, msgs: _call_claude(key, api_model, msgs)
    elif backend == "deepseek":
        call_fn = lambda key, msgs: _call_deepseek(key, api_model, msgs)
    else:
        return _score_heuristic_local(result, clip_duration, min_dur, max_dur, top_n, dynamic_hook_mode)

    mode_label = "⚡ AI Smart Dynamic Hook" if dynamic_hook_mode else f"⏱️ Fixed Duration (~{int(clip_duration)}s)"
    log(f"⚡ Fast AI Scoring: {ui_model_name} | Mode: {mode_label} | Allowed: {int(min_dur)}s–{int(max_dur)}s | {len(rotator)} key(s) active")

    lines = []
    for s in result.segments:
        m, sec = divmod(int(s.start), 60)
        lines.append(f"[{m:02d}:{sec:02d}] {s.text.strip()}")
    transcript_outline = "\n".join(lines)

    candidates = []
    if len(transcript_outline) < 40000:
        log("🚀 Running Single-Pass Instant Viral Hook Discovery across entire video...")
        if dynamic_hook_mode:
            base_prompt = _DYNAMIC_SMART_HOOK_PROMPT.format(max_dur=int(max_dur))
        else:
            base_prompt = _GLOBAL_DISCOVERY_PROMPT.format(clip_dur=int(clip_duration), min_dur=int(min_dur), max_dur=int(max_dur))
        
        if user_prompt and user_prompt.strip():
            base_prompt += f"\n\nUSER PRIORITY INSTRUCTIONS: {user_prompt.strip()}"

        prompt_text = f"{base_prompt}\n\nTRANSCRIPT WITH TIMESTAMPS:\n{transcript_outline}"
        messages = [{"role": "user", "content": prompt_text}]

        try:
            raw = rotator.try_call(lambda key: call_fn(key, messages))
            results = _parse_json_response(raw)
            for r in results:
                st = float(r.get("start", 0))
                raw_end = r.get("end")
                if raw_end is not None and float(raw_end) > st:
                    et = float(raw_end)
                else:
                    et = st + 20.0
                    for s in result.segments:
                        s_st = getattr(s, 'start', s.get('start', 0) if isinstance(s, dict) else 0)
                        s_et = getattr(s, 'end', s.get('end', 0) if isinstance(s, dict) else 0)
                        if s_st <= st <= s_et:
                            et = s_et
                            break

                st, et = _snap_to_transcript_boundaries(st, et, result.segments)
                dur = et - st
                sc = float(r.get("score", 7.5))
                if sc > 10.0 and sc <= 100.0:
                    sc = sc / 10.0
                elif 0.0 < sc <= 1.0:
                    sc = sc * 10.0

                if dur >= max(6.0, min_dur * 0.7) and dur <= (max_dur * 1.3):
                    candidates.append(ClipCandidate(
                        rank=0,
                        start=round(st, 2),
                        end=round(et, 2),
                        duration=round(dur, 2),
                        score=round(min(10.0, max(1.0, sc)), 1),
                        title=_clean_str(r.get("title", f"Viral Moment #{st:.0f}s")).strip(),
                        hook=_clean_str(r.get("hook", "")).strip(),
                        reasoning=_clean_str(r.get("reasoning", "")).strip(),
                        transcript_text=_clean_str(r.get("transcript_text", "")).strip(),
                    ))
            if candidates:
                log(f"✓ Single-Pass Dynamic Discovery extracted {len(candidates)} high-potential candidates in 1 shot!")
        except Exception as se:
            log(f"[Single-Pass notice] {_clean_str(str(se))} — Evaluating windowed scan / local engine...")
            candidates = []

    if not candidates:
        log(f"Building clip windows ({clip_duration}s each)...")
        windows = _build_windows(result, clip_duration)
        log(f"{len(windows)} candidate windows to evaluate")

        all_scores = []
        n_batches = (len(windows) + batch_size - 1) // batch_size

        for bi in range(n_batches):
            batch = windows[bi * batch_size:(bi + 1) * batch_size]
            log(f"Analyzing batch {bi+1}/{n_batches} ({len(batch)} clips)...")

            segs_json = json.dumps([
                {"index": i, "start": fmt_time(w["start"]), "end": fmt_time(w["end"]),
                 "text": w["text"][:300]}
                for i, w in enumerate(batch)
            ], indent=2)

            messages = [
                {"role": "user", "content": _BATCH_TEMPLATE.format(n=len(batch), segs=segs_json)},
            ]

            try:
                raw = rotator.try_call(lambda key: call_fn(key, messages))
                results = _parse_json_response(raw)
                for r in results:
                    idx = r.get("index", 0)
                    if 0 <= idx < len(batch):
                        exact_title = (r.get("title") or r.get("clip_title") or r.get("headline") or "").strip()
                        if not exact_title:
                            hook_txt = r.get("hook", "").strip()
                            exact_title = hook_txt.split(".")[0].split("?")[0] if hook_txt else f"Viral Moment #{idx+1}"
                        
                        sc = float(r.get("score", 7.5))
                        if sc > 10.0 and sc <= 100.0:
                            sc = sc / 10.0
                        elif 0.0 < sc <= 1.0:
                            sc = sc * 10.0

                        all_scores.append({
                            "window": batch[idx],
                            "score": round(min(10.0, max(1.0, sc)), 1),
                            "title": _clean_str(exact_title),
                            "hook": _clean_str(r.get("hook", "")),
                            "reasoning": _clean_str(r.get("reasoning", "")),
                        })
            except Exception as e:
                log(f"[Warning] Batch {bi+1} scoring error: {e}")
                for w in batch:
                    all_scores.append({
                        "window": w, "score": 6.5,
                        "title": f"Moment #{int(w['start'])}s",
                        "hook": w["text"][:60], "reasoning": "Batch fallback scoring"
                    })

        for s in all_scores:
            w = s["window"]
            st, et = _snap_to_transcript_boundaries(w["start"], w["end"], result.segments)
            dur = et - st
            candidates.append(ClipCandidate(
                rank=0,
                start=round(st, 2),
                end=round(et, 2),
                duration=round(dur, 2),
                score=s["score"],
                title=s["title"],
                hook=s["hook"],
                reasoning=s["reasoning"],
                transcript_text=w["text"],
            ))

    unique_cand = _deduplicate(candidates, min_gap=6.0)
    unique_cand.sort(key=lambda x: -x.score)

    if auto_mode:
        final_clips = [c for c in unique_cand if c.score >= min_score]
        if not final_clips:
            final_clips = unique_cand[:top_n]
    else:
        final_clips = unique_cand[:top_n]

    for idx, c in enumerate(final_clips):
        c.rank = idx + 1

    log(f"\n[DONE] Discovered {len(final_clips)} viral moments!")
    return final_clips
