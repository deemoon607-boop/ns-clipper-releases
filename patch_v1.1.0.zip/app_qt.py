"""
app_qt.py — Native PyQt6 Desktop User Interface for NS Clipper
================================================================
A 100% native PyQt6 desktop application matching the modern, clean,
and premium design of the reference interface.

Features:
- Pure PyQt6 native widgets (No browser / No Gradio / No local web server)
- Non-blocking async worker threads (QThread) with live status updates
- Responsive dual-column card layout with custom Qt Style Sheets (QSS)
- Light & Dark theme toggle
- Hardware-locked license verification and instant startup
"""

import os
import sys
import json
import time
import shutil
import subprocess
import webbrowser
import cv2
import numpy as np
from pathlib import Path
from typing import Optional, List, Dict

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QComboBox, QSlider, QCheckBox,
    QTextEdit, QPlainTextEdit, QFileDialog, QScrollArea, QFrame,
    QStackedWidget, QRadioButton, QButtonGroup, QProgressBar, QSizePolicy,
    QGraphicsDropShadowEffect, QSplitter
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QSize, QTimer, QUrl, QPoint
)
from PyQt6.QtGui import (
    QFont, QIcon, QColor, QPixmap, QImage, QPainter, QLinearGradient,
    QBrush, QPen, QCursor, QFontDatabase
)
from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput

# ── Dynamic Runtime Path & Resource Resolver ─────────────────────────────────
def get_resource_path(relative_path: str) -> Path:
    """Finds resource relative_path across PyInstaller _MEIPASS, _internal, exe dir, or source dir."""
    if hasattr(sys, '_MEIPASS'):
        p = Path(sys._MEIPASS) / relative_path
        if p.exists():
            return p
    if getattr(sys, 'frozen', False):
        exe_dir = Path(sys.executable).parent
        p = exe_dir / "_internal" / relative_path
        if p.exists():
            return p
        p = exe_dir / relative_path
        if p.exists():
            return p
    p = Path(__file__).resolve().parent / relative_path
    return p


# Forcefully inject internal bundle directories to the top of PATH environment
extra_paths = []
if hasattr(sys, '_MEIPASS'):
    extra_paths.append(str(Path(sys._MEIPASS)))
    extra_paths.append(str(Path(sys._MEIPASS) / "bin"))
if getattr(sys, 'frozen', False):
    app_exe_dir = Path(sys.executable).parent
    extra_paths.append(str(app_exe_dir / "_internal"))
    extra_paths.append(str(app_exe_dir / "_internal" / "bin"))
    extra_paths.append(str(app_exe_dir))
    extra_paths.append(str(app_exe_dir / "bin"))
script_dir = Path(__file__).resolve().parent
extra_paths.append(str(script_dir))
extra_paths.append(str(script_dir / "bin"))

curr_path = os.environ.get("PATH", "")
for ep in extra_paths:
    if os.path.exists(ep) and ep not in curr_path:
        curr_path = ep + os.pathsep + curr_path
os.environ["PATH"] = curr_path

# ── Import Backend Modules (Zero Backend Changes) ─────────────────────────────
APP_DIR = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
WORK_DIR = APP_DIR / "workspace"
WORK_DIR.mkdir(exist_ok=True)

import config as cfg
import updater
import project_manager
from video_editor import (
    ASPECT_RATIOS, WATERMARK_POSITIONS, VOICEOVER_VOICES,
    EXPORT_RESOLUTIONS, QUALITY_PRESETS, CAPTION_STYLE_NAMES, CAPTION_LANGUAGE_NAMES,
    extract_clip, process_clip, export_clip, GAMEPLAY_MODE_NAMES, ANIMATION_EFFECT_NAMES
)
from viral_scorer_cloud import UI_MODEL_NAMES as SCORING_MODELS, PROVIDER_MODELS
from transcription_router import ALL_MODELS as TRANS_MODELS, auto_transcribe
import social_auth as sa
import license_check

# ─────────────────────────────────────────────────────────────────────────────
# CUSTOM MULTI-LINE API KEY CONTAINER WITH EYE MASKING & AUTO-SAVE
# ─────────────────────────────────────────────────────────────────────────────

class MultiLineKeyInput(QWidget):
    """
    Sleek, compact Multi-line API Key input container (QPlainTextEdit):
    - One Line = One Key (Enter drops cleanly to next line for failover key rotation)
    - 100% Direct Text Binding: editor.toPlainText() is the absolute single source of truth (no bullet string corruption)
    - CSS-based Privacy Eye Toggle (instant hide/reveal without modifying string buffer)
    - Real-time textChanged signal for background continuous auto-save
    """
    textChanged = pyqtSignal()

    def __init__(self, placeholder: str = "", initial_text: str = "", parent=None):
        super().__init__(parent)
        self._is_hidden = False

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        self.editor = QPlainTextEdit()
        self.editor.setPlaceholderText(placeholder)
        self.editor.setFixedHeight(72)
        if initial_text:
            self.editor.setPlainText(initial_text)

        self.editor.setStyleSheet(self._get_style(revealed=True))
        layout.addWidget(self.editor, stretch=1)

        self.eye_btn = QPushButton("🙈 Hide")
        self.eye_btn.setProperty("class", "secondaryButton")
        self.eye_btn.setFixedWidth(85)
        self.eye_btn.setFixedHeight(72)
        self.eye_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.eye_btn.clicked.connect(self.toggle_visibility)
        layout.addWidget(self.eye_btn)

        self.editor.textChanged.connect(self.textChanged)

    def _get_style(self, revealed: bool) -> str:
        if revealed:
            return """
                QPlainTextEdit {
                    background: #111827;
                    border: 1px solid #374151;
                    border-radius: 8px;
                    color: #F3F4F6;
                    padding: 6px 10px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    font-size: 11px;
                    line-height: 1.4;
                }
                QPlainTextEdit:focus {
                    border: 1px solid #E11D48;
                }
            """
        else:
            return """
                QPlainTextEdit {
                    background: #111827;
                    border: 1px solid #374151;
                    border-radius: 8px;
                    color: #111827;
                    selection-background-color: #374151;
                    selection-color: #374151;
                    padding: 6px 10px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    font-size: 11px;
                    line-height: 1.4;
                }
                QPlainTextEdit:focus {
                    border: 1px solid #E11D48;
                }
            """

    def toggle_visibility(self):
        self._is_hidden = not self._is_hidden
        if self._is_hidden:
            self.editor.setStyleSheet(self._get_style(revealed=False))
            self.eye_btn.setText("👁️ Show")
        else:
            self.editor.setStyleSheet(self._get_style(revealed=True))
            self.eye_btn.setText("🙈 Hide")

    def text(self) -> str:
        return self.editor.toPlainText().strip()

    def setText(self, val: str):
        if val == self.editor.toPlainText():
            return
        old_block = self.editor.blockSignals(True)
        try:
            self.editor.setPlainText(val or "")
        finally:
            self.editor.blockSignals(old_block)

# ─────────────────────────────────────────────────────────────────────────────
# QSS THEMES (LIGHT / DARK)
# ─────────────────────────────────────────────────────────────────────────────

LIGHT_THEME_QSS = """
QMainWindow, QWidget#centralWidget {
    background-color: #F8FAFC;
    color: #0F172A;
    font-family: 'Segoe UI', 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

QFrame.cardFrame {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 14px;
}

QFrame.statusGreenCard {
    background-color: #F0FDF4;
    border: 1px solid #86EFAC;
    border-radius: 12px;
}

QFrame.tipFrame {
    background-color: #FFF1F2;
    border: 1px solid #FFE4E6;
    border-radius: 10px;
}

QFrame.dropzoneFrame {
    background-color: #FAFAFA;
    border: 1px solid #E4E4E7;
    border-radius: 10px;
}
QFrame.dropzoneFrame:hover {
    background-color: #F4F4F5;
    border: 1px solid #CBD5E1;
}

QLabel {
    color: #0F172A;
    font-size: 13px;
}

QLabel.mutedText {
    color: #64748B;
    font-size: 12px;
}

QLabel.sectionTitle {
    color: #0F172A;
    font-size: 13px;
    font-weight: 700;
}

QLabel.stepTitle {
    color: #0F172A;
    font-weight: 800;
    font-size: 14px;
}

QLabel.stepBadge {
    background: #FFE4E6;
    color: #E11D48;
    font-weight: 800;
    font-size: 11px;
    border-radius: 6px;
    padding: 4px 8px;
}

QLabel.statusGreenText {
    color: #15803D;
    font-size: 13px;
    font-weight: 600;
    line-height: 1.4;
}

QLabel.statusIconText {
    color: #16A34A;
    font-size: 18px;
    font-weight: 800;
}

QLabel.tipTextLabel {
    color: #9F1239;
    font-size: 12px;
    font-weight: 500;
}

QLabel.fileNameLabel {
    font-weight: 600;
    font-size: 13px;
    color: #334155;
}

QLabel.appTitlePrefix {
    font-size: 18px;
    font-weight: 900;
    color: #0F172A;
}

QLineEdit, QComboBox, QPlainTextEdit, QTextEdit {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 8px;
    padding: 8px 12px;
    color: #0F172A;
    font-size: 13px;
    selection-background-color: #E11D48;
}
QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus, QTextEdit:focus {
    border: 1px solid #E11D48;
    background-color: #FFFFFF;
}

QPlainTextEdit#transcriptOutput {
    background-color: #FAFAFA;
    border: 1px solid #E4E4E7;
    border-radius: 10px;
    font-family: 'Consolas', 'Segoe UI', monospace;
    font-size: 12px;
    line-height: 1.5;
    padding: 12px;
    color: #0F172A;
}

QPlainTextEdit#editorConsole {
    background-color: #0F172A;
    color: #38BDF8;
    font-family: 'Consolas', monospace;
    font-size: 12px;
    border: 1px solid #1E293B;
    border-radius: 10px;
    padding: 12px;
}

QComboBox {
    padding-right: 24px;
}
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 24px;
    border-left: none;
}
QComboBox QAbstractItemView {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 8px;
    selection-background-color: #FFE4E6;
    selection-color: #E11D48;
    padding: 4px;
    outline: none;
}

QPushButton.primaryButton {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #E11D48, stop:1 #FF2D55);
    color: #FFFFFF;
    border: none;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
    padding: 12px 20px;
}
QPushButton.primaryButton:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #BE123C, stop:1 #E11D48);
}
QPushButton.primaryButton:pressed {
    background: #9F1239;
}
QPushButton.primaryButton:disabled {
    background: #CBD5E1;
    color: #94A3B8;
}

QPushButton.outlineButton {
    background-color: #FFF1F2;
    border: 1px solid #FDA4AF;
    color: #E11D48;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    padding: 8px 14px;
}
QPushButton.outlineButton:hover {
    background-color: #FFE4E6;
    border: 1px solid #F43F5E;
}

QPushButton.secondaryButton {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    color: #334155;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    padding: 8px 14px;
}
QPushButton.secondaryButton:hover {
    background-color: #F8FAFC;
    border: 1px solid #CBD5E1;
}

QPushButton.navTabButton {
    background: transparent;
    border: none;
    border-bottom: 3px solid transparent;
    color: #64748B;
    font-size: 13px;
    font-weight: 600;
    padding: 10px 16px;
    border-radius: 0px;
}
QPushButton.navTabButton:hover {
    color: #0F172A;
    background-color: rgba(225, 29, 72, 0.04);
}
QPushButton.navTabButton[active="true"] {
    color: #E11D48;
    border-bottom: 3px solid #E11D48;
    font-weight: 700;
}

QScrollBar:vertical {
    border: none;
    background: #F1F5F9;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #CBD5E1;
    min-height: 20px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #94A3B8;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QSlider::groove:horizontal {
    height: 6px;
    background: #E2E8F0;
    border-radius: 3px;
}
QSlider::sub-page:horizontal {
    background: #E11D48;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #FFFFFF;
    border: 2px solid #E11D48;
    width: 16px;
    height: 16px;
    margin-top: -5px;
    margin-bottom: -5px;
    border-radius: 8px;
}
QSlider::handle:horizontal:hover {
    background: #FFE4E6;
}

QCheckBox {
    color: #0F172A;
    font-size: 13px;
    spacing: 8px;
}
QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border: 1px solid #CBD5E1;
    border-radius: 5px;
    background: #FFFFFF;
}
QCheckBox::indicator:checked {
    background: #E11D48;
    border: 1px solid #E11D48;
}

QFrame#supportFrame {
    background-color: #F0FDF4;
    border: 1px solid #86EFAC;
    border-radius: 12px;
}
QPushButton#whatsappBtn {
    background-color: #25D366;
    color: #FFFFFF;
    font-weight: 700;
    font-size: 13px;
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
}
QPushButton#whatsappBtn:hover {
    background-color: #20BA56;
}
QPushButton#callBtn {
    background-color: #2563EB;
    color: #FFFFFF;
    font-weight: 700;
    font-size: 13px;
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
}
QPushButton#callBtn:hover {
    background-color: #1D4ED8;
}

QFrame#playerCanvasFrame {
    background-color: #07070A;
    border: 1px solid #23232F;
    border-radius: 12px;
}
QLabel#playerTimeLabel {
    color: #F8FAFC;
    font-family: 'Consolas', 'Segoe UI', monospace;
    font-size: 12px;
    font-weight: 600;
    padding: 3px 8px;
    background-color: #111622;
    border: 1px solid #252D3D;
    border-radius: 6px;
}
QSlider#playerScrubSlider::groove:horizontal {
    height: 6px;
    background: #CBD5E1;
    border-radius: 3px;
}
QSlider#playerScrubSlider::sub-page:horizontal {
    background: #E11D48;
    border-radius: 3px;
}
QSlider#playerScrubSlider::handle:horizontal {
    background: #FFFFFF;
    border: 2px solid #E11D48;
    width: 14px;
    height: 14px;
    margin-top: -4px;
    margin-bottom: -4px;
    border-radius: 7px;
}
"""

DARK_THEME_QSS = """
QMainWindow, QWidget#centralWidget {
    background-color: #0B0E14;
    color: #F8FAFC;
    font-family: 'Segoe UI', 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

QFrame.cardFrame {
    background-color: #151921;
    border: 1px solid #252D3D;
    border-radius: 14px;
}

QFrame.statusGreenCard {
    background-color: #062E1A;
    border: 1px solid #10B981;
    border-radius: 12px;
}

QFrame.tipFrame {
    background-color: #261019;
    border: 1px solid #4C1D2E;
    border-radius: 10px;
}

QFrame.dropzoneFrame {
    background-color: #1A1F2C;
    border: 1px solid #2A3449;
    border-radius: 10px;
}
QFrame.dropzoneFrame:hover {
    background-color: #22293A;
    border: 1px solid #3E4D6B;
}

QLabel {
    color: #F8FAFC;
    font-size: 13px;
}

QLabel.mutedText {
    color: #94A3B8;
    font-size: 12px;
}

QLabel.sectionTitle {
    color: #F8FAFC;
    font-size: 13px;
    font-weight: 700;
}

QLabel.stepTitle {
    color: #F8FAFC;
    font-weight: 800;
    font-size: 14px;
}

QLabel.stepBadge {
    background: #3B1624;
    color: #FB7185;
    border: 1px solid #881337;
    font-weight: 800;
    font-size: 11px;
    border-radius: 6px;
    padding: 4px 8px;
}

QLabel.statusGreenText {
    color: #86EFAC;
    font-size: 13px;
    font-weight: 600;
    line-height: 1.4;
}

QLabel.statusIconText {
    color: #4ADE80;
    font-size: 18px;
    font-weight: 800;
}

QLabel.tipTextLabel {
    color: #FB7185;
    font-size: 12px;
    font-weight: 500;
}

QLabel.fileNameLabel {
    font-weight: 600;
    font-size: 13px;
    color: #E2E8F0;
}

QLabel.appTitlePrefix {
    font-size: 18px;
    font-weight: 900;
    color: #F8FAFC;
}

QLineEdit, QComboBox, QPlainTextEdit, QTextEdit {
    background-color: #1A1F2C;
    border: 1px solid #2A3449;
    border-radius: 8px;
    padding: 8px 12px;
    color: #F8FAFC;
    font-size: 13px;
    selection-background-color: #E11D48;
}
QLineEdit:focus, QComboBox:focus, QPlainTextEdit:focus, QTextEdit:focus {
    border: 1px solid #E11D48;
    background-color: #1E2433;
}

QPlainTextEdit#transcriptOutput {
    background-color: #111622;
    border: 1px solid #252D3D;
    border-radius: 10px;
    font-family: 'Consolas', 'Segoe UI', monospace;
    font-size: 12px;
    line-height: 1.5;
    padding: 12px;
    color: #F1F5F9;
}

QPlainTextEdit#editorConsole {
    background-color: #0B0E14;
    color: #38BDF8;
    font-family: 'Consolas', monospace;
    font-size: 12px;
    border: 1px solid #1E2433;
    border-radius: 10px;
    padding: 12px;
}

QComboBox {
    padding-right: 24px;
}
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 24px;
    border-left: none;
}
QComboBox QAbstractItemView {
    background-color: #151921;
    border: 1px solid #252D3D;
    border-radius: 8px;
    selection-background-color: #331623;
    selection-color: #FB7185;
    padding: 4px;
    outline: none;
}

QPushButton.primaryButton {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #E11D48, stop:1 #FF2D55);
    color: #FFFFFF;
    border: none;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
    padding: 12px 20px;
}
QPushButton.primaryButton:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #BE123C, stop:1 #E11D48);
}
QPushButton.primaryButton:pressed {
    background: #9F1239;
}
QPushButton.primaryButton:disabled {
    background: #334155;
    color: #64748B;
}

QPushButton.outlineButton {
    background-color: #2D141E;
    border: 1px solid #881337;
    color: #FB7185;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    padding: 8px 14px;
}
QPushButton.outlineButton:hover {
    background-color: #3B1624;
    border: 1px solid #BE123C;
}

QPushButton.secondaryButton {
    background-color: #1E2433;
    border: 1px solid #2E384D;
    color: #E2E8F0;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    padding: 8px 14px;
}
QPushButton.secondaryButton:hover {
    background-color: #273043;
    border: 1px solid #3E4D6B;
}

QPushButton.navTabButton {
    background: transparent;
    border: none;
    border-bottom: 3px solid transparent;
    color: #94A3B8;
    font-size: 13px;
    font-weight: 600;
    padding: 10px 16px;
    border-radius: 0px;
}
QPushButton.navTabButton:hover {
    color: #F8FAFC;
    background-color: rgba(225, 29, 72, 0.08);
}
QPushButton.navTabButton[active="true"] {
    color: #FB7185;
    border-bottom: 3px solid #E11D48;
    font-weight: 700;
}

QScrollBar:vertical {
    border: none;
    background: #11151D;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #252D3D;
    min-height: 20px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #3B465D;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QSlider::groove:horizontal {
    height: 6px;
    background: #252D3D;
    border-radius: 3px;
}
QSlider::sub-page:horizontal {
    background: #E11D48;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #151921;
    border: 2px solid #FB7185;
    width: 16px;
    height: 16px;
    margin-top: -5px;
    margin-bottom: -5px;
    border-radius: 8px;
}

QCheckBox {
    color: #F8FAFC;
    font-size: 13px;
    spacing: 8px;
}
QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border: 1px solid #2E384D;
    border-radius: 5px;
    background: #1A1F2C;
}
QCheckBox::indicator:checked {
    background: #E11D48;
    border: 1px solid #E11D48;
}

QFrame#supportFrame {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 rgba(225, 29, 72, 0.14), stop:1 rgba(16, 185, 129, 0.16));
    border: 1px solid #2D3748;
    border-radius: 12px;
}
QPushButton#whatsappBtn {
    background-color: #25D366;
    color: #FFFFFF;
    font-weight: 700;
    font-size: 13px;
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
}
QPushButton#whatsappBtn:hover {
    background-color: #20BA56;
}
QPushButton#callBtn {
    background-color: #2563EB;
    color: #FFFFFF;
    font-weight: 700;
    font-size: 13px;
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
}
QPushButton#callBtn:hover {
    background-color: #1D4ED8;
}

QFrame#playerCanvasFrame {
    background-color: #07070A;
    border: 1px solid #23232F;
    border-radius: 12px;
}
QLabel#playerTimeLabel {
    color: #F8FAFC;
    font-family: 'Consolas', 'Segoe UI', monospace;
    font-size: 12px;
    font-weight: 600;
    padding: 3px 8px;
    background-color: #111622;
    border: 1px solid #252D3D;
    border-radius: 6px;
}
QSlider#playerScrubSlider::groove:horizontal {
    height: 6px;
    background: #252D3D;
    border-radius: 3px;
}
QSlider#playerScrubSlider::sub-page:horizontal {
    background: #E11D48;
    border-radius: 3px;
}
QSlider#playerScrubSlider::handle:horizontal {
    background: #FFFFFF;
    border: 2px solid #E11D48;
    width: 14px;
    height: 14px;
    margin-top: -4px;
    margin-bottom: -4px;
    border-radius: 7px;
}
"""


# ─────────────────────────────────────────────────────────────────────────────
# THREADING WORKERS (NON-BLOCKING ASYNC OPERATIONS)
# ─────────────────────────────────────────────────────────────────────────────

class InspectQualityThread(QThread):
    sig_result = pyqtSignal(list, str) # choices, status
    sig_error = pyqtSignal(str)

    def __init__(self, url: str):
        super().__init__()
        self.url = url

    def run(self):
        import yt_dlp
        opts = {
            'quiet': True, 'no_warnings': True, 'noplaylist': True,
            'nocheckcertificate': True, 'geo_bypass': True,
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
            }
        }
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(self.url, download=False)
                if not info:
                    self.sig_error.emit("Could not fetch video info.")
                    return
                formats = info.get('formats', [])
                found_heights = set()
                choices = ["🌟 Best Available (Highest Quality)"]
                for f in formats:
                    h = f.get('height')
                    if h and isinstance(h, int) and h > 0:
                        if h >= 2160 and 2160 not in found_heights:
                            choices.append("4K (2160p)")
                            found_heights.add(2160)
                        elif h >= 1440 and 1440 not in found_heights:
                            choices.append("2K (1440p)")
                            found_heights.add(1440)
                        elif h >= 1080 and 1080 not in found_heights:
                            choices.append("1080p (Full HD)")
                            found_heights.add(1080)
                        elif h >= 720 and 720 not in found_heights:
                            choices.append("720p (HD)")
                            found_heights.add(720)
                        elif h >= 480 and 480 not in found_heights:
                            choices.append("480p")
                            found_heights.add(480)
                        elif h >= 360 and 360 not in found_heights:
                            choices.append("360p")
                            found_heights.add(360)
                title = info.get('title', 'Video')
                self.sig_result.emit(choices, f"✓ Available qualities loaded for: {title}")
        except Exception as e:
            self.sig_error.emit(f"Quality inspection error: {e}")


class DownloadVideoThread(QThread):
    sig_status = pyqtSignal(str)
    sig_finished = pyqtSignal(str) # downloaded file path
    sig_error = pyqtSignal(str)

    def __init__(self, url: str, quality: str):
        super().__init__()
        self.url = url
        self.quality = quality

    def run(self):
        import yt_dlp
        out_dir = WORK_DIR / "downloads"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_tmpl = str(out_dir / "%(title).40s_%(id)s.%(ext)s")

        fmt_str = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
        if "4k" in self.quality.lower() or "2160" in self.quality:
            fmt_str = "bestvideo[height<=2160][ext=mp4]+bestaudio[ext=m4a]/best"
        elif "2k" in self.quality.lower() or "1440" in self.quality:
            fmt_str = "bestvideo[height<=1440][ext=mp4]+bestaudio[ext=m4a]/best"
        elif "1080" in self.quality:
            fmt_str = "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best"
        elif "720" in self.quality:
            fmt_str = "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best"
        elif "480" in self.quality:
            fmt_str = "bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/best"

        def _hook(d):
            if d['status'] == 'downloading':
                p = d.get('_percent_str', '0%')
                s = d.get('_speed_str', '')
                self.sig_status.emit(f"⬇️ Downloading video... {p} ({s})")

        opts = {
            'outtmpl': out_tmpl,
            'format': fmt_str,
            'merge_output_format': 'mp4',
            'progress_hooks': [_hook],
            'quiet': True,
            'nocheckcertificate': True
        }
        try:
            self.sig_status.emit("Connecting to video server...")
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(self.url, download=True)
                fn = ydl.prepare_filename(info)
                if not Path(fn).exists():
                    fn = str(Path(fn).with_suffix(".mp4"))
                self.sig_finished.emit(fn)
        except Exception as e:
            self.sig_error.emit(f"Download failed: {e}")


class TranscribeThread(QThread):
    sig_log = pyqtSignal(str)
    sig_status = pyqtSignal(str)
    sig_finished = pyqtSignal(object) # TranscriptResult
    sig_error = pyqtSignal(str)

    def __init__(self, video_path: str, model_name: str, language: str):
        super().__init__()
        self.video_path = video_path
        self.model_name = model_name
        self.language = language

    def run(self):
        try:
            license_check.enforce_access_or_raise()
            stem = Path(self.video_path).stem[:40]
            session_dir = WORK_DIR / f"session_{stem}"
            session_dir.mkdir(parents=True, exist_ok=True)

            def _log(msg):
                self.sig_log.emit(str(msg))

            self.sig_status.emit(f"Transcribing {Path(self.video_path).name} with {self.model_name}...")
            res = auto_transcribe(
                video_path=self.video_path,
                session_dir=str(session_dir),
                model_name=self.model_name,
                language=None if self.language == "Auto Detect" else self.language,
                log=_log
            )
            # Save session for scorer
            session_meta = {
                "source_video": self.video_path,
                "session_dir": str(session_dir),
                "transcript_json": str(session_dir / "transcript.json"),
                "duration": getattr(res, 'duration', 0.0)
            }
            (WORK_DIR / "session.json").write_text(json.dumps(session_meta, indent=2), encoding="utf-8")
            self.sig_finished.emit(res)
        except Exception as e:
            self.sig_error.emit(f"Transcription failed: {e}")


class ScoreViralClipsThread(QThread):
    sig_log = pyqtSignal(str)
    sig_status = pyqtSignal(str)
    sig_finished = pyqtSignal(list) # list of ClipCandidate
    sig_error = pyqtSignal(str)

    def __init__(self, model_name: str, auto_mode: bool, min_dur: int, max_dur: int, custom_prompt: str, n_clips: int = 5, dynamic_hook_mode: bool = True):
        super().__init__()
        self.model_name = model_name
        self.auto_mode = auto_mode
        self.min_dur = min_dur
        self.max_dur = max_dur
        self.custom_prompt = custom_prompt
        self.n_clips = n_clips
        self.dynamic_hook_mode = dynamic_hook_mode

    def run(self):
        try:
            license_check.enforce_access_or_raise()
            from transcribe import TranscriptResult, Segment, WordToken

            tr_path = None
            
            # 1. Try active project from project_manager
            try:
                act_proj = project_manager.get_active_project()
                if act_proj:
                    p_state = act_proj.load_state()
                    cand_tr = p_state.get("transcript_json")
                    if cand_tr and Path(cand_tr).exists():
                        tr_path = Path(cand_tr)
                    elif (act_proj.folder / "transcript.json").exists():
                        tr_path = act_proj.folder / "transcript.json"
            except Exception:
                pass

            # 2. Try workspace/session.json
            if not tr_path or not tr_path.exists():
                sess_file = WORK_DIR / "session.json"
                if sess_file.exists():
                    try:
                        sess = json.loads(sess_file.read_text(encoding="utf-8"))
                        cand = sess.get("transcript_json")
                        if cand and Path(cand).exists():
                            tr_path = Path(cand)
                    except Exception:
                        pass

            # 3. Try global workspace transcript files
            if not tr_path or not tr_path.exists():
                for cand in [WORK_DIR / "transcript.json"] + sorted(list(WORK_DIR.glob("session_*/transcript.json")), key=lambda p: p.stat().st_mtime, reverse=True):
                    if cand.exists() and cand.stat().st_size > 50:
                        tr_path = cand
                        break

            if not tr_path or not tr_path.exists():
                self.sig_error.emit("No active transcript found. Please transcribe a video in Tab 1 first.")
                return

            res = TranscriptResult.load_json(str(tr_path))
            if not res or not res.segments:
                self.sig_error.emit("Transcript file is empty. Please transcribe a video in Tab 1 first.")
                return

            def _log(msg):
                self.sig_log.emit(str(msg))

            from viral_scorer_cloud import score_viral_clips_cloud
            self.sig_status.emit(f"Scanning for viral moments with {self.model_name}...")
            clips = score_viral_clips_cloud(
                result=res,
                ui_model_name=self.model_name,
                clip_duration=float((self.min_dur + self.max_dur) / 2),
                top_n=self.n_clips if not self.auto_mode else 15,
                auto_mode=self.auto_mode,
                dynamic_hook_mode=self.dynamic_hook_mode,
                min_dur=float(self.min_dur),
                max_dur=float(self.max_dur),
                user_prompt=self.custom_prompt,
                groq_keys=cfg.get_groq_keys(),
                gemini_keys=cfg.get_gemini_keys(),
                openai_keys=cfg.get_openai_keys(),
                claude_keys=cfg.get_anthropic_keys(),
                deepseek_keys=cfg.get_deepseek_keys(),
                progress_cb=_log
            )
            # Save clips json
            clips_data = [c.to_dict() for c in clips]
            (WORK_DIR / "viral_clips.json").write_text(json.dumps(clips_data, indent=2, ensure_ascii=False), encoding="utf-8")
            self.sig_finished.emit(clips)
        except Exception as e:
            self.sig_error.emit(f"Viral scoring failed: {e}")


class RenderEditorThread(QThread):
    sig_log = pyqtSignal(str)
    sig_status = pyqtSignal(str)
    sig_finished = pyqtSignal(str, bool) # output_path, is_fast_preview
    sig_error = pyqtSignal(str)

    def __init__(self, clip_idx: int, params: dict, fast_preview: bool = False):
        super().__init__()
        self.clip_idx = clip_idx
        self.params = params
        self.fast_preview = fast_preview
        self.is_cancelled = False

    def cancel(self):
        """Immediately flags cancellation and terminates child subprocesses."""
        self.is_cancelled = True
        try:
            import video_editor
            video_editor.terminate_all_active_subprocesses()
        except Exception:
            pass

    def run(self):
        try:
            license_check.enforce_access_or_raise()
            import traceback
            from transcribe import TranscriptResult
            from video_editor import process_clip, GAMEPLAY_MODES

            # 1. Multi-source resolution for source video, transcript, and viral clips
            src_video = None
            tr_json = None
            clips = None

            # Check active project first
            try:
                act_proj = project_manager.get_active_project()
                if act_proj:
                    p_state = act_proj.load_state()
                    src_video = p_state.get("source_video")
                    tr_json = p_state.get("transcript_json")
                    if p_state.get("viral_clips"):
                        clips = p_state.get("viral_clips")
            except Exception:
                pass

            # Check workspace session.json
            sess_file = WORK_DIR / "session.json"
            if sess_file.exists():
                try:
                    sess = json.loads(sess_file.read_text(encoding="utf-8"))
                    if not src_video:
                        src_video = sess.get("source_video")
                    if not tr_json:
                        tr_json = sess.get("transcript_json")
                except Exception:
                    pass

            # Check workspace viral_clips.json
            clips_file = WORK_DIR / "viral_clips.json"
            if not clips and clips_file.exists():
                try:
                    clips = json.loads(clips_file.read_text(encoding="utf-8"))
                except Exception:
                    pass

            if not src_video or not Path(src_video).exists():
                self.sig_error.emit("Source video file not found. Please import and transcribe a video first.")
                return

            if not clips:
                self.sig_error.emit("No viral clips found. Please run 'Find Viral Moments' in Tab 2 first.")
                return

            if self.clip_idx >= len(clips):
                self.sig_error.emit(f"Clip #{self.clip_idx + 1} not found (total clips: {len(clips)}).")
                return

            c = clips[self.clip_idx]
            out_dir = WORK_DIR / "editor" / f"clip_{self.clip_idx + 1}"
            out_dir.mkdir(parents=True, exist_ok=True)

            segs = None
            if tr_json and Path(tr_json).exists():
                try:
                    tr = TranscriptResult.load_json(str(tr_json))
                    segs = tr.segments
                except Exception:
                    pass

            def _log(m):
                if not self.is_cancelled:
                    self.sig_log.emit(str(m))

            c_start = float(c.get("start", 0.0))
            c_end = float(c.get("end", c_start + 60.0))
            if self.fast_preview:
                target_end = min(c_start + 8.0, c_end)
            else:
                target_end = c_end

            gp_mode_key = GAMEPLAY_MODES.get(self.params.get("gp_mode", ""), "reel_split")

            edited_out = process_clip(
                source_video=src_video,
                clip_start=c_start,
                clip_end=target_end,
                work_dir=str(out_dir),
                transcript_segments=segs,
                enable_face_crop=self.params.get("enable_face_crop", True),
                face_tracking_mode=self.params.get("face_tracking_mode", "dynamic"),
                aspect_ratio=self.params.get("aspect_ratio", "9:16 (Portrait)"),
                custom_ratio=self.params.get("custom_ratio", None),
                clip_zoom=self.params.get("clip_zoom", 100.0),
                enable_captions=self.params.get("enable_captions", True),
                caption_font_size=self.params.get("caption_font_size", 18),
                caption_position="bottom",
                caption_y_pos=self.params.get("caption_y_pos", 75.0),
                caption_style=self.params.get("caption_style", "Hormozi Classic Pop"),
                enable_mirror=self.params.get("enable_mirror", False),
                enable_gameplay=self.params.get("enable_gameplay", False),
                gameplay_video=self.params.get("gameplay_video", None),
                gameplay_mode=gp_mode_key,
                gameplay_blend_pct=self.params.get("gameplay_blend_pct", 15.0),
                gameplay_split_ratio=self.params.get("gameplay_split_ratio", 55.0),
                gameplay_overlay_opacity=self.params.get("gameplay_overlay_opacity", 0.95),
                gameplay_y_pos=self.params.get("gameplay_y_pos", 50.0),
                gameplay_scale=self.params.get("gameplay_scale", 100.0),
                fast_preview=self.fast_preview,
                log=_log
            )

            if self.is_cancelled:
                return

            target_dest = str(out_dir / ("preview_fast.mp4" if self.fast_preview else "edited.mp4"))
            if edited_out and Path(edited_out).exists():
                if edited_out != target_dest:
                    shutil.copy2(edited_out, target_dest)
                if not self.fast_preview:
                    exp_dir = Path(cfg.get_output_folder())
                    exp_dir.mkdir(parents=True, exist_ok=True)
                    auto_exp = str(exp_dir / f"viral_clip_{self.clip_idx + 1}.mp4")
                    shutil.copy2(target_dest, auto_exp)

            if not self.is_cancelled:
                self.sig_finished.emit(target_dest, self.fast_preview)
        except Exception as e:
            if not self.is_cancelled:
                import traceback
                tb_str = traceback.format_exc()
                self.sig_error.emit(f"Rendering failed:\n{tb_str}")


class CheckUpdateThread(QThread):
    sig_result = pyqtSignal(dict)
    sig_error = pyqtSignal(str)

    def run(self):
        try:
            res = updater.check_for_updates()
            self.sig_result.emit(res)
        except Exception as e:
            self.sig_error.emit(str(e))


class DownloadUpdateThread(QThread):
    sig_progress = pyqtSignal(int)
    sig_finished = pyqtSignal(str)
    sig_error = pyqtSignal(str)

    def __init__(self, download_url: str):
        super().__init__()
        self.download_url = download_url

    def run(self):
        try:
            def _cb(pct, d_bytes):
                self.sig_progress.emit(pct)
            patch_file = updater.download_patch(self.download_url, progress_cb=_cb)
            self.sig_finished.emit(patch_file)
        except Exception as e:
            self.sig_error.emit(str(e))


# ─────────────────────────────────────────────────────────────────────────────
# CUSTOM WIDGETS (EXACT VISUAL REPLICATION)
# ─────────────────────────────────────────────────────────────────────────────

class DropzoneWidget(QFrame):
    sig_file_selected = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.setProperty("class", "dropzoneFrame")
        self.setAcceptDrops(True)
        self.current_file = ""

        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(16, 14, 16, 14)
        self.layout.setSpacing(12)

        self.icon_label = QLabel("📄")
        self.icon_label.setStyleSheet("font-size: 22px;")
        self.layout.addWidget(self.icon_label)

        self.text_container = QVBoxLayout()
        self.text_container.setSpacing(2)

        self.file_name_label = QLabel("Click to upload video or drag and drop here")
        self.file_name_label.setProperty("class", "fileNameLabel")
        self.text_container.addWidget(self.file_name_label)

        self.sub_label = QLabel("Supports MP4, MOV, MKV, AVI, WEBM, MP3, WAV (Max 4K)")
        self.sub_label.setProperty("class", "mutedText")
        self.text_container.addWidget(self.sub_label)
        self.layout.addLayout(self.text_container, stretch=1)

        self.size_badge = QLabel("")
        self.size_badge.setStyleSheet("color: #3B82F6; font-weight: 700; font-size: 12px; background: #EFF6FF; border-radius: 6px; padding: 3px 8px;")
        self.size_badge.setVisible(False)
        self.layout.addWidget(self.size_badge)

        self.remove_btn = QPushButton("✕")
        self.remove_btn.setStyleSheet("background: transparent; border: none; font-size: 14px; font-weight: 700; color: #94A3B8; padding: 4px;")
        self.remove_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.remove_btn.setVisible(False)
        self.remove_btn.clicked.connect(self.clear_file)
        self.layout.addWidget(self.remove_btn)

        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            fn, _ = QFileDialog.getOpenFileName(self, "Select Video or Audio File", "", "Video/Audio Files (*.mp4 *.mov *.mkv *.avi *.webm *.mp3 *.wav *.m4a)")
            if fn:
                self.set_file(fn)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if urls:
            fn = urls[0].toLocalFile()
            if fn and Path(fn).exists():
                self.set_file(fn)

    def set_file(self, file_path: str):
        self.current_file = str(Path(file_path).resolve())
        p = Path(self.current_file)
        size_mb = p.stat().st_size / (1024 * 1024)
        self.file_name_label.setText(p.name)
        self.size_badge.setText(f"{size_mb:.1f} MB")
        self.size_badge.setVisible(True)
        self.remove_btn.setVisible(True)
        self.sig_file_selected.emit(self.current_file)

    def clear_file(self):
        self.current_file = ""
        self.file_name_label.setText("Click to upload video or drag and drop here")
        self.size_badge.setVisible(False)
        self.remove_btn.setVisible(False)
        self.sig_file_selected.emit("")

    def clear(self):
        self.clear_file()

    def get_file(self) -> str:
        return self.current_file


# ─────────────────────────────────────────────────────────────────────────────
# MAIN APPLICATION WINDOW
# ─────────────────────────────────────────────────────────────────────────────

class NSClipperMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # Clean up any lingering orphaned FFmpeg / FFprobe processes from prior crashes/sessions
        try:
            import video_editor
            video_editor.cleanup_orphan_ffmpeg_processes()
        except Exception:
            pass

        self.is_dark_theme = True
        self.active_project_id = project_manager.get_active_project_id()
        self._init_live_player()
        self._init_export_player()
        self.init_window()
        self.build_ui()
        self.apply_theme(is_dark=True)

        # Active worker references
        self.active_worker = None

        # Check license
        self.refresh_license_status()

        # Initialize Project Dropdown and load active project
        self._refresh_project_dropdown()
        self.action_switch_project(self.active_project_id)

    def init_window(self):
        self.setWindowTitle("NS Clipper — AI Viral Clip Studio")
        self.resize(1360, 840)
        self.setMinimumSize(1100, 680)
        icon_path = str(get_resource_path("launcher_icon.ico"))
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

    def closeEvent(self, event):
        """Forcefully terminates all background worker threads and ffmpeg zombie processes on app exit."""
        try:
            if hasattr(self, 'render_worker') and self.render_worker:
                if self.render_worker.isRunning():
                    self.render_worker.cancel()
                    self.render_worker.terminate()
                    self.render_worker.wait(1000)
            if hasattr(self, 'active_worker') and self.active_worker:
                if hasattr(self.active_worker, 'isRunning') and self.active_worker.isRunning():
                    self.active_worker.terminate()
                    self.active_worker.wait(1000)
            import video_editor
            video_editor.cleanup_orphan_ffmpeg_processes()
        except Exception:
            pass

        if hasattr(self, 'media_player') and self.media_player:
            try: self.media_player.stop()
            except Exception: pass
        if hasattr(self, 'ex_media_player') and self.ex_media_player:
            try: self.ex_media_player.stop()
            except Exception: pass
        if hasattr(self, 'gameplay_cap') and self.gameplay_cap:
            try: self.gameplay_cap.release()
            except Exception: pass
        if hasattr(self, 'player_timer') and self.player_timer:
            try: self.player_timer.stop()
            except Exception: pass
        event.accept()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, '_render_current_player_frame'):
            self._render_current_player_frame()
        if hasattr(self, '_render_current_export_frame'):
            self._render_current_export_frame()

    def apply_theme(self, is_dark: bool):
        self.is_dark_theme = is_dark
        if is_dark:
            self.setStyleSheet(DARK_THEME_QSS)
            self.theme_btn.setText("☀️ Light")
        else:
            self.setStyleSheet(LIGHT_THEME_QSS)
            self.theme_btn.setText("🌓 Theme")

    def toggle_theme(self):
        self.apply_theme(not self.is_dark_theme)

    def refresh_license_status(self):
        lic_info = license_check.check_access()
        allowed = lic_info.get("allowed", False)
        is_act = lic_info.get("is_activated", False)
        status_lbl = lic_info.get("status_label", "Trial Mode")
        
        if hasattr(self, 'trial_badge'):
            self.trial_badge.setText(status_lbl)
            if is_act:
                self.trial_badge.setStyleSheet("background: rgba(16, 185, 129, 0.15); border: 1px solid #10B981; color: #10B981; font-weight: 800; font-size: 12px; border-radius: 20px; padding: 5px 14px;")
            elif allowed:
                self.trial_badge.setStyleSheet("background: rgba(245, 158, 11, 0.15); border: 1px solid #F59E0B; color: #F59E0B; font-weight: 700; font-size: 12px; border-radius: 20px; padding: 5px 14px;")
            else:
                self.trial_badge.setStyleSheet("background: rgba(239, 68, 68, 0.2); border: 1px solid #EF4444; color: #EF4444; font-weight: 800; font-size: 12px; border-radius: 20px; padding: 5px 14px;")

    def build_ui(self):
        self.central_widget = QWidget()
        self.central_widget.setObjectName("centralWidget")
        self.setCentralWidget(self.central_widget)

        self.main_layout = QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(24, 20, 24, 20)
        self.main_layout.setSpacing(16)

        # ── 1. Top Header Bar ─────────────────────────────────────────────
        header_layout = QHBoxLayout()
        header_layout.setSpacing(12)

        # Logo Icon Badge
        logo_icon = QLabel("✂️")
        logo_icon.setStyleSheet("background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #E11D48, stop:1 #FF2D55); color: #FFFFFF; font-size: 18px; border-radius: 9px; padding: 6px 10px;")
        header_layout.addWidget(logo_icon)

        # Title Label
        title_label = QLabel("<span style='font-size:18px; font-weight:900;'>NS</span> <span style='font-size:18px; font-weight:900; color:#E11D48;'>Clipper</span>")
        title_label.setProperty("class", "appTitlePrefix")
        header_layout.addWidget(title_label)

        # ── Project Session Management Frame ──
        proj_frame = QFrame()
        proj_frame.setStyleSheet("background: rgba(30, 41, 59, 0.4); border: 1px solid #334155; border-radius: 8px; padding: 2px 6px;")
        proj_layout = QHBoxLayout(proj_frame)
        proj_layout.setContentsMargins(6, 2, 6, 2)
        proj_layout.setSpacing(8)

        proj_icon = QLabel("📁")
        proj_icon.setStyleSheet("font-size: 13px;")
        proj_layout.addWidget(proj_icon)

        self.project_combo = QComboBox()
        self.project_combo.setMinimumWidth(230)
        self.project_combo.setStyleSheet("font-weight: 600; font-size: 12px; padding: 4px 8px; border: 1px solid #475569; border-radius: 6px;")
        self.project_combo.currentIndexChanged.connect(self._on_project_combo_changed)
        proj_layout.addWidget(self.project_combo)

        self.new_proj_btn = QPushButton("➕ New")
        self.new_proj_btn.setToolTip("Create a new clean project session")
        self.new_proj_btn.setProperty("class", "secondaryButton")
        self.new_proj_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.new_proj_btn.clicked.connect(self.action_create_new_project)
        proj_layout.addWidget(self.new_proj_btn)

        self.delete_proj_btn = QPushButton("🗑️")
        self.delete_proj_btn.setToolTip("Delete current project from disk")
        self.delete_proj_btn.setProperty("class", "outlineButton")
        self.delete_proj_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.delete_proj_btn.clicked.connect(self.action_delete_current_project)
        proj_layout.addWidget(self.delete_proj_btn)

        self.autosave_status_lbl = QLabel("💾 Auto-Saved")
        self.autosave_status_lbl.setStyleSheet("color: #10B981; font-weight: 700; font-size: 11px; padding: 2px 6px; background: rgba(16, 185, 129, 0.1); border-radius: 4px;")
        proj_layout.addWidget(self.autosave_status_lbl)

        header_layout.addWidget(proj_frame)

        header_layout.addStretch(1)

        # Trial Mode Badge
        self.trial_badge = QLabel("⏳ Trial Mode")
        self.trial_badge.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.trial_badge.setToolTip("Click to enter license key and activate Pro")
        self.trial_badge.mousePressEvent = lambda ev: self.action_show_activation_dialog()
        header_layout.addWidget(self.trial_badge)

        # Theme Toggle Button
        self.theme_btn = QPushButton("🌓 Theme")
        self.theme_btn.setProperty("class", "secondaryButton")
        self.theme_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.theme_btn.clicked.connect(self.toggle_theme)
        header_layout.addWidget(self.theme_btn)

        self.main_layout.addLayout(header_layout)

        # ── 2. Top Segmented Navigation Tabs Strip ─────────────────────────
        nav_card = QFrame()
        nav_card.setProperty("class", "cardFrame")
        nav_card_layout = QHBoxLayout(nav_card)
        nav_card_layout.setContentsMargins(12, 4, 12, 4)
        nav_card_layout.setSpacing(8)

        self.nav_buttons: List[QPushButton] = []
        tabs_data = [
            ("🎙️ Transcribe", 0),
            ("🔥 Find Viral Clips", 1),
            ("✂️ Editor", 2),
            ("💾 Export", 3),
            ("⚙️ Settings", 4),
        ]

        for title, idx in tabs_data:
            btn = QPushButton(title)
            btn.setProperty("class", "navTabButton")
            btn.setProperty("active", "true" if idx == 0 else "false")
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            btn.clicked.connect(lambda checked, i=idx: self.switch_tab(i))
            self.nav_buttons.append(btn)
            nav_card_layout.addWidget(btn)

        nav_card_layout.addStretch(1)
        self.main_layout.addWidget(nav_card)

        # ── 3. Main Stacked Pages Container ───────────────────────────────
        self.stacked_widget = QStackedWidget()
        self.main_layout.addWidget(self.stacked_widget, stretch=1)

        # Build each tab
        self.build_tab1_transcribe()
        self.build_tab2_find_clips()
        self.build_tab3_editor()
        self.build_tab4_export()
        self.build_tab5_settings()

        # ── 4. Bottom Footer Tip Bar ──────────────────────────────────────
        self.tip_frame = QFrame()
        self.tip_frame.setProperty("class", "tipFrame")
        tip_layout = QHBoxLayout(self.tip_frame)
        tip_layout.setContentsMargins(14, 10, 14, 10)
        tip_layout.setSpacing(10)

        tip_icon = QLabel("ℹ️")
        tip_layout.addWidget(tip_icon)

        self.tip_text = QLabel("Tip: For best results, use high quality videos with clear audio.")
        self.tip_text.setProperty("class", "tipTextLabel")
        tip_layout.addWidget(self.tip_text, stretch=1)

        self.main_layout.addWidget(self.tip_frame)

    def switch_tab(self, index: int):
        try:
            self.stacked_widget.setCurrentIndex(index)
            for i, btn in enumerate(self.nav_buttons):
                btn.setProperty("active", "true" if i == index else "false")
                btn.style().unpolish(btn)
                btn.style().polish(btn)

            if index == 4:
                self._reload_settings_from_disk()

            # Tab switching resource management
            if index != 2 and getattr(self, 'player_is_playing', False):
                self.action_player_toggle_play()
            if index != 3 and getattr(self, 'ex_player_is_playing', False):
                self.action_ex_player_toggle_play()
            elif index == 3:
                # When opening Export tab, auto-load latest export if player is idle
                if not getattr(self, 'current_export_video_path', '') or not Path(getattr(self, 'current_export_video_path', '')).exists():
                    export_dir = Path(WORK_DIR) / "exports"
                    exports = sorted(export_dir.glob("*.mp4"), key=os.path.getmtime, reverse=True) if export_dir.exists() else []
                    if exports:
                        self._load_export_player(str(exports[0]), auto_play=False)
                    else:
                        editor_dir = Path(WORK_DIR) / "editor"
                        edited_clips = sorted(editor_dir.glob("clip_*/edited.mp4"), key=os.path.getmtime, reverse=True) if editor_dir.exists() else []
                        if edited_clips:
                            self._load_export_player(str(edited_clips[0]), auto_play=False)
        except Exception as e:
            print(f"[UI Critical Exception in switch_tab]: {e}")

    def _reload_settings_from_disk(self):
        inputs = [
            getattr(self, 'gem_keys_input', None),
            getattr(self, 'groq_keys_input', None),
            getattr(self, 'dg_keys_input', None),
            getattr(self, 'oai_keys_input', None),
            getattr(self, 'claude_keys_input', None),
            getattr(self, 'deepseek_keys_input', None),
        ]
        # Block all signals during loading
        for inp in inputs:
            if inp is not None:
                inp.blockSignals(True)

        try:
            cfg_data = cfg.load()
            if hasattr(self, 'gem_keys_input'):
                self.gem_keys_input.setText("\n".join(cfg_data.get("gemini_keys", [])))
            if hasattr(self, 'groq_keys_input'):
                self.groq_keys_input.setText("\n".join(cfg_data.get("groq_keys", [])))
            if hasattr(self, 'dg_keys_input'):
                self.dg_keys_input.setText("\n".join(cfg_data.get("deepgram_keys", [])))
            if hasattr(self, 'oai_keys_input'):
                self.oai_keys_input.setText("\n".join(cfg_data.get("openai_keys", [])))
            if hasattr(self, 'claude_keys_input'):
                self.claude_keys_input.setText("\n".join(cfg_data.get("anthropic_keys", [])))
            if hasattr(self, 'deepseek_keys_input'):
                self.deepseek_keys_input.setText("\n".join(cfg_data.get("deepseek_keys", [])))
            if hasattr(self, 'set_folder_input'):
                self.set_folder_input.setText(cfg.get_output_folder())
        except Exception as e:
            print(f"[UI Critical Exception in _reload_settings_from_disk]: {e}")
        finally:
            for inp in inputs:
                if inp is not None:
                    inp.blockSignals(False)

    # ═════════════════════════════════════════════════════════════════════════
    # TAB 1: TRANSCRIBE (EXACT MATCH OF ATTACHED SCREENSHOT)
    # ═════════════════════════════════════════════════════════════════════════
    def build_tab1_transcribe(self):
        page = QWidget()
        layout = QHBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        # ── Left Column: Video Ingestion Card ─────────────────────────────
        left_card = QFrame()
        left_card.setProperty("class", "cardFrame")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(22, 22, 22, 22)
        left_layout.setSpacing(16)

        # Header Title with Step 1 Badge
        header_row = QHBoxLayout()
        header_row.setSpacing(12)

        step_badge = QLabel("STEP 1")
        step_badge.setProperty("class", "stepBadge")
        header_row.addWidget(step_badge)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        step_title = QLabel("Video Ingestion & Speech Recognition")
        step_title.setProperty("class", "stepTitle")
        title_col.addWidget(step_title)

        step_desc = QLabel("Upload a video or audio file and generate transcript")
        step_desc.setProperty("class", "mutedText")
        title_col.addWidget(step_desc)

        header_row.addLayout(title_col, stretch=1)
        left_layout.addLayout(header_row)

        # Section 1: Upload Dropzone
        lbl1 = QLabel("📁 Upload Video or Audio File")
        lbl1.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl1)

        self.t_dropzone = DropzoneWidget()
        left_layout.addWidget(self.t_dropzone)

        # Section 2: Paste Video Link
        lbl2 = QLabel("🔗 Paste Video Link")
        lbl2.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl2)

        url_row = QHBoxLayout()
        url_row.setSpacing(10)
        self.t_url_input = QLineEdit()
        self.t_url_input.setPlaceholderText("https://www.youtube.com/watch?v=... or TikTok / Reel link")
        url_row.addWidget(self.t_url_input, stretch=3)

        self.t_check_qual_btn = QPushButton("🔍 Check Qualities")
        self.t_check_qual_btn.setProperty("class", "outlineButton")
        self.t_check_qual_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.t_check_qual_btn.clicked.connect(self.action_check_qualities)
        url_row.addWidget(self.t_check_qual_btn, stretch=1)
        left_layout.addLayout(url_row)

        # Section 3: Select Quality
        lbl3 = QLabel("🖥️ Select Quality")
        lbl3.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl3)

        self.t_quality_combo = QComboBox()
        self.t_quality_combo.addItems([
            "🌟 Best Available (Highest Quality)",
            "4K (2160p)",
            "2K (1440p)",
            "1080p (Full HD)",
            "720p (HD)",
            "480p",
            "360p"
        ])
        self.t_quality_combo.setCurrentText("1080p (Full HD)")
        left_layout.addWidget(self.t_quality_combo)

        # Section 4: AI Model & Language
        lbl4 = QLabel("🎙️ Transcription Engine & Language")
        lbl4.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl4)

        opt_row = QHBoxLayout()
        opt_row.setSpacing(10)
        self.t_model_combo = QComboBox()
        self.t_model_combo.addItems(TRANS_MODELS)
        opt_row.addWidget(self.t_model_combo, stretch=2)

        self.t_lang_combo = QComboBox()
        self.t_lang_combo.addItems(CAPTION_LANGUAGE_NAMES)
        opt_row.addWidget(self.t_lang_combo, stretch=1)
        left_layout.addLayout(opt_row)

        left_layout.addStretch(1)

        # Big Red Action Button
        self.t_start_btn = QPushButton("⬇️ Download & Transcribe Video")
        self.t_start_btn.setProperty("class", "primaryButton")
        self.t_start_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.t_start_btn.clicked.connect(self.action_start_transcription)
        left_layout.addWidget(self.t_start_btn)

        layout.addWidget(left_card, stretch=1)

        # ── Right Column: Stacked Status + Transcript Output ──────────────
        right_col = QVBoxLayout()
        right_col.setSpacing(16)

        # Right Top Card: Status
        self.status_card = QFrame()
        self.status_card.setProperty("class", "statusGreenCard")
        status_card_layout = QHBoxLayout(self.status_card)
        status_card_layout.setContentsMargins(18, 16, 18, 16)
        status_card_layout.setSpacing(14)

        self.status_icon = QLabel("✔️")
        self.status_icon.setProperty("class", "statusIconText")
        status_card_layout.addWidget(self.status_icon)

        self.t_status_label = QLabel("Ready — Upload a video or paste a link to begin.")
        self.t_status_label.setProperty("class", "statusGreenText")
        self.t_status_label.setWordWrap(True)
        status_card_layout.addWidget(self.t_status_label, stretch=1)

        right_col.addWidget(self.status_card)

        # Right Bottom Card: Transcript Output
        out_card = QFrame()
        out_card.setProperty("class", "cardFrame")
        out_card_layout = QVBoxLayout(out_card)
        out_card_layout.setContentsMargins(20, 20, 20, 20)
        out_card_layout.setSpacing(12)

        out_header = QHBoxLayout()
        out_title_lbl = QLabel("📄 Transcript Output")
        out_title_lbl.setProperty("class", "sectionTitle")
        out_header.addWidget(out_title_lbl)
        out_header.addStretch(1)

        self.copy_transcript_btn = QPushButton("📋 Copy")
        self.copy_transcript_btn.setProperty("class", "secondaryButton")
        self.copy_transcript_btn.clicked.connect(self.action_copy_transcript)
        out_header.addWidget(self.copy_transcript_btn)

        out_card_layout.addLayout(out_header)

        self.t_output_text = QPlainTextEdit()
        self.t_output_text.setObjectName("transcriptOutput")
        self.t_output_text.setReadOnly(True)
        self.t_output_text.setPlaceholderText("Transcript with word-level timestamps will appear here...")
        out_card_layout.addWidget(self.t_output_text, stretch=1)

        right_col.addWidget(out_card, stretch=1)

        layout.addLayout(right_col, stretch=1)
        self.stacked_widget.addWidget(page)


    # ═════════════════════════════════════════════════════════════════════════
    # TAB 2: FIND VIRAL CLIPS
    # ═════════════════════════════════════════════════════════════════════════
    def build_tab2_find_clips(self):
        page = QWidget()
        layout = QHBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        # Left Column: Scoring Controls
        left_card = QFrame()
        left_card.setProperty("class", "cardFrame")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(22, 22, 22, 22)
        left_layout.setSpacing(16)

        header_row = QHBoxLayout()
        step_badge = QLabel("STEP 2")
        step_badge.setProperty("class", "stepBadge")
        header_row.addWidget(step_badge)

        title_col = QVBoxLayout()
        step_title = QLabel("AI Viral Moment Detection")
        step_title.setProperty("class", "stepTitle")
        title_col.addWidget(step_title)
        step_desc = QLabel("Analyze transcript & score high-potential viral moments")
        step_desc.setProperty("class", "mutedText")
        title_col.addWidget(step_desc)
        header_row.addLayout(title_col, stretch=1)
        left_layout.addLayout(header_row)

        # AI Provider & Model Cascading Selection
        prov_row = QHBoxLayout()
        prov_row.setSpacing(10)

        prov_col = QVBoxLayout()
        prov_col.setSpacing(4)
        prov_col.addWidget(QLabel("🏢 AI Provider"))
        self.s_provider_combo = QComboBox()
        self.s_provider_combo.addItems(list(PROVIDER_MODELS.keys()))
        prov_col.addWidget(self.s_provider_combo)
        prov_row.addLayout(prov_col, stretch=1)

        mod_col = QVBoxLayout()
        mod_col.setSpacing(4)
        mod_col.addWidget(QLabel("🤖 AI Virality Scoring Model"))
        self.s_model_combo = QComboBox()
        mod_col.addWidget(self.s_model_combo)
        prov_row.addLayout(mod_col, stretch=2)
        left_layout.addLayout(prov_row)

        def _on_provider_changed(prov_name):
            models = PROVIDER_MODELS.get(prov_name, [])
            self.s_model_combo.blockSignals(True)
            self.s_model_combo.clear()
            self.s_model_combo.addItems(models)
            self.s_model_combo.blockSignals(False)
            if models:
                self.s_model_combo.setCurrentIndex(0)
                cfg.set("scoring_model", models[0])

        self.s_provider_combo.currentTextChanged.connect(_on_provider_changed)
        self.s_model_combo.currentTextChanged.connect(lambda m: cfg.set("scoring_model", m) if m else None)

        saved_scoring_model = cfg.get("scoring_model", "")
        found_prov = None
        for prov, mlist in PROVIDER_MODELS.items():
            if saved_scoring_model in mlist:
                found_prov = prov
                break
        if found_prov:
            self.s_provider_combo.setCurrentText(found_prov)
            _on_provider_changed(found_prov)
            self.s_model_combo.setCurrentText(saved_scoring_model)
        else:
            _on_provider_changed(self.s_provider_combo.currentText())

        # AI Smart Dynamic Hook Mode
        self.s_dynamic_chk = QCheckBox("⚡ AI Smart Dynamic Hook & Climax Selection (Let AI Decide Exact Duration)")
        self.s_dynamic_chk.setChecked(True)
        self.s_dynamic_chk.setStyleSheet("color: #E11D48; font-weight: 700; font-size: 12px;")
        left_layout.addWidget(self.s_dynamic_chk)

        self.s_dynamic_tip = QLabel("💡 AI will autonomously analyze conversational arcs, emotional hooks, and climax points, snapping cleanly to natural sentence boundaries (10s – 300s).")
        self.s_dynamic_tip.setStyleSheet("color: #64748B; font-size: 11px; margin-bottom: 4px;")
        self.s_dynamic_tip.setWordWrap(True)
        left_layout.addWidget(self.s_dynamic_tip)

        # Auto Mode Toggle
        self.s_auto_chk = QCheckBox("🤖 AI Auto Discovery Mode (Find all qualifying clips across full video)")
        self.s_auto_chk.setChecked(True)
        left_layout.addWidget(self.s_auto_chk)

        # Manual Number of Clips Container (Visible when AI Auto Mode is unchecked)
        self.s_manual_container = QWidget()
        manual_lay = QVBoxLayout(self.s_manual_container)
        manual_lay.setContentsMargins(0, 2, 0, 2)
        manual_lay.setSpacing(6)

        self.s_nclips_lbl = QLabel("🔢 Number of Clips to Extract: 5 clips")
        self.s_nclips_lbl.setProperty("class", "sectionTitle")
        manual_lay.addWidget(self.s_nclips_lbl)

        self.s_nclips_slider = QSlider(Qt.Orientation.Horizontal)
        self.s_nclips_slider.setRange(1, 30)
        self.s_nclips_slider.setValue(5)
        self.s_nclips_slider.valueChanged.connect(
            lambda v: self.s_nclips_lbl.setText(f"🔢 Number of Clips to Extract: {v} clips")
        )
        manual_lay.addWidget(self.s_nclips_slider)

        left_layout.addWidget(self.s_manual_container)
        self.s_manual_container.setVisible(False)

        self.s_auto_chk.toggled.connect(
            lambda checked: self.s_manual_container.setVisible(not checked)
        )

        # Target Clip Length Range (Extended from 10s up to 300s)
        self.s_dur_lbl = QLabel("⏱️ Target Clip Length Range: 20s – 90s (Max Limit: 300s / 5 min)")
        self.s_dur_lbl.setProperty("class", "sectionTitle")
        left_layout.addWidget(self.s_dur_lbl)

        dur_row = QHBoxLayout()
        dur_row.setSpacing(10)

        self.s_min_val_lbl = QLabel("Min: 20s")
        self.s_min_val_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 600;")
        dur_row.addWidget(self.s_min_val_lbl)

        self.s_min_slider = QSlider(Qt.Orientation.Horizontal)
        self.s_min_slider.setRange(10, 180)
        self.s_min_slider.setValue(20)
        self.s_min_slider.valueChanged.connect(self._on_duration_sliders_changed)
        dur_row.addWidget(self.s_min_slider, stretch=1)

        self.s_max_val_lbl = QLabel("Max: 90s")
        self.s_max_val_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 600;")
        dur_row.addWidget(self.s_max_val_lbl)

        self.s_max_slider = QSlider(Qt.Orientation.Horizontal)
        self.s_max_slider.setRange(20, 300)
        self.s_max_slider.setValue(90)
        self.s_max_slider.valueChanged.connect(self._on_duration_sliders_changed)
        dur_row.addWidget(self.s_max_slider, stretch=1)
        left_layout.addLayout(dur_row)

        # Custom Prompt
        left_layout.addWidget(QLabel("💡 Custom Hook Instructions (Optional)"))
        self.s_prompt_input = QTextEdit()
        self.s_prompt_input.setPlaceholderText("e.g. Prioritize shocking revelations, funny moments, or business advice...")
        self.s_prompt_input.setMaximumHeight(80)
        left_layout.addWidget(self.s_prompt_input)

        left_layout.addStretch(1)

        self.s_find_btn = QPushButton("🎯 Find Viral Moments")
        self.s_find_btn.setProperty("class", "primaryButton")
        self.s_find_btn.clicked.connect(self.action_find_viral_clips)
        left_layout.addWidget(self.s_find_btn)

        layout.addWidget(left_card, stretch=1)

        # Right Column: Viral Clips Scroll Area
        right_card = QFrame()
        right_card.setProperty("class", "cardFrame")
        right_layout = QVBoxLayout(right_card)
        right_layout.setContentsMargins(20, 20, 20, 20)
        right_layout.setSpacing(12)

        right_header = QLabel("🔥 Discovered Viral Clips")
        right_header.setStyleSheet("font-weight: 700; font-size: 14px;")
        right_layout.addWidget(right_header)

        self.clips_scroll = QScrollArea()
        self.clips_scroll.setWidgetResizable(True)
        self.clips_scroll.setStyleSheet("border: none; background: transparent;")
        self.clips_container = QWidget()
        self.clips_container_layout = QVBoxLayout(self.clips_container)
        self.clips_container_layout.setSpacing(12)
        self.clips_scroll.setWidget(self.clips_container)

        self.no_clips_lbl = QLabel("No viral clips discovered yet. Click 'Find Viral Moments' to scan.")
        self.no_clips_lbl.setProperty("class", "mutedText")
        self.no_clips_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.clips_container_layout.addWidget(self.no_clips_lbl)

        right_layout.addWidget(self.clips_scroll, stretch=1)
        layout.addWidget(right_card, stretch=1)

        self.stacked_widget.addWidget(page)

    # ═════════════════════════════════════════════════════════════════════════
    # TAB 3: EDITOR
    # ═════════════════════════════════════════════════════════════════════════
    # ═════════════════════════════════════════════════════════════════════════
    # TAB 3: EDITOR
    # ═════════════════════════════════════════════════════════════════════════
    def build_tab3_editor(self):
        page = QWidget()
        layout = QHBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        # Left Column: Editor Controls (Stretch = 3, ~35%-40% width)
        left_card = QFrame()
        left_card.setProperty("class", "cardFrame")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(18, 16, 18, 16)
        left_layout.setSpacing(12)

        top_row = QHBoxLayout()
        self.e_clip_combo = QComboBox()
        self.e_clip_combo.addItem("Select Clip (Raw Source Video)")
        top_row.addWidget(self.e_clip_combo, stretch=3)

        self.e_reload_btn = QPushButton("🔄 Reload")
        self.e_reload_btn.setProperty("class", "secondaryButton")
        self.e_reload_btn.clicked.connect(self.action_reload_clips_dropdown)
        top_row.addWidget(self.e_reload_btn, stretch=1)

        self.e_mirror_chk = QCheckBox("🪞 Mirror")
        top_row.addWidget(self.e_mirror_chk)
        left_layout.addLayout(top_row)

        # Face Tracking Section
        ft_header_row = QHBoxLayout()
        self.e_face_enable_chk = QCheckBox("☑️ Enable AI Face Tracking")
        self.e_face_enable_chk.setChecked(True)
        self.e_face_enable_chk.setStyleSheet("font-weight: 700; color: #F8FAFC;")
        self.e_face_enable_chk.toggled.connect(self._on_face_enable_toggled)
        ft_header_row.addWidget(self.e_face_enable_chk)
        left_layout.addLayout(ft_header_row)

        face_row = QHBoxLayout()
        self.e_face_dynamic = QRadioButton("Dynamic Auto Split")
        self.e_face_dynamic.setChecked(True)
        self.e_face_simple = QRadioButton("Simple Face Tracking")
        self.e_face_multi = QRadioButton("Multi-Person Group")
        self.face_bg = QButtonGroup()
        self.face_bg.addButton(self.e_face_dynamic)
        self.face_bg.addButton(self.e_face_simple)
        self.face_bg.addButton(self.e_face_multi)
        face_row.addWidget(self.e_face_dynamic)
        face_row.addWidget(self.e_face_simple)
        face_row.addWidget(self.e_face_multi)
        left_layout.addLayout(face_row)

        # Aspect Ratio & Zoom
        asp_row = QHBoxLayout()
        asp_row.addWidget(QLabel("Aspect Ratio:"))
        self.e_aspect_combo = QComboBox()
        self.e_aspect_combo.addItems(list(ASPECT_RATIOS.keys()))
        self.e_aspect_combo.setCurrentText("9:16 (Portrait)")
        asp_row.addWidget(self.e_aspect_combo)

        asp_row.addWidget(QLabel("Zoom %:"))
        self.e_zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self.e_zoom_slider.setRange(50, 250)
        self.e_zoom_slider.setValue(100)
        asp_row.addWidget(self.e_zoom_slider)
        left_layout.addLayout(asp_row)

        # Subtitles & Captions
        left_layout.addWidget(QLabel("📝 Subtitle Styling"))
        cap_row = QHBoxLayout()
        self.e_caps_chk = QCheckBox("Burn Subtitles")
        self.e_caps_chk.setChecked(True)
        cap_row.addWidget(self.e_caps_chk)

        self.e_cap_style_combo = QComboBox()
        self.e_cap_style_combo.addItems(CAPTION_STYLE_NAMES)
        cap_row.addWidget(self.e_cap_style_combo)
        left_layout.addLayout(cap_row)

        # Dynamic Font Size & Vertical Position Sliders
        cap_ctrl_row = QHBoxLayout()
        self.e_cap_size_lbl = QLabel("Font Size: 18px")
        self.e_cap_size_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
        cap_ctrl_row.addWidget(self.e_cap_size_lbl)

        self.e_cap_size_slider = QSlider(Qt.Orientation.Horizontal)
        self.e_cap_size_slider.setRange(8, 40)
        self.e_cap_size_slider.setValue(18)
        self.e_cap_size_slider.valueChanged.connect(self._on_cap_size_changed)
        cap_ctrl_row.addWidget(self.e_cap_size_slider)

        self.e_cap_y_lbl = QLabel("Placement Y: 78%")
        self.e_cap_y_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
        cap_ctrl_row.addWidget(self.e_cap_y_lbl)

        self.e_cap_y_slider = QSlider(Qt.Orientation.Horizontal)
        self.e_cap_y_slider.setRange(10, 90)
        self.e_cap_y_slider.setValue(78)
        self.e_cap_y_slider.valueChanged.connect(self._on_cap_y_changed)
        cap_ctrl_row.addWidget(self.e_cap_y_slider)
        left_layout.addLayout(cap_ctrl_row)

        # Split Gameplay Overlay Section
        left_layout.addWidget(QLabel("🎮 Split Gameplay Overlay"))
        gp_top_row = QHBoxLayout()
        self.e_gp_chk = QCheckBox("Enable Gameplay Overlay")
        gp_top_row.addWidget(self.e_gp_chk)

        self.e_gp_preset = QComboBox()
        self.e_gp_preset.addItems([
            "Subway Surfers (Loop)",
            "Minecraft Parkour (Loop)",
            "GTA V Stunt Ramp (Loop)",
            "Kinetic Sand / Slime (Loop)"
        ])
        gp_top_row.addWidget(self.e_gp_preset)
        left_layout.addLayout(gp_top_row)

        # Custom Gameplay Upload & Split Ratio Controls
        gp_sub_row = QHBoxLayout()
        self.e_gp_upload_btn = QPushButton("📂 Upload Custom Gameplay...")
        self.e_gp_upload_btn.setProperty("class", "secondaryButton")
        self.e_gp_upload_btn.clicked.connect(self.action_upload_custom_gameplay)
        gp_sub_row.addWidget(self.e_gp_upload_btn)

        self.e_gp_custom_lbl = QLabel("")
        self.e_gp_custom_lbl.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 600;")
        self.e_gp_custom_lbl.setVisible(False)
        gp_sub_row.addWidget(self.e_gp_custom_lbl)
        left_layout.addLayout(gp_sub_row)

        split_row = QHBoxLayout()
        self.e_gp_split_lbl = QLabel("Split: 55% Top / 45% Gameplay")
        self.e_gp_split_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
        split_row.addWidget(self.e_gp_split_lbl)

        self.e_gp_split_slider = QSlider(Qt.Orientation.Horizontal)
        self.e_gp_split_slider.setRange(30, 75)
        self.e_gp_split_slider.setValue(55)
        self.e_gp_split_slider.valueChanged.connect(self._on_gameplay_split_changed)
        split_row.addWidget(self.e_gp_split_slider)
        left_layout.addLayout(split_row)

        gp_y_row = QHBoxLayout()
        self.e_gp_y_lbl = QLabel("🎮 Gameplay Vertical Position (Y-Offset): 50%")
        self.e_gp_y_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
        gp_y_row.addWidget(self.e_gp_y_lbl)

        self.e_gp_y_slider = QSlider(Qt.Orientation.Horizontal)
        self.e_gp_y_slider.setRange(0, 100)
        self.e_gp_y_slider.setValue(50)
        self.e_gp_y_slider.valueChanged.connect(self._on_gameplay_y_changed)
        gp_y_row.addWidget(self.e_gp_y_slider)
        left_layout.addLayout(gp_y_row)

        # Live Player Sync Connections
        self.e_clip_combo.currentIndexChanged.connect(self._on_player_clip_changed)
        self.e_mirror_chk.toggled.connect(self._on_editor_settings_changed)
        self.e_aspect_combo.currentIndexChanged.connect(self._on_editor_settings_changed)
        self.e_zoom_slider.valueChanged.connect(self._on_editor_settings_changed)
        self.e_face_dynamic.toggled.connect(self._on_editor_settings_changed)
        self.e_face_simple.toggled.connect(self._on_editor_settings_changed)
        self.e_face_multi.toggled.connect(self._on_editor_settings_changed)
        self.e_caps_chk.toggled.connect(self._on_editor_settings_changed)
        self.e_cap_style_combo.currentIndexChanged.connect(self._on_editor_settings_changed)
        self.e_gp_chk.toggled.connect(self._on_gameplay_toggled)
        self.e_gp_preset.currentIndexChanged.connect(self._on_gameplay_preset_changed)
        self.e_gp_y_slider.valueChanged.connect(self._on_editor_settings_changed)
        self.e_gp_chk.toggled.connect(self._on_gameplay_toggled)
        self.e_gp_preset.currentIndexChanged.connect(self._on_gameplay_preset_changed)

        left_layout.addStretch(1)

        # Render Action Button
        self.e_render_btn = QPushButton("✂️ Render Full Clip")
        self.e_render_btn.setProperty("class", "primaryButton")
        self.e_render_btn.clicked.connect(lambda: self.action_render_clip(fast_preview=False))
        left_layout.addWidget(self.e_render_btn)

        layout.addWidget(left_card, stretch=1)

        # Right Column: Real-Time Interactive Video Player & Processing Console (Equal 1:1 width)
        right_card = QFrame()
        right_card.setProperty("class", "cardFrame")
        right_layout = QVBoxLayout(right_card)
        right_layout.setContentsMargins(16, 14, 16, 14)
        right_layout.setSpacing(8)

        right_header = QLabel("🎬 Real-Time Interactive Live Video Player")
        right_header.setStyleSheet("font-weight: 700; font-size: 13px;")
        right_layout.addWidget(right_header)

        # Video Canvas Container Frame (Maximized, Expanding Policy, Dynamic Scaling)
        self.e_player_frame = QFrame()
        self.e_player_frame.setObjectName("playerCanvasFrame")
        self.e_player_frame.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.e_player_frame.setMinimumHeight(240)
        
        canvas_layout = QVBoxLayout(self.e_player_frame)
        canvas_layout.setContentsMargins(4, 4, 4, 4)
        canvas_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.e_video_canvas = QLabel("🎬 Select an active clip to preview in real-time")
        self.e_video_canvas.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.e_video_canvas.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.e_video_canvas.setStyleSheet("color: #64748B; font-size: 13px; font-weight: 600;")
        canvas_layout.addWidget(self.e_video_canvas)
        right_layout.addWidget(self.e_player_frame, stretch=1)

        # Timeline Scrubbing Slider
        self.e_time_slider = QSlider(Qt.Orientation.Horizontal)
        self.e_time_slider.setObjectName("playerScrubSlider")
        self.e_time_slider.setRange(0, 100)
        self.e_time_slider.setValue(0)
        self.e_time_slider.sliderMoved.connect(self.action_player_seek)
        right_layout.addWidget(self.e_time_slider)

        # Playback Control Bar
        controls_row = QHBoxLayout()
        controls_row.setSpacing(8)

        self.e_play_btn = QPushButton("▶ Play")
        self.e_play_btn.setObjectName("playerPlayBtn")
        self.e_play_btn.setProperty("class", "primaryButton")
        self.e_play_btn.clicked.connect(self.action_player_toggle_play)
        controls_row.addWidget(self.e_play_btn)

        self.e_skip_back_btn = QPushButton("⏪ -5s")
        self.e_skip_back_btn.setProperty("class", "secondaryButton")
        self.e_skip_back_btn.clicked.connect(lambda: self.action_player_skip(-5.0))
        controls_row.addWidget(self.e_skip_back_btn)

        self.e_skip_fwd_btn = QPushButton("⏩ +5s")
        self.e_skip_fwd_btn.setProperty("class", "secondaryButton")
        self.e_skip_fwd_btn.clicked.connect(lambda: self.action_player_skip(5.0))
        controls_row.addWidget(self.e_skip_fwd_btn)

        controls_row.addStretch(1)

        self.e_time_lbl = QLabel("00:00 / 00:00")
        self.e_time_lbl.setObjectName("playerTimeLabel")
        controls_row.addWidget(self.e_time_lbl)

        self.e_mute_btn = QPushButton("🔊")
        self.e_mute_btn.setProperty("class", "secondaryButton")
        self.e_mute_btn.setFixedWidth(38)
        self.e_mute_btn.clicked.connect(self.action_player_toggle_mute)
        controls_row.addWidget(self.e_mute_btn)

        right_layout.addLayout(controls_row)

        # Compact Processing Console (Compact 60-70px height)
        right_layout.addWidget(QLabel("📜 Processing Console"))
        self.e_console_log = QPlainTextEdit()
        self.e_console_log.setObjectName("editorConsole")
        self.e_console_log.setReadOnly(True)
        self.e_console_log.setMaximumHeight(65)
        right_layout.addWidget(self.e_console_log)

        layout.addWidget(right_card, stretch=1)
        self.stacked_widget.addWidget(page)

    # ═════════════════════════════════════════════════════════════════════════
    # TAB 4: EXPORT
    # ═════════════════════════════════════════════════════════════════════════
    def build_tab4_export(self):
        page = QWidget()
        layout = QHBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        left_card = QFrame()
        left_card.setProperty("class", "cardFrame")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(20, 18, 20, 18)
        left_layout.setSpacing(14)

        header_row = QHBoxLayout()
        step_badge = QLabel("STEP 4")
        step_badge.setProperty("class", "stepBadge")
        header_row.addWidget(step_badge)

        title_col = QVBoxLayout()
        step_title = QLabel("Final Clip Review & PC Export")
        step_title.setProperty("class", "stepTitle")
        title_col.addWidget(step_title)
        step_desc = QLabel("Review rendered clips with burned subtitles and save to your computer")
        step_desc.setProperty("class", "mutedText")
        title_col.addWidget(step_desc)
        header_row.addLayout(title_col, stretch=1)
        left_layout.addLayout(header_row)

        left_layout.addWidget(QLabel("📁 Choose Export Destination Folder"))
        folder_row = QHBoxLayout()
        self.ex_folder_input = QLineEdit(cfg.get_output_folder())
        folder_row.addWidget(self.ex_folder_input, stretch=3)

        browse_btn = QPushButton("📁 Browse...")
        browse_btn.setProperty("class", "secondaryButton")
        browse_btn.clicked.connect(self.action_browse_export_folder)
        folder_row.addWidget(browse_btn, stretch=1)
        left_layout.addLayout(folder_row)

        # Quick Destination Buttons
        quick_row = QHBoxLayout()
        d_btn = QPushButton("🖥️ Desktop")
        d_btn.setProperty("class", "secondaryButton")
        d_btn.clicked.connect(lambda: self.ex_folder_input.setText(str(Path.home() / "Desktop")))
        quick_row.addWidget(d_btn)

        dl_btn = QPushButton("📥 Downloads")
        dl_btn.setProperty("class", "secondaryButton")
        dl_btn.clicked.connect(lambda: self.ex_folder_input.setText(str(Path.home() / "Downloads")))
        quick_row.addWidget(dl_btn)

        vid_btn = QPushButton("🎬 Videos")
        vid_btn.setProperty("class", "secondaryButton")
        vid_btn.clicked.connect(lambda: self.ex_folder_input.setText(str(Path.home() / "Videos")))
        quick_row.addWidget(vid_btn)
        left_layout.addLayout(quick_row)

        left_layout.addWidget(QLabel("📄 Export Filename"))
        self.ex_filename_input = QLineEdit("viral_short_clip_1.mp4")
        left_layout.addWidget(self.ex_filename_input)

        left_layout.addStretch(1)

        self.ex_save_btn = QPushButton("💾 Export & Save Video to Selected Location")
        self.ex_save_btn.setProperty("class", "primaryButton")
        self.ex_save_btn.clicked.connect(self.action_save_export)
        left_layout.addWidget(self.ex_save_btn)

        self.ex_open_btn = QPushButton("📂 Open Folder in Windows Explorer")
        self.ex_open_btn.setProperty("class", "secondaryButton")
        self.ex_open_btn.clicked.connect(self.action_open_export_folder)
        left_layout.addWidget(self.ex_open_btn)

        layout.addWidget(left_card, stretch=1)

        # Right Column: Interactive Final Video Review Player (Equal 1:1 width)
        right_card = QFrame()
        right_card.setProperty("class", "cardFrame")
        right_layout = QVBoxLayout(right_card)
        right_layout.setContentsMargins(16, 14, 16, 14)
        right_layout.setSpacing(8)

        right_header = QLabel("🎬 Final Video Review Player")
        right_header.setStyleSheet("font-weight: 700; font-size: 13px;")
        right_layout.addWidget(right_header)

        # Video Canvas Container Frame
        self.ex_player_frame = QFrame()
        self.ex_player_frame.setObjectName("playerCanvasFrame")
        self.ex_player_frame.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.ex_player_frame.setMinimumHeight(240)

        ex_canvas_layout = QVBoxLayout(self.ex_player_frame)
        ex_canvas_layout.setContentsMargins(4, 4, 4, 4)
        ex_canvas_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.ex_video_canvas = QLabel("🎬 Render a clip in Tab 3 to review the final output here")
        self.ex_video_canvas.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.ex_video_canvas.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ex_video_canvas.setStyleSheet("color: #64748B; font-size: 13px; font-weight: 600;")
        ex_canvas_layout.addWidget(self.ex_video_canvas)
        right_layout.addWidget(self.ex_player_frame, stretch=1)

        # Timeline Scrubbing Slider
        self.ex_time_slider = QSlider(Qt.Orientation.Horizontal)
        self.ex_time_slider.setObjectName("playerScrubSlider")
        self.ex_time_slider.setRange(0, 100)
        self.ex_time_slider.setValue(0)
        self.ex_time_slider.sliderMoved.connect(self.action_ex_player_seek)
        right_layout.addWidget(self.ex_time_slider)

        # Playback Controls Bar
        ex_controls_row = QHBoxLayout()
        ex_controls_row.setSpacing(8)

        self.ex_play_btn = QPushButton("▶ Play")
        self.ex_play_btn.setObjectName("playerPlayBtn")
        self.ex_play_btn.setProperty("class", "primaryButton")
        self.ex_play_btn.clicked.connect(self.action_ex_player_toggle_play)
        ex_controls_row.addWidget(self.ex_play_btn)

        self.ex_skip_back_btn = QPushButton("⏪ -5s")
        self.ex_skip_back_btn.setProperty("class", "secondaryButton")
        self.ex_skip_back_btn.clicked.connect(lambda: self.action_ex_player_skip(-5.0))
        ex_controls_row.addWidget(self.ex_skip_back_btn)

        self.ex_skip_fwd_btn = QPushButton("⏩ +5s")
        self.ex_skip_fwd_btn.setProperty("class", "secondaryButton")
        self.ex_skip_fwd_btn.clicked.connect(lambda: self.action_ex_player_skip(5.0))
        ex_controls_row.addWidget(self.ex_skip_fwd_btn)

        ex_controls_row.addStretch(1)

        self.ex_time_lbl = QLabel("00:00 / 00:00")
        self.ex_time_lbl.setObjectName("playerTimeLabel")
        ex_controls_row.addWidget(self.ex_time_lbl)

        self.ex_mute_btn = QPushButton("🔊")
        self.ex_mute_btn.setProperty("class", "secondaryButton")
        self.ex_mute_btn.setFixedWidth(38)
        self.ex_mute_btn.clicked.connect(self.action_ex_player_toggle_mute)
        ex_controls_row.addWidget(self.ex_mute_btn)

        right_layout.addLayout(ex_controls_row)

        # Export Status Badge
        self.ex_status_lbl = QLabel("Ready to export rendered clips.")
        self.ex_status_lbl.setProperty("class", "mutedText")
        self.ex_status_lbl.setStyleSheet("font-size: 11px; padding: 2px;")
        right_layout.addWidget(self.ex_status_lbl)

        layout.addWidget(right_card, stretch=1)
        self.stacked_widget.addWidget(page)

    # ═════════════════════════════════════════════════════════════════════════
    # TAB 5: SETTINGS & LICENSE
    # ═════════════════════════════════════════════════════════════════════════
    def build_tab5_settings(self):
        page = QWidget()
        layout = QHBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        # ── Left Column: API Keys & Export Folder Card ────────────────────
        left_card = QFrame()
        left_card.setProperty("class", "cardFrame")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(22, 22, 22, 22)
        left_layout.setSpacing(14)

        # Header Title
        header_row = QHBoxLayout()
        header_row.setSpacing(12)
        step_badge = QLabel("SETTINGS")
        step_badge.setProperty("class", "stepBadge")
        header_row.addWidget(step_badge)

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        step_title = QLabel("AI Model API Keys & Cloud Storage")
        step_title.setProperty("class", "stepTitle")
        title_col.addWidget(step_title)
        step_desc = QLabel("Automatic failover and rate-limit rotation across multiple keys")
        step_desc.setProperty("class", "mutedText")
        title_col.addWidget(step_desc)
        header_row.addLayout(title_col, stretch=1)
        left_layout.addLayout(header_row)

        # 1. Google Gemini Keys (Multi-Line with One-Line=One-Key & Eye Toggle)
        lbl_gem = QLabel("🔑 Google Gemini API Key(s) (One per line for rotation):")
        lbl_gem.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl_gem)

        self.gem_keys_input = MultiLineKeyInput(
            placeholder="Enter Google Gemini API Key(s)\n(One per line: AIzaSy...)",
            initial_text="\n".join(cfg.get_gemini_keys())
        )
        self.gem_keys_input.textChanged.connect(self.auto_save_api_keys)
        left_layout.addWidget(self.gem_keys_input)

        # 2. Groq Cloud Keys (Multi-Line with One-Line=One-Key & Eye Toggle)
        lbl_grq = QLabel("⚡ Groq Cloud API Key(s) (One per line for rotation):")
        lbl_grq.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl_grq)

        self.groq_keys_input = MultiLineKeyInput(
            placeholder="Enter Groq Cloud API Key(s)\n(One per line: gsk_...)",
            initial_text="\n".join(cfg.get_groq_keys())
        )
        self.groq_keys_input.textChanged.connect(self.auto_save_api_keys)
        left_layout.addWidget(self.groq_keys_input)

        # 3. Deepgram API Key (Multi-Line with One-Line=One-Key & Eye Toggle)
        lbl_dg = QLabel("🎙️ Deepgram API Key(s) (One per line for rotation):")
        lbl_dg.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl_dg)

        self.dg_keys_input = MultiLineKeyInput(
            placeholder="Enter Deepgram API Key(s)\n(One per line: Token...)",
            initial_text="\n".join(cfg.get_deepgram_keys())
        )
        self.dg_keys_input.textChanged.connect(self.auto_save_api_keys)
        left_layout.addWidget(self.dg_keys_input)

        # 4. OpenAI API Key (Multi-Line with One-Line=One-Key & Eye Toggle)
        lbl_oai = QLabel("🤖 OpenAI API Key(s) (One per line for rotation):")
        lbl_oai.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl_oai)

        self.oai_keys_input = MultiLineKeyInput(
            placeholder="Enter OpenAI API Key(s)\n(One per line: sk-...)",
            initial_text="\n".join(cfg.get_openai_keys())
        )
        self.oai_keys_input.textChanged.connect(self.auto_save_api_keys)
        left_layout.addWidget(self.oai_keys_input)

        # 5. Anthropic Claude API Key (Multi-Line with One-Line=One-Key & Eye Toggle)
        lbl_claude = QLabel("🧠 Anthropic Claude API Key(s) (One per line for rotation):")
        lbl_claude.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl_claude)

        self.claude_keys_input = MultiLineKeyInput(
            placeholder="Enter Anthropic API Key(s)\n(One per line: sk-ant-...)",
            initial_text="\n".join(cfg.get_anthropic_keys())
        )
        self.claude_keys_input.textChanged.connect(self.auto_save_api_keys)
        left_layout.addWidget(self.claude_keys_input)

        # 6. DeepSeek API Key (Multi-Line with One-Line=One-Key & Eye Toggle)
        lbl_ds = QLabel("🔮 DeepSeek API Key(s) (One per line for rotation):")
        lbl_ds.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl_ds)

        self.deepseek_keys_input = MultiLineKeyInput(
            placeholder="Enter DeepSeek API Key(s)\n(One per line: sk-...)",
            initial_text="\n".join(cfg.get_deepseek_keys())
        )
        self.deepseek_keys_input.textChanged.connect(self.auto_save_api_keys)
        left_layout.addWidget(self.deepseek_keys_input)

        # 4. Global Export Destination Folder
        lbl_exp = QLabel("📁 Default Export Destination Folder:")
        lbl_exp.setProperty("class", "sectionTitle")
        left_layout.addWidget(lbl_exp)
        
        folder_row = QHBoxLayout()
        self.set_folder_input = QLineEdit(cfg.get_output_folder())
        self.set_folder_input.setPlaceholderText("e.g. C:\\Users\\Name\\Desktop")
        folder_row.addWidget(self.set_folder_input, stretch=3)
        set_browse_btn = QPushButton("📁 Browse...")
        set_browse_btn.setProperty("class", "secondaryButton")
        set_browse_btn.clicked.connect(self.action_browse_settings_folder)
        folder_row.addWidget(set_browse_btn, stretch=1)
        left_layout.addLayout(folder_row)

        left_layout.addStretch(1)

        # Save Button
        save_keys_btn = QPushButton("💾 Save All Settings & API Keys")
        save_keys_btn.setProperty("class", "primaryButton")
        save_keys_btn.clicked.connect(self.action_save_api_keys)
        left_layout.addWidget(save_keys_btn)

        layout.addWidget(left_card, stretch=1)

        # ── Right Column: Official Support & License & Updates ────────────
        right_card = QFrame()
        right_card.setProperty("class", "cardFrame")
        right_layout = QVBoxLayout(right_card)
        right_layout.setContentsMargins(22, 22, 22, 22)
        right_layout.setSpacing(14)

        # 1. Official Support Card (Green/Rose Gradient Banner)
        support_frame = QFrame()
        support_frame.setObjectName("supportFrame")
        support_layout = QVBoxLayout(support_frame)
        support_layout.setContentsMargins(18, 16, 18, 16)
        support_layout.setSpacing(10)

        supp_badge = QLabel("● OFFICIAL DEVELOPER SUPPORT & SALES")
        supp_badge.setStyleSheet("color: #10B981; font-weight: 800; font-size: 11px;")
        support_layout.addWidget(supp_badge)

        supp_title = QLabel("📞 Buy License & Customer Support")
        supp_title.setStyleSheet("font-weight: 800; font-size: 15px;")
        support_layout.addWidget(supp_title)

        supp_desc = QLabel("Need a lifetime license key, activation help, or custom features? Contact the developer directly:")
        supp_desc.setProperty("class", "mutedText")
        supp_desc.setWordWrap(True)
        support_layout.addWidget(supp_desc)

        contact_row = QHBoxLayout()
        contact_row.setSpacing(10)
        wa_btn = QPushButton("💬 WhatsApp (+1 307 776 8444)")
        wa_btn.setObjectName("whatsappBtn")
        wa_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        wa_btn.clicked.connect(lambda: webbrowser.open("https://wa.me/13077768444?text=Hello%2C%20I%20want%20to%20buy%20a%20license%20key%20for%20NS%20Clipper"))
        contact_row.addWidget(wa_btn)

        call_btn = QPushButton("📞 Direct Call")
        call_btn.setObjectName("callBtn")
        call_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        call_btn.clicked.connect(lambda: webbrowser.open("tel:+13077768444"))
        contact_row.addWidget(call_btn)
        support_layout.addLayout(contact_row)

        right_layout.addWidget(support_frame)

        # 2. License Activation Section
        lic_header = QLabel("🔒 Hardware-Locked Software Activation")
        lic_header.setProperty("class", "sectionTitle")
        right_layout.addWidget(lic_header)

        # HWID row
        lbl_hwid = QLabel("Machine HWID (Share this with seller):")
        lbl_hwid.setProperty("class", "mutedText")
        right_layout.addWidget(lbl_hwid)

        hwid_box = QHBoxLayout()
        hwid_box.setSpacing(10)
        self.hwid_display = QLineEdit(license_check.get_hwid())
        self.hwid_display.setReadOnly(True)
        hwid_box.addWidget(self.hwid_display, stretch=3)
        copy_hwid_btn = QPushButton("📋 Copy Machine HWID")
        copy_hwid_btn.setProperty("class", "secondaryButton")
        copy_hwid_btn.clicked.connect(self.action_copy_hwid)
        hwid_box.addWidget(copy_hwid_btn, stretch=1)
        right_layout.addLayout(hwid_box)

        # License key entry
        lbl_key = QLabel("Enter Software License Key:")
        lbl_key.setProperty("class", "mutedText")
        right_layout.addWidget(lbl_key)

        lic_input_row = QHBoxLayout()
        lic_input_row.setSpacing(10)
        self.lic_key_input = QLineEdit()
        self.lic_key_input.setPlaceholderText("NSC-XXXX-XXXX-XXXX-XXXX / NADEEM-...")
        lic_input_row.addWidget(self.lic_key_input, stretch=3)

        activate_btn = QPushButton("🔓 Activate License")
        activate_btn.setProperty("class", "primaryButton")
        activate_btn.clicked.connect(self.action_activate_license)
        lic_input_row.addWidget(activate_btn, stretch=1)
        right_layout.addLayout(lic_input_row)

        self.lic_msg_lbl = QLabel("")
        self.lic_msg_lbl.setWordWrap(True)
        self.lic_msg_lbl.setStyleSheet("font-size: 12px; font-weight: 600; padding: 4px;")
        right_layout.addWidget(self.lic_msg_lbl)

        # 3. In-App OTA Software Updates & Maintenance Card
        upd_header = QLabel("🔄 Software Updates & Maintenance")
        upd_header.setProperty("class", "sectionTitle")
        right_layout.addWidget(upd_header)

        upd_row = QHBoxLayout()
        self.upd_version_lbl = QLabel(f"📦 Installed Version: v{cfg.APP_VERSION}")
        self.upd_version_lbl.setStyleSheet("font-weight: 700; font-size: 12px; color: #64748B;")
        upd_row.addWidget(self.upd_version_lbl)

        upd_row.addStretch(1)

        self.upd_check_btn = QPushButton("🔄 Check for Updates")
        self.upd_check_btn.setProperty("class", "secondaryButton")
        self.upd_check_btn.clicked.connect(self.action_check_updates)
        upd_row.addWidget(self.upd_check_btn)
        right_layout.addLayout(upd_row)

        self.upd_status_lbl = QLabel("System is up to date.")
        self.upd_status_lbl.setProperty("class", "mutedText")
        self.upd_status_lbl.setStyleSheet("font-size: 11px; padding: 2px;")
        right_layout.addWidget(self.upd_status_lbl)

        # Update details box
        self.upd_container = QFrame()
        self.upd_container.setStyleSheet("background: #111622; border: 1px solid #252D3D; border-radius: 8px; padding: 10px;")
        self.upd_container.setVisible(False)
        upd_c_lay = QVBoxLayout(self.upd_container)
        upd_c_lay.setContentsMargins(10, 8, 10, 8)
        upd_c_lay.setSpacing(6)

        self.upd_badge_lbl = QLabel("✨ New Update Available: v1.1.0")
        self.upd_badge_lbl.setStyleSheet("color: #10B981; font-weight: 800; font-size: 12px;")
        upd_c_lay.addWidget(self.upd_badge_lbl)

        self.upd_changelog_lbl = QLabel("")
        self.upd_changelog_lbl.setStyleSheet("color: #94A3B8; font-size: 11px;")
        self.upd_changelog_lbl.setWordWrap(True)
        upd_c_lay.addWidget(self.upd_changelog_lbl)

        self.upd_progress_bar = QProgressBar()
        self.upd_progress_bar.setRange(0, 100)
        self.upd_progress_bar.setValue(0)
        self.upd_progress_bar.setVisible(False)
        upd_c_lay.addWidget(self.upd_progress_bar)

        self.upd_apply_btn = QPushButton("⚡ Download & Upgrade Now")
        self.upd_apply_btn.setProperty("class", "primaryButton")
        self.upd_apply_btn.clicked.connect(self.action_start_update)
        upd_c_lay.addWidget(self.upd_apply_btn)

        right_layout.addWidget(self.upd_container)

        right_layout.addStretch(1)

        layout.addWidget(right_card, stretch=1)
        self.stacked_widget.addWidget(page)

    # ═════════════════════════════════════════════════════════════════════════
    # USER ACTIONS & HANDLERS
    # ═════════════════════════════════════════════════════════════════════════

    def action_check_qualities(self):
        url = self.t_url_input.text().strip()
        if not url:
            self.t_status_label.setText("⚠️ Please enter a video URL first.")
            return
        self.t_status_label.setText("🔍 Inspecting video stream qualities...")
        self.worker = InspectQualityThread(url)
        self.worker.sig_result.connect(self._on_qualities_loaded)
        self.worker.sig_error.connect(lambda err: self.t_status_label.setText(f"❌ {err}"))
        self.worker.start()

    def _on_qualities_loaded(self, choices, status):
        self.t_quality_combo.clear()
        self.t_quality_combo.addItems(choices)
        self.t_status_label.setText(status)

    def action_start_transcription(self):
        file_path = self.t_dropzone.current_file
        url = self.t_url_input.text().strip()
        quality = self.t_quality_combo.currentText()
        model_name = self.t_model_combo.currentText()
        language = self.t_lang_combo.currentText()

        if not file_path and not url:
            self.t_status_label.setText("⚠️ Please upload a file or paste a video URL first.")
            return

        if not file_path and url:
            self.t_start_btn.setEnabled(False)
            self.t_status_label.setText("⬇️ Downloading video from URL...")
            self.dl_worker = DownloadVideoThread(url, quality)
            self.dl_worker.sig_status.connect(lambda s: self.t_status_label.setText(s))
            self.dl_worker.sig_finished.connect(lambda p: self._on_download_complete(p, model_name, language))
            self.dl_worker.sig_error.connect(self._on_error)
            self.dl_worker.start()
        else:
            self._start_transcribe_worker(file_path, model_name, language)

    def _on_download_complete(self, file_path: str, model_name: str, language: str):
        self.t_dropzone.set_file(file_path)
        self._start_transcribe_worker(file_path, model_name, language)

    def _start_transcribe_worker(self, file_path: str, model_name: str, language: str):
        self.t_start_btn.setEnabled(False)
        self.t_output_text.clear()
        self.t_status_label.setText(f"🎙️ Transcribing: {Path(file_path).name} with {model_name}...")
        self.tr_worker = TranscribeThread(file_path, model_name, language)
        self.tr_worker.sig_status.connect(lambda s: self.t_status_label.setText(s))
        self.tr_worker.sig_log.connect(lambda m: self.t_output_text.appendPlainText(m))
        self.tr_worker.sig_finished.connect(self._on_transcribe_finished)
        self.tr_worker.sig_error.connect(self._on_error)
        self.tr_worker.start()

    def _on_transcribe_finished(self, result):
        self.t_start_btn.setEnabled(True)
        self.t_status_label.setText("✅ Transcription Complete! Ready to find viral clips in Tab 2.")
        self.t_output_text.clear()
        
        segments = getattr(result, 'segments', None)
        if not segments:
            try:
                sess_file = WORK_DIR / "session.json"
                if sess_file.exists():
                    sess = json.loads(sess_file.read_text(encoding="utf-8"))
                    tr_path = sess.get("transcript_json")
                    if tr_path and Path(tr_path).exists():
                        tr_data = json.loads(Path(tr_path).read_text(encoding="utf-8"))
                        segments = tr_data.get("segments", [])
            except Exception:
                segments = []

        lines = []
        for seg in (segments or []):
            st = getattr(seg, 'start', None)
            if st is None and isinstance(seg, dict):
                st = seg.get('start', 0.0)
            et = getattr(seg, 'end', None)
            if et is None and isinstance(seg, dict):
                et = seg.get('end', 0.0)
            txt = getattr(seg, 'text', None)
            if txt is None and isinstance(seg, dict):
                txt = seg.get('text', '')
            
            st = float(st) if st is not None else 0.0
            et = float(et) if et is not None else 0.0
            txt = str(txt or '').strip()
            if txt:
                lines.append(f"[{st:05.1f}s --> {et:05.1f}s]  {txt}")

        full_txt = "\n".join(lines) if lines else "Transcript generated successfully (0 segments returned)."
        self.t_output_text.setPlainText(full_txt)

        # Autonomous Project Persistence
        video_file = self.t_dropzone.get_file()
        sess_file = WORK_DIR / "session.json"
        tr_json_path = ""
        dur_val = getattr(result, 'duration', 0.0)
        if sess_file.exists():
            try:
                s_data = json.loads(sess_file.read_text(encoding="utf-8"))
                tr_json_path = s_data.get("transcript_json", "")
                if not dur_val:
                    dur_val = s_data.get("duration", 0.0)
            except Exception:
                pass

        proj_name = Path(video_file).stem[:35] if video_file else f"Project {time.strftime('%b %d, %H:%M')}"
        project_manager.save_project_state(self.active_project_id, {
            "name": proj_name,
            "source_video": video_file,
            "transcript_text": full_txt,
            "transcript_json": tr_json_path,
            "duration": dur_val
        })
        self._refresh_project_dropdown()
        self.autosave_status_lbl.setText("💾 Auto-Saved")

    # ═════════════════════════════════════════════════════════════════════════
    # PROJECT MANAGEMENT ACTIONS & RECOVERY
    # ═════════════════════════════════════════════════════════════════════════

    def _refresh_project_dropdown(self):
        if not hasattr(self, 'project_combo'):
            return
        self.project_combo.blockSignals(True)
        self.project_combo.clear()
        projects = project_manager.list_projects()
        active_pid = getattr(self, 'active_project_id', '')
        active_idx = 0
        for i, p in enumerate(projects):
            pid = p.get("project_id", "")
            pname = p.get("name", "Untitled")
            updated = p.get("updated_at", "")
            date_str = updated.split("T")[0] if "T" in updated else ""
            title = f"{pname} ({date_str})" if date_str else pname
            self.project_combo.addItem(title, pid)
            if pid == active_pid:
                active_idx = i
        if self.project_combo.count() > 0:
            self.project_combo.setCurrentIndex(active_idx)
        self.project_combo.blockSignals(False)

    def _on_project_combo_changed(self, index: int):
        if index < 0:
            return
        proj_id = self.project_combo.itemData(index)
        if proj_id and proj_id != getattr(self, 'active_project_id', ''):
            self.action_switch_project(proj_id)

    def action_create_new_project(self):
        state = project_manager.create_project()
        self.active_project_id = state["project_id"]
        self._refresh_project_dropdown()
        self._reset_ui_to_empty_project()
        self.autosave_status_lbl.setText("✨ New Project Created")
        QTimer.singleShot(2000, lambda: self.autosave_status_lbl.setText("💾 Auto-Saved"))

    def action_delete_current_project(self):
        if not hasattr(self, 'active_project_id') or not self.active_project_id:
            return
        project_manager.delete_project(self.active_project_id)
        self.active_project_id = project_manager.get_active_project_id()
        self._refresh_project_dropdown()
        self.action_switch_project(self.active_project_id)

    def action_switch_project(self, project_id: str):
        self.active_project_id = project_id
        project_manager.set_active_project_id(project_id)
        state = project_manager.load_project(project_id)
        if not state:
            return

        # 1. Restore Transcribe Tab
        src_video = state.get("source_video", "")
        if src_video and Path(src_video).exists():
            self.t_dropzone.set_file(src_video)
        else:
            self.t_dropzone.clear()

        tr_text = state.get("transcript_text", "")
        if tr_text:
            self.t_output_text.setPlainText(tr_text)
            self.t_status_label.setText(f"✅ Loaded Project: {state.get('name', 'Session')}")
        else:
            self.t_output_text.clear()
            self.t_status_label.setText("Ready to transcribe video.")

        # 2. Restore Viral Clips Tab
        clips = state.get("viral_clips", [])
        if clips:
            self._display_viral_clips(clips)
        else:
            while self.clips_container_layout.count() > 0:
                it = self.clips_container_layout.takeAt(0)
                if it.widget():
                    it.widget().deleteLater()
            empty_lbl = QLabel("No viral clips scored yet for this project. Run Step 2.")
            empty_lbl.setStyleSheet("color: #64748B; font-size: 12px; padding: 10px;")
            self.clips_container_layout.addWidget(empty_lbl)
            self.e_clip_combo.clear()

        # 3. Restore Editor Settings
        ed = state.get("editor_settings", {})
        if ed:
            if hasattr(self, 'e_face_enable_chk') and "enable_face_tracking" in ed:
                is_ft_en = bool(ed["enable_face_tracking"])
                self.e_face_enable_chk.setChecked(is_ft_en)
                self.e_face_dynamic.setEnabled(is_ft_en)
                self.e_face_simple.setEnabled(is_ft_en)
                self.e_face_multi.setEnabled(is_ft_en)
            if hasattr(self, 'e_face_simple') and "face_tracking_mode" in ed:
                mode_val = ed["face_tracking_mode"]
                if mode_val in ("simple", "center"):
                    self.e_face_simple.setChecked(True)
                elif mode_val in ("group", "multi"):
                    self.e_face_multi.setChecked(True)
                else:
                    self.e_face_dynamic.setChecked(True)
            if hasattr(self, 'e_aspect_combo') and "aspect_ratio" in ed:
                self.e_aspect_combo.setCurrentText(ed["aspect_ratio"])
            if hasattr(self, 'e_zoom_slider') and "zoom" in ed:
                self.e_zoom_slider.setValue(ed["zoom"])
            if hasattr(self, 'e_caps_chk') and "enable_captions" in ed:
                self.e_caps_chk.setChecked(ed["enable_captions"])
            if hasattr(self, 'e_cap_style_combo') and "caption_style" in ed:
                self.e_cap_style_combo.setCurrentText(ed["caption_style"])
            if hasattr(self, 'e_cap_size_slider') and "caption_font_size" in ed:
                self.e_cap_size_slider.setValue(int(ed["caption_font_size"]))
                if hasattr(self, 'e_cap_size_lbl'):
                    self.e_cap_size_lbl.setText(f"Font Size: {int(ed['caption_font_size'])}px")
            if hasattr(self, 'e_cap_y_slider') and "caption_y_pos" in ed:
                self.e_cap_y_slider.setValue(int(ed["caption_y_pos"]))
                if hasattr(self, 'e_cap_y_lbl'):
                    self.e_cap_y_lbl.setText(f"Placement Y: {int(ed['caption_y_pos'])}%")
            if hasattr(self, 'e_mirror_chk') and "enable_mirror" in ed:
                self.e_mirror_chk.setChecked(ed["enable_mirror"])
            if hasattr(self, 'e_gp_chk') and "enable_gameplay" in ed:
                self.e_gp_chk.setChecked(ed["enable_gameplay"])
            if hasattr(self, 'e_gp_preset') and "gameplay_preset" in ed:
                self.e_gp_preset.blockSignals(True)
                self.e_gp_preset.setCurrentText(ed["gameplay_preset"])
                self.e_gp_preset.blockSignals(False)
            if hasattr(self, 'e_gp_split_slider') and "gameplay_split_ratio" in ed:
                self.e_gp_split_slider.setValue(int(ed["gameplay_split_ratio"]))
            if hasattr(self, 'e_gp_y_slider') and "gameplay_y_pos" in ed:
                self.e_gp_y_slider.setValue(int(ed["gameplay_y_pos"]))
                if hasattr(self, 'e_gp_y_lbl'):
                    self.e_gp_y_lbl.setText(f"🎮 Gameplay Vertical Position (Y-Offset): {int(ed['gameplay_y_pos'])}%")
            custom_gp = ed.get("custom_gameplay_path", "")
            if custom_gp and Path(custom_gp).exists():
                self.custom_gameplay_path = custom_gp
                if hasattr(self, 'e_gp_custom_lbl'):
                    self.e_gp_custom_lbl.setText(f"Custom: {Path(custom_gp).name}")
                    self.e_gp_custom_lbl.setVisible(True)
            else:
                self.custom_gameplay_path = ""
                if hasattr(self, 'e_gp_custom_lbl'):
                    self.e_gp_custom_lbl.setVisible(False)

        # 4. Sync session.json and viral_clips.json for compatibility
        sess_meta = {
            "source_video": src_video,
            "session_dir": str(project_manager.PROJECTS_DIR / project_id),
            "transcript_json": state.get("transcript_json", ""),
            "duration": state.get("duration", 0.0)
        }
        (WORK_DIR / "session.json").write_text(json.dumps(sess_meta, indent=2), encoding="utf-8")
        if clips:
            (WORK_DIR / "viral_clips.json").write_text(json.dumps(clips, indent=2), encoding="utf-8")

        # 5. Reload editor player if clips exist
        self.action_reload_clips_dropdown()
        if self.e_clip_combo.count() > 0:
            self._on_player_clip_changed(0)

        self.autosave_status_lbl.setText("💾 Restored")
        QTimer.singleShot(2000, lambda: self.autosave_status_lbl.setText("💾 Auto-Saved"))

    def _reset_ui_to_empty_project(self):
        self.t_dropzone.clear()
        self.t_output_text.clear()
        self.t_status_label.setText("Ready to transcribe video.")
        while self.clips_container_layout.count() > 0:
            it = self.clips_container_layout.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        self.e_clip_combo.clear()
        if self.player_cap is not None:
            self.player_cap.release()
            self.player_cap = None
        if hasattr(self, 'media_player'):
            self.media_player.stop()
        self.e_video_canvas.setText("🎬 Select an active clip to preview in real-time")
        self.e_time_slider.setValue(0)
        self.e_time_lbl.setText("00:00 / 00:00")

    def load_cached_session_if_available(self):
        # Superseded by action_switch_project(active_project_id)
        pass

    def action_copy_transcript(self):
        txt = self.t_output_text.toPlainText()
        if txt:
            QApplication.clipboard().setText(txt)
            self.copy_transcript_btn.setText("✓ Copied!")
            QTimer.singleShot(1500, lambda: self.copy_transcript_btn.setText("📋 Copy"))

    def _on_duration_sliders_changed(self):
        min_v = self.s_min_slider.value()
        max_v = self.s_max_slider.value()
        if min_v > max_v:
            self.s_max_slider.setValue(min_v)
            max_v = min_v
        self.s_min_val_lbl.setText(f"Min: {min_v}s")
        self.s_max_val_lbl.setText(f"Max: {max_v}s")
        self.s_dur_lbl.setText(f"⏱️ Target Clip Length Range: {min_v}s – {max_v}s (Max Limit: 300s / 5 min)")

    def action_find_viral_clips(self):
        model_name = self.s_model_combo.currentText()
        auto_mode = self.s_auto_chk.isChecked()
        dynamic_hook = self.s_dynamic_chk.isChecked() if hasattr(self, 's_dynamic_chk') else True
        n_clips = self.s_nclips_slider.value() if hasattr(self, 's_nclips_slider') else 5
        min_dur = self.s_min_slider.value()
        max_dur = self.s_max_slider.value()
        prompt = self.s_prompt_input.toPlainText()

        self.s_find_btn.setEnabled(False)
        # Clear container
        while self.clips_container_layout.count() > 0:
            item = self.clips_container_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        mode_text = "⚡ AI Dynamic Smart Hook Mode" if dynamic_hook else ("AI Auto Mode" if auto_mode else f"Manual Mode ({n_clips} Clips)")
        lbl = QLabel(f"🤖 AI is extracting natural Hook-to-Climax viral moments ({mode_text})...")
        lbl.setStyleSheet("color: #E11D48; font-weight: 700; font-size: 13px; padding: 10px;")
        self.clips_container_layout.addWidget(lbl)

        self.sc_worker = ScoreViralClipsThread(model_name, auto_mode, min_dur, max_dur, prompt, n_clips, dynamic_hook_mode=dynamic_hook)
        self.sc_worker.sig_finished.connect(self._on_scoring_finished)
        self.sc_worker.sig_error.connect(self._on_error)
        self.sc_worker.start()

    def _on_scoring_finished(self, clips):
        self.s_find_btn.setEnabled(True)
        self._display_viral_clips(clips)
        
        # Save to project state
        clips_data = [c.to_dict() if hasattr(c, 'to_dict') else c for c in clips]
        project_manager.save_project_state(self.active_project_id, {
            "viral_clips": clips_data
        })
        self.autosave_status_lbl.setText("💾 Auto-Saved")

    def _display_viral_clips(self, clips):
        while self.clips_container_layout.count() > 0:
            item = self.clips_container_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if not clips:
            lbl = QLabel("No qualifying viral clips found. Try adjusting settings or prompt.")
            self.clips_container_layout.addWidget(lbl)
            return

        for i, c in enumerate(clips):
            card = QFrame()
            card.setProperty("class", "cardFrame")
            c_lay = QVBoxLayout(card)
            c_lay.setContentsMargins(16, 14, 16, 14)
            c_lay.setSpacing(8)

            row1 = QHBoxLayout()
            rank_lbl = QLabel(f"#{i+1}")
            rank_lbl.setStyleSheet("background: #0F172A; color: #FFFFFF; font-weight: 800; border-radius: 4px; padding: 2px 6px;")
            row1.addWidget(rank_lbl)

            title_str = c.get("title", f"Viral Moment #{i+1}") if isinstance(c, dict) else getattr(c, 'title', f"Viral Moment #{i+1}")
            title_lbl = QLabel(title_str)
            title_lbl.setStyleSheet("font-weight: 700; font-size: 13px;")
            row1.addWidget(title_lbl, stretch=1)

            # Dynamic Duration Tag Display
            dur_val = c.get("duration", 0) if isinstance(c, dict) else getattr(c, 'duration', 0)
            dur_tag = QLabel(f"⚡ {int(dur_val)}s")
            dur_tag.setStyleSheet("background: #EDE9FE; color: #7C3AED; font-weight: 800; border-radius: 6px; padding: 3px 8px;")
            row1.addWidget(dur_tag)

            score_val = c.get("score", 8.5) if isinstance(c, dict) else getattr(c, 'score', 8.5)
            score_badge = QLabel(f"🔥 {score_val:.1f}/10")
            score_badge.setStyleSheet("background: #FFF1F2; color: #E11D48; font-weight: 800; border-radius: 6px; padding: 3px 8px;")
            row1.addWidget(score_badge)
            c_lay.addLayout(row1)

            hook_str = c.get("hook", "") if isinstance(c, dict) else getattr(c, 'hook', '')
            if hook_str:
                hook_lbl = QLabel(f"💡 <i>{hook_str}</i>")
                hook_lbl.setStyleSheet("color: #64748B; font-size: 12px;")
                hook_lbl.setWordWrap(True)
                c_lay.addWidget(hook_lbl)

            row2 = QHBoxLayout()
            st_val = c.get("start", 0) if isinstance(c, dict) else getattr(c, 'start', 0)
            et_val = c.get("end", 0) if isinstance(c, dict) else getattr(c, 'end', 0)
            tr_lbl = QLabel(f"⏱️ {st_val:.1f}s --> {et_val:.1f}s (Natural Cut)")
            tr_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
            row2.addWidget(tr_lbl)
            row2.addStretch(1)

            edit_btn = QPushButton("✂️ Edit Clip")
            edit_btn.setProperty("class", "outlineButton")
            edit_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            edit_btn.clicked.connect(lambda checked, idx=i: self._on_select_clip_for_editing(idx))
            row2.addWidget(edit_btn)
            c_lay.addLayout(row2)

            self.clips_container_layout.addWidget(card)

        self.action_reload_clips_dropdown()

    def _on_select_clip_for_editing(self, clip_idx: int):
        self.action_reload_clips_dropdown()
        if clip_idx < self.e_clip_combo.count():
            self.e_clip_combo.setCurrentIndex(clip_idx)
        self.switch_tab(2)

    def action_reload_clips_dropdown(self):
        clips_file = WORK_DIR / "viral_clips.json"
        if clips_file.exists():
            clips = json.loads(clips_file.read_text(encoding="utf-8"))
            self.e_clip_combo.clear()
            for i, c in enumerate(clips):
                t = c.get("title", f"Clip #{i+1}")
                st = c.get("start", 0)
                et = c.get("end", 0)
                dur = et - st
                self.e_clip_combo.addItem(f"Clip #{i+1}: {t} [{st:.0f}s - {et:.0f}s ({dur:.0f}s)]")

    def action_render_clip(self, fast_preview: bool = False):
        idx = self.e_clip_combo.currentIndex()
        if idx < 0:
            self.e_console_log.appendPlainText("⚠️ Please select an active clip to render.")
            return

        # Forcefully terminate any previous render job or hanging child processes
        if hasattr(self, 'render_worker') and self.render_worker:
            try:
                if self.render_worker.isRunning():
                    self.render_worker.cancel()
                    self.render_worker.terminate()
                    self.render_worker.wait(1000)
            except Exception:
                pass

        try:
            import video_editor
            video_editor.terminate_all_active_subprocesses()
        except Exception:
            pass

        params = {
            "enable_face_crop": self.e_face_enable_chk.isChecked() if hasattr(self, 'e_face_enable_chk') else True,
            "face_tracking_mode": "multi" if self.e_face_multi.isChecked() else ("simple" if self.e_face_simple.isChecked() else "dynamic"),
            "aspect_ratio": self.e_aspect_combo.currentText(),
            "clip_zoom": float(self.e_zoom_slider.value()),
            "enable_captions": self.e_caps_chk.isChecked(),
            "caption_font_size": int(self.e_cap_size_slider.value()) if hasattr(self, 'e_cap_size_slider') else 18,
            "caption_style": self.e_cap_style_combo.currentText(),
            "caption_y_pos": float(self.e_cap_y_slider.value()) if hasattr(self, 'e_cap_y_slider') else 78.0,
            "enable_mirror": self.e_mirror_chk.isChecked(),
            "enable_gameplay": self.e_gp_chk.isChecked() if hasattr(self, 'e_gp_chk') else False,
            "gp_mode": "reel_split",
            "gameplay_video": self.get_active_gameplay_video_path() if (hasattr(self, 'e_gp_chk') and self.e_gp_chk.isChecked()) else None,
            "gameplay_split_ratio": float(self.e_gp_split_slider.value()) if hasattr(self, 'e_gp_split_slider') else 55.0,
            "gameplay_y_pos": float(self.e_gp_y_slider.value()) if hasattr(self, 'e_gp_y_slider') else 50.0,
            "gameplay_blend_pct": 15.0,
            "gameplay_scale": 100.0,
        }

        self.e_render_btn.setEnabled(False)
        self.e_console_log.clear()
        self.e_console_log.appendPlainText(f"🚀 Starting {'Fast Preview (8s)' if fast_preview else 'Full Clip Render'} for Clip #{idx+1}...")

        self.render_worker = RenderEditorThread(idx, params, fast_preview)
        self.render_worker.sig_log.connect(lambda m: self.e_console_log.appendPlainText(m))
        self.render_worker.sig_finished.connect(self._on_render_finished)
        self.render_worker.sig_error.connect(self._on_error)
        self.render_worker.finished.connect(self._on_render_worker_done)
        self.render_worker.start()

    def _on_render_worker_done(self):
        if hasattr(self, 'e_preview_btn'):
            self.e_preview_btn.setEnabled(True)
        if hasattr(self, 'e_render_btn'):
            self.e_render_btn.setEnabled(True)

    def _on_render_finished(self, out_path: str, is_fast: bool):
        try:
            self.e_console_log.appendPlainText(f"\n✅ {'Live Preview' if is_fast else 'Full Clip'} Rendered Successfully!")
            self.e_console_log.appendPlainText(f"📁 Output file: {out_path}")
            
            # Load rendered video directly into the Export Tab Review Player
            self._load_export_player(out_path, auto_play=True)

            if not is_fast:
                self.ex_status_lbl.setText(f"✅ Clip Ready for Export!\n{Path(out_path).name}")
                self.ex_filename_input.setText(f"viral_short_clip_{self.e_clip_combo.currentIndex() + 1}.mp4")
                self.switch_tab(3) # Automatically navigate to Tab 4: Export
            else:
                self.ex_status_lbl.setText(f"✓ Fast preview ready:\n{out_path}")
        finally:
            self._on_render_worker_done()

    def action_browse_export_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Select Export Folder", self.ex_folder_input.text())
        if d:
            self.ex_folder_input.setText(d)

    def action_save_export(self):
        folder = self.ex_folder_input.text().strip()
        fname = self.ex_filename_input.text().strip()
        if not fname.lower().endswith(".mp4"):
            fname += ".mp4"
        out_dir = Path(folder)
        out_dir.mkdir(parents=True, exist_ok=True)
        dest = out_dir / fname

        # Copy latest rendered / reviewed clip
        src = getattr(self, 'current_export_video_path', '')
        if not src or not Path(src).exists():
            clip_idx = max(0, self.e_clip_combo.currentIndex())
            src = WORK_DIR / "editor" / f"clip_{clip_idx + 1}" / "edited.mp4"
            if not src.exists():
                src = WORK_DIR / "editor" / f"clip_{clip_idx + 1}" / "preview_fast.mp4"
        
        if src and Path(src).exists():
            shutil.copy2(src, dest)
            sz = dest.stat().st_size / (1024 * 1024)
            self.ex_status_lbl.setText(f"✅ Exported successfully!\n📁 Path: {dest}\n📊 Size: {sz:.1f} MB")
            self.ex_status_lbl.setStyleSheet("color: #10B981; font-weight: 700; font-size: 12px; padding: 4px;")
        else:
            self.ex_status_lbl.setText("⚠️ No rendered clip found to export. Render in Tab 3 first.")

    def action_open_export_folder(self):
        f = self.ex_folder_input.text().strip()
        if Path(f).exists():
            os.startfile(f)

    def action_browse_settings_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Default Export Folder", self.set_folder_input.text())
        if folder:
            self.set_folder_input.setText(folder)
            cfg.set_output_folder(folder)
            if hasattr(self, 'ex_folder_input'):
                self.ex_folder_input.setText(folder)

    def action_copy_hwid(self):
        hwid = license_check.get_hwid()
        QApplication.clipboard().setText(hwid)
        if hasattr(self, 'lic_msg_lbl'):
            self.lic_msg_lbl.setText("✅ Machine HWID copied to clipboard!")
            self.lic_msg_lbl.setStyleSheet("color: #10B981; font-weight: 600; font-size: 12px; padding: 4px;")

    def _toggle_key_visibility(self, line_edit: QLineEdit, btn: QPushButton):
        if line_edit.echoMode() == QLineEdit.EchoMode.Password:
            line_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            btn.setText("🙈 Hide")
        else:
            line_edit.setEchoMode(QLineEdit.EchoMode.Password)
            btn.setText("👁️ Show")

    def auto_save_api_keys(self):
        """Continuously auto-save API keys and destination folder to disk on text change."""
        try:
            keys_payload = {
                "gemini": self.gem_keys_input.text() if hasattr(self, 'gem_keys_input') else "",
                "groq": self.groq_keys_input.text() if hasattr(self, 'groq_keys_input') else "",
            }
            if hasattr(self, 'dg_keys_input'):
                keys_payload["deepgram"] = self.dg_keys_input.text()
            if hasattr(self, 'oai_keys_input'):
                keys_payload["openai"] = self.oai_keys_input.text()
            if hasattr(self, 'claude_keys_input'):
                keys_payload["anthropic"] = self.claude_keys_input.text()
            if hasattr(self, 'deepseek_keys_input'):
                keys_payload["deepseek"] = self.deepseek_keys_input.text()

            f_path = self.set_folder_input.text().strip() if hasattr(self, 'set_folder_input') else ""
            cfg.save_all_keys(keys_payload, output_folder=f_path)
        except Exception:
            pass

    def action_save_api_keys(self):
        keys_payload = {
            "gemini": self.gem_keys_input.text(),
            "groq": self.groq_keys_input.text(),
        }
        if hasattr(self, 'dg_keys_input'):
            keys_payload["deepgram"] = self.dg_keys_input.text()
        if hasattr(self, 'oai_keys_input'):
            keys_payload["openai"] = self.oai_keys_input.text()
        if hasattr(self, 'claude_keys_input'):
            keys_payload["anthropic"] = self.claude_keys_input.text()
        if hasattr(self, 'deepseek_keys_input'):
            keys_payload["deepseek"] = self.deepseek_keys_input.text()

        f_path = self.set_folder_input.text().strip() if hasattr(self, 'set_folder_input') else ""
        cfg.save_all_keys(keys_payload, output_folder=f_path)
        if hasattr(self, 'ex_folder_input') and f_path:
            self.ex_folder_input.setText(f_path)

        # Refresh inputs with sanitized values from disk
        self._reload_settings_from_disk()

        # Structural format checks
        warnings = []
        gem_list = cfg.get_gemini_keys()
        if gem_list and not any(k.startswith("AIza") for k in gem_list):
            warnings.append("⚠️ Gemini key: Standard Google AI Studio keys start with 'AIza...'")

        groq_list = cfg.get_groq_keys()
        if groq_list and not any(k.startswith("gsk_") for k in groq_list):
            warnings.append("⚠️ Groq key: Standard Groq Cloud keys start with 'gsk_...'")

        if warnings:
            msg = "✅ Saved & Synced! " + " | ".join(warnings)
            color = "#F59E0B"
        else:
            msg = "✅ All Settings, API Keys & Output Destination saved & synced to disk!"
            color = "#10B981"

        if hasattr(self, 't_status_label'):
            self.t_status_label.setText("✅ Settings & API Keys saved successfully!")
        if hasattr(self, 'lic_msg_lbl'):
            self.lic_msg_lbl.setText(msg)
            self.lic_msg_lbl.setStyleSheet(f"color: {color}; font-weight: 600; font-size: 12px; padding: 4px;")

    def action_activate_license(self):
        k = self.lic_key_input.text().strip()
        ok, msg = license_check.activate_license(k)
        self.lic_msg_lbl.setText(msg)
        if ok:
            self.lic_msg_lbl.setStyleSheet("color: #10B981; font-weight: 700; font-size: 12px; padding: 4px;")
        else:
            self.lic_msg_lbl.setStyleSheet("color: #FB7185; font-weight: 700; font-size: 12px; padding: 4px;")
        self.refresh_license_status()

    def refresh_license_status(self):
        acc = license_check.check_access()
        if hasattr(self, 'trial_badge'):
            status_txt = acc.get("status_label", "Trial Mode")
            self.trial_badge.setText(status_txt)
            if acc.get("is_activated"):
                self.trial_badge.setStyleSheet("background: #064E3B; border: 1px solid #10B981; color: #A7F3D0; font-weight: 700; font-size: 12px; border-radius: 20px; padding: 5px 14px;")
            elif acc.get("allowed"):
                self.trial_badge.setStyleSheet("background: #451A03; border: 1px solid #F59E0B; color: #FDE68A; font-weight: 600; font-size: 12px; border-radius: 20px; padding: 5px 14px;")
            else:
                self.trial_badge.setStyleSheet("background: #450A0A; border: 1px solid #EF4444; color: #FCA5A5; font-weight: 800; font-size: 12px; border-radius: 20px; padding: 5px 14px;")

    def action_show_activation_dialog(self, force_modal: bool = False):
        from PyQt6.QtWidgets import QDialog
        acc = license_check.check_access()
        dlg = QDialog(self)
        dlg.setWindowTitle("🔐 Software License Activation")
        dlg.setFixedSize(520, 380)
        dlg.setStyleSheet(DARK_THEME_QSS if getattr(self, 'is_dark_theme', True) else LIGHT_THEME_QSS)

        d_layout = QVBoxLayout(dlg)
        d_layout.setContentsMargins(24, 20, 24, 20)
        d_layout.setSpacing(14)

        t_lbl = QLabel("<h2 style='color:#38BDF8;'>🔑 Activate NS Clipper Pro</h2>")
        d_layout.addWidget(t_lbl)

        status_txt = acc.get("status_label", "")
        s_lbl = QLabel(f"Current Status: <b>{status_txt}</b>")
        s_lbl.setWordWrap(True)
        d_layout.addWidget(s_lbl)

        # HWID box
        d_layout.addWidget(QLabel("Your Machine HWID (Share with seller):"))
        h_box = QHBoxLayout()
        hwid_val = license_check.get_hwid()
        h_input = QLineEdit(hwid_val)
        h_input.setReadOnly(True)
        h_box.addWidget(h_input, stretch=3)
        c_btn = QPushButton("📋 Copy HWID")
        c_btn.setProperty("class", "secondaryButton")
        c_btn.clicked.connect(lambda: (QApplication.clipboard().setText(hwid_val), c_btn.setText("✓ Copied!")))
        h_box.addWidget(c_btn, stretch=1)
        d_layout.addLayout(h_box)

        # Key Input
        d_layout.addWidget(QLabel("Enter Cryptographic License Key:"))
        k_input = QLineEdit()
        k_input.setPlaceholderText("NSC-XXXX-XXXX-XXXX-XXXX")
        d_layout.addWidget(k_input)

        msg_lbl = QLabel("")
        msg_lbl.setWordWrap(True)
        d_layout.addWidget(msg_lbl)

        act_btn = QPushButton("⚡ Activate Pro License")
        act_btn.setProperty("class", "primaryButton")
        
        def _on_act():
            key = k_input.text().strip()
            ok, msg = license_check.activate_license(key)
            msg_lbl.setText(msg)
            if ok:
                msg_lbl.setStyleSheet("color: #10B981; font-weight: 700;")
                self.refresh_license_status()
                QTimer.singleShot(1500, dlg.accept)
            else:
                msg_lbl.setStyleSheet("color: #EF4444; font-weight: 700;")

        act_btn.clicked.connect(_on_act)
        d_layout.addWidget(act_btn)

        supp_lbl = QLabel("<span style='font-size:11px; color:#94A3B8;'>WhatsApp: +1 307 776 8444 | Email: support@nsclipper.com</span>")
        supp_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        d_layout.addWidget(supp_lbl)

        dlg.exec()

    def _on_error(self, err_msg: str):
        try:
            import video_editor
            video_editor.terminate_all_active_subprocesses()
        except Exception:
            pass
        try:
            self.t_status_label.setText(f"❌ Error: {err_msg}")
            if hasattr(self, 'e_console_log'):
                self.e_console_log.appendPlainText(f"\n[ERROR] {err_msg}")
        finally:
            if hasattr(self, 't_start_btn'):
                self.t_start_btn.setEnabled(True)
            if hasattr(self, 's_find_btn'):
                self.s_find_btn.setEnabled(True)
            if hasattr(self, 'e_preview_btn'):
                self.e_preview_btn.setEnabled(True)
            if hasattr(self, 'e_render_btn'):
                self.e_render_btn.setEnabled(True)

    # ═════════════════════════════════════════════════════════════════════════
    # REAL-TIME EMBEDDED LIVE VIDEO PLAYER ENGINE WITH SYNCHRONIZED AUDIO
    # ═════════════════════════════════════════════════════════════════════════

    def _init_live_player(self):
        self.player_cap = None
        self.gameplay_cap = None
        self.player_is_playing = False
        self.player_current_frame = 0
        self.player_total_clip_frames = 0
        self.player_start_frame = 0
        self.player_end_frame = 0
        self.player_fps = 30.0
        self.player_segments = []
        self.custom_gameplay_path = ""
        self.player_timer = QTimer()
        self.player_timer.timeout.connect(self._on_player_tick)

        # Native QMediaPlayer for synchronized live audio playback
        self.media_player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.media_player.setAudioOutput(self.audio_output)
        self.audio_output.setVolume(1.0)

        # YuNet detector for live preview face tracking
        yunet_path = str(get_resource_path("models/face_detection_yunet_2023mar.onnx"))
        self.player_detector = None
        self._player_ema_cx = None
        self._player_ema_cy = None
        self._player_lost_frames = 0
        if hasattr(cv2, 'FaceDetectorYN') and os.path.exists(yunet_path) and os.path.getsize(yunet_path) > 50000:
            try:
                self.player_detector = cv2.FaceDetectorYN.create(
                    model=yunet_path,
                    config="",
                    input_size=(320, 240),
                    score_threshold=0.40,
                    nms_threshold=0.3,
                    top_k=500
                )
            except Exception:
                self.player_detector = None

    def get_active_gameplay_video_path(self) -> str:
        if self.custom_gameplay_path and Path(self.custom_gameplay_path).exists():
            return self.custom_gameplay_path
        preset_name = self.e_gp_preset.currentText() if hasattr(self, 'e_gp_preset') else "Subway Surfers (Loop)"
        gp_map = {
            "Subway Surfers (Loop)": get_resource_path("assets/gameplay/subway_runner.mp4"),
            "Minecraft Parkour (Loop)": get_resource_path("assets/gameplay/minecraft_parkour.mp4"),
            "GTA V Stunt Ramp (Loop)": get_resource_path("assets/gameplay/gta_stunt.mp4"),
            "Kinetic Sand / Slime (Loop)": get_resource_path("assets/gameplay/kinetic_sand.mp4"),
        }
        p = gp_map.get(preset_name, get_resource_path("assets/gameplay/default_gameplay.mp4"))
        if p.exists():
            return str(p)
        gp_dir = get_resource_path("assets/gameplay")
        if gp_dir.exists():
            for f in gp_dir.glob("*.mp4"):
                return str(f)
        return ""

    def action_upload_custom_gameplay(self):
        f, _ = QFileDialog.getOpenFileName(self, "Select Custom Gameplay / B-Roll Video", "", "Video Files (*.mp4 *.mov *.mkv *.webm *.avi)")
        if f:
            self.custom_gameplay_path = f
            self.e_gp_custom_lbl.setText(f"Custom: {Path(f).name}")
            self.e_gp_custom_lbl.setVisible(True)
            self._init_gameplay_cap()
            self._render_current_player_frame()

    def _on_gameplay_toggled(self, checked: bool):
        try:
            if checked:
                self._init_gameplay_cap()
            else:
                if self.gameplay_cap is not None:
                    try:
                        self.gameplay_cap.release()
                    except Exception:
                        pass
                    self.gameplay_cap = None
            self._render_current_player_frame()
            self._on_editor_settings_changed()
        except Exception as te:
            if hasattr(self, 'e_console_log'):
                self.e_console_log.appendPlainText(f"[Gameplay Toggle Warning] {te}")

    def _on_gameplay_preset_changed(self):
        self.custom_gameplay_path = ""
        self.e_gp_custom_lbl.setVisible(False)
        if hasattr(self, 'e_gp_chk') and self.e_gp_chk.isChecked():
            self._init_gameplay_cap()
        self._render_current_player_frame()

    def _on_gameplay_split_changed(self, val: int):
        top_pct = val
        bot_pct = 100 - val
        self.e_gp_split_lbl.setText(f"Split: {top_pct}% Top / {bot_pct}% Gameplay")
        self._render_current_player_frame()

    def _on_gameplay_y_changed(self, val: int):
        if hasattr(self, 'e_gp_y_lbl'):
            self.e_gp_y_lbl.setText(f"🎮 Gameplay Vertical Position (Y-Offset): {val}%")
        self._render_current_player_frame()

    def _on_cap_size_changed(self, val: int):
        if hasattr(self, 'e_cap_size_lbl'):
            self.e_cap_size_lbl.setText(f"Font Size: {val}px")
        self._on_editor_settings_changed()

    def _on_cap_y_changed(self, val: int):
        if hasattr(self, 'e_cap_y_lbl'):
            self.e_cap_y_lbl.setText(f"Placement Y: {val}%")
        self._on_editor_settings_changed()

    def _on_face_enable_toggled(self, checked: bool):
        if hasattr(self, 'e_face_dynamic'):
            self.e_face_dynamic.setEnabled(checked)
        if hasattr(self, 'e_face_simple'):
            self.e_face_simple.setEnabled(checked)
        if hasattr(self, 'e_face_multi'):
            self.e_face_multi.setEnabled(checked)
        self._on_editor_settings_changed()

    def _on_editor_settings_changed(self):
        self._render_current_player_frame()
        if hasattr(self, 'active_project_id') and self.active_project_id:
            ft_mode = "dynamic"
            if hasattr(self, 'e_face_simple') and self.e_face_simple.isChecked():
                ft_mode = "simple"
            elif hasattr(self, 'e_face_multi') and self.e_face_multi.isChecked():
                ft_mode = "multi"
                
            ed_settings = {
                "enable_face_tracking": self.e_face_enable_chk.isChecked() if hasattr(self, 'e_face_enable_chk') else True,
                "face_tracking_mode": ft_mode,
                "aspect_ratio": self.e_aspect_combo.currentText() if hasattr(self, 'e_aspect_combo') else "9:16 (Portrait)",
                "zoom": self.e_zoom_slider.value() if hasattr(self, 'e_zoom_slider') else 100,
                "enable_captions": self.e_caps_chk.isChecked() if hasattr(self, 'e_caps_chk') else True,
                "caption_style": self.e_cap_style_combo.currentText() if hasattr(self, 'e_cap_style_combo') else "Hormozi Classic Pop",
                "caption_font_size": self.e_cap_size_slider.value() if hasattr(self, 'e_cap_size_slider') else 18,
                "caption_y_pos": self.e_cap_y_slider.value() if hasattr(self, 'e_cap_y_slider') else 78,
                "enable_mirror": self.e_mirror_chk.isChecked() if hasattr(self, 'e_mirror_chk') else False,
                "enable_gameplay": self.e_gp_chk.isChecked() if hasattr(self, 'e_gp_chk') else False,
                "gameplay_preset": self.e_gp_preset.currentText() if hasattr(self, 'e_gp_preset') else "Subway Surfers (Loop)",
                "gameplay_split_ratio": self.e_gp_split_slider.value() if hasattr(self, 'e_gp_split_slider') else 55,
                "gameplay_y_pos": self.e_gp_y_slider.value() if hasattr(self, 'e_gp_y_slider') else 50,
                "custom_gameplay_path": getattr(self, 'custom_gameplay_path', '')
            }
            project_manager.save_project_state(self.active_project_id, {"editor_settings": ed_settings})
            if hasattr(self, 'autosave_status_lbl'):
                self.autosave_status_lbl.setText("💾 Auto-Saved")

    def _init_gameplay_cap(self):
        try:
            if self.gameplay_cap is not None:
                try:
                    self.gameplay_cap.release()
                except Exception:
                    pass
                self.gameplay_cap = None
            gp_path = self.get_active_gameplay_video_path()
            if gp_path and Path(gp_path).is_file():
                self.gameplay_cap = cv2.VideoCapture(str(gp_path))
                if not self.gameplay_cap.isOpened():
                    self.gameplay_cap = None
                    if hasattr(self, 'e_console_log'):
                        self.e_console_log.appendPlainText("[Warning] Could not open gameplay video stream. Using fallback matte.")
            else:
                self.gameplay_cap = None
                if hasattr(self, 'e_console_log'):
                    self.e_console_log.appendPlainText("[Warning] Gameplay video not found at path. Using fallback color matte.")
        except Exception as ge:
            self.gameplay_cap = None
            if hasattr(self, 'e_console_log'):
                self.e_console_log.appendPlainText(f"[Gameplay Init Warning] {ge}")

    def _on_player_clip_changed(self, idx: int):
        if idx < 0:
            return
        try:
            clips_file = WORK_DIR / "viral_clips.json"
            if not clips_file.exists():
                return
            clips = json.loads(clips_file.read_text(encoding="utf-8"))
            if idx >= len(clips):
                return
            clip = clips[idx]

            # Load raw original source video
            sess_file = WORK_DIR / "session.json"
            source_video = ""
            if sess_file.exists():
                sess = json.loads(sess_file.read_text(encoding="utf-8"))
                source_video = sess.get("source_video", "")
                tr_path = sess.get("transcript_json", "")
                if tr_path and Path(tr_path).exists():
                    try:
                        tr_data = json.loads(Path(tr_path).read_text(encoding="utf-8"))
                        self.player_segments = tr_data.get("segments", [])
                    except Exception:
                        self.player_segments = []

            if not source_video or not Path(source_video).exists():
                rendered_clip = WORK_DIR / "editor" / f"clip_{idx + 1}" / "edited.mp4"
                if rendered_clip.exists():
                    source_video = str(rendered_clip)
                else:
                    return

            st_sec = float(clip.get("start", 0.0))
            end_sec = float(clip.get("end", st_sec + 30.0))
            dur_sec = max(1.0, end_sec - st_sec)

            if self.player_cap is not None:
                self.player_cap.release()

            self.player_cap = cv2.VideoCapture(source_video)
            if not self.player_cap.isOpened():
                return

            fps = self.player_cap.get(cv2.CAP_PROP_FPS)
            self.player_fps = fps if fps and fps > 5.0 else 30.0
            self.player_start_frame = int(st_sec * self.player_fps)
            self.player_total_clip_frames = max(1, int(dur_sec * self.player_fps))
            self.player_end_frame = self.player_start_frame + self.player_total_clip_frames
            self.player_current_frame = 0

            self.e_time_slider.blockSignals(True)
            self.e_time_slider.setRange(0, max(1, self.player_total_clip_frames))
            self.e_time_slider.setValue(0)
            self.e_time_slider.blockSignals(False)

            # Initialize synchronized audio stream at clip start
            self.media_player.setSource(QUrl.fromLocalFile(source_video))
            self.media_player.setPosition(int(st_sec * 1000))

            if hasattr(self, 'e_gp_chk') and self.e_gp_chk.isChecked():
                self._init_gameplay_cap()

            self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.player_start_frame)
            self._render_current_player_frame()
            self._update_player_time_label()

            if hasattr(self, 'e_console_log'):
                self.e_console_log.appendPlainText(f"[Player] Loaded Source Clip #{idx+1}: {clip.get('title', '')} ({dur_sec:.1f}s)")
        except Exception as e:
            if hasattr(self, 'e_console_log'):
                self.e_console_log.appendPlainText(f"[Player] Info: {e}")

    def _render_current_player_frame(self, seek: bool = False):
        try:
            if self.player_cap is None or not self.player_cap.isOpened():
                return
            if seek:
                self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.player_start_frame + self.player_current_frame)
            ret, frame = self.player_cap.read()
            if not ret or frame is None or frame.size == 0:
                self.player_current_frame = 0
                self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.player_start_frame)
                ret, frame = self.player_cap.read()
                if not ret or frame is None or frame.size == 0:
                    return

            orig_h, orig_w = frame.shape[:2]
            if orig_h <= 0 or orig_w <= 0:
                return

            # 1. Calculate Target Aspect Ratio
            is_gp_active = hasattr(self, 'e_gp_chk') and self.e_gp_chk.isChecked()
            if is_gp_active:
                split_ratio = max(0.2, min(0.8, float(self.e_gp_split_slider.value()) / 100.0 if hasattr(self, 'e_gp_split_slider') else 0.55))
                target_w = 1080
                target_h = 1920
                top_h = max(20, int(target_h * split_ratio))
                bot_h = max(20, target_h - top_h)
                target_ar = float(target_w) / float(top_h)
            else:
                aspect_text = self.e_aspect_combo.currentText() if hasattr(self, 'e_aspect_combo') else "9:16 (Portrait)"
                if "16:9" in aspect_text or "Landscape" in aspect_text:
                    target_ar = 16.0 / 9.0
                elif "1:1" in aspect_text or "Square" in aspect_text:
                    target_ar = 1.0
                elif "4:5" in aspect_text:
                    target_ar = 4.0 / 5.0
                elif "4:3" in aspect_text:
                    target_ar = 4.0 / 3.0
                elif "21:9" in aspect_text:
                    target_ar = 21.0 / 9.0
                else: # 9:16 Portrait default
                    target_ar = 9.0 / 16.0

            if orig_w / float(orig_h) > target_ar:
                crop_h = orig_h
                crop_w = int(orig_h * target_ar)
            else:
                crop_w = orig_w
                crop_h = int(orig_w / target_ar)

            zoom = float(self.e_zoom_slider.value()) / 100.0 if hasattr(self, 'e_zoom_slider') else 1.0
            crop_w = max(10, int(crop_w / max(0.1, zoom)))
            crop_h = max(10, int(crop_h / max(0.1, zoom)))

            # Center Calculation (AI Face Tracking vs Fallback Center Crop)
            is_ft_enabled = self.e_face_enable_chk.isChecked() if hasattr(self, 'e_face_enable_chk') else True

            cx, cy = orig_w // 2, orig_h // 2
            if is_ft_enabled and hasattr(self, 'player_detector') and self.player_detector is not None:
                try:
                    should_detect = (self.player_current_frame % 4 == 0) or (getattr(self, '_player_locked_cx', None) is None) or seek
                    if should_detect:
                        scale = min(240.0 / float(orig_w), 160.0 / float(orig_h))
                        dw, dh = max(2, int(orig_w * scale)), max(2, int(orig_h * scale))
                        det_frame = cv2.resize(frame, (dw, dh), interpolation=cv2.INTER_AREA)
                        self.player_detector.setInputSize((dw, dh))
                        _, faces = self.player_detector.detect(det_frame)
                        dist_thresh = orig_w * 0.20

                    if faces is not None and len(faces) > 0:
                        parsed_faces = []
                        for f in faces:
                            fx, fy, fw, fh = float(f[0]), float(f[1]), float(f[2]), float(f[3])
                            fcx = (fx + fw / 2.0) / scale
                            fcy = (fy + fh / 2.0) / scale
                            parsed_faces.append((fcx, fcy, fw / scale, fh / scale, float(f[2]) * float(f[3])))

                        locked_cx = getattr(self, '_player_locked_cx', None)
                        locked_cy = getattr(self, '_player_locked_cy', None)

                        if locked_cx is None:
                            best = max(parsed_faces, key=lambda f: f[4])
                            self._player_locked_cx = best[0]
                            self._player_locked_cy = best[1]
                            self._player_ema_cx = best[0]
                            self._player_ema_cy = best[1]
                            self._player_cand_frames = 0
                            self._player_cand_cx = None
                            self._player_cand_cy = None
                            cx, cy = int(best[0]), int(best[1])
                        else:
                            # Match Person A
                            matched = None
                            other = []
                            for pf in parsed_faces:
                                if math.hypot(pf[0] - locked_cx, pf[1] - locked_cy) < dist_thresh:
                                    if matched is None or pf[4] > matched[4]:
                                        matched = pf
                                else:
                                    other.append(pf)

                            if matched is not None:
                                if other:
                                    best_o = max(other, key=lambda f: f[4])
                                    if best_o[4] >= matched[4] * 1.05:
                                        cand_cx = getattr(self, '_player_cand_cx', None)
                                        cand_cy = getattr(self, '_player_cand_cy', None)
                                        if cand_cx is not None and math.hypot(best_o[0] - cand_cx, best_o[1] - cand_cy) < dist_thresh:
                                            self._player_cand_frames = getattr(self, '_player_cand_frames', 0) + 1
                                            self._player_cand_cx = best_o[0]
                                            self._player_cand_cy = best_o[1]
                                        else:
                                            self._player_cand_cx = best_o[0]
                                            self._player_cand_cy = best_o[1]
                                            self._player_cand_frames = 1

                                        if getattr(self, '_player_cand_frames', 0) >= 36:
                                            # Instant snap cut to Person B
                                            self._player_ema_cx = self._player_cand_cx
                                            self._player_ema_cy = self._player_cand_cy
                                            self._player_locked_cx = self._player_cand_cx
                                            self._player_locked_cy = self._player_cand_cy
                                            self._player_cand_frames = 0
                                            self._player_cand_cx = None
                                            self._player_cand_cy = None
                                        else:
                                            # Dead-still lock on Person A
                                            dx = matched[0] - self._player_ema_cx
                                            dy = matched[1] - self._player_ema_cy
                                            if math.hypot(dx, dy) > 25.0:
                                                self._player_ema_cx = 0.04 * matched[0] + 0.96 * self._player_ema_cx
                                                self._player_ema_cy = 0.04 * matched[1] + 0.96 * self._player_ema_cy
                                            self._player_locked_cx = matched[0]
                                            self._player_locked_cy = matched[1]
                                    else:
                                        self._player_cand_frames = max(0, getattr(self, '_player_cand_frames', 0) - 2)
                                        dx = matched[0] - self._player_ema_cx
                                        dy = matched[1] - self._player_ema_cy
                                        if math.hypot(dx, dy) > 25.0:
                                            self._player_ema_cx = 0.04 * matched[0] + 0.96 * self._player_ema_cx
                                            self._player_ema_cy = 0.04 * matched[1] + 0.96 * self._player_ema_cy
                                        self._player_locked_cx = matched[0]
                                        self._player_locked_cy = matched[1]
                                else:
                                    self._player_cand_frames = max(0, getattr(self, '_player_cand_frames', 0) - 2)
                                    dx = matched[0] - self._player_ema_cx
                                    dy = matched[1] - self._player_ema_cy
                                    if math.hypot(dx, dy) > 25.0:
                                        self._player_ema_cx = 0.04 * matched[0] + 0.96 * self._player_ema_cx
                                        self._player_ema_cy = 0.04 * matched[1] + 0.96 * self._player_ema_cy
                                    self._player_locked_cx = matched[0]
                                    self._player_locked_cy = matched[1]
                            else:
                                # Person A lost, candidate new speaker
                                best_char = max(parsed_faces, key=lambda f: f[4])
                                if math.hypot(best_char[0] - locked_cx, best_char[1] - locked_cy) >= dist_thresh:
                                    cand_cx = getattr(self, '_player_cand_cx', None)
                                    cand_cy = getattr(self, '_player_cand_cy', None)
                                    if cand_cx is not None and math.hypot(best_char[0] - cand_cx, best_char[1] - cand_cy) < dist_thresh:
                                        self._player_cand_frames = getattr(self, '_player_cand_frames', 0) + 1
                                        self._player_cand_cx = best_char[0]
                                        self._player_cand_cy = best_char[1]
                                    else:
                                        self._player_cand_cx = best_char[0]
                                        self._player_cand_cy = best_char[1]
                                        self._player_cand_frames = 1

                                    if getattr(self, '_player_cand_frames', 0) >= 36:
                                        self._player_ema_cx = self._player_cand_cx
                                        self._player_ema_cy = self._player_cand_cy
                                        self._player_locked_cx = self._player_cand_cx
                                        self._player_locked_cy = self._player_cand_cy
                                        self._player_cand_frames = 0
                                        self._player_cand_cx = None
                                        self._player_cand_cy = None
                                else:
                                    self._player_locked_cx = best_char[0]
                                    self._player_locked_cy = best_char[1]
                                    dx = best_char[0] - self._player_ema_cx
                                    dy = best_char[1] - self._player_ema_cy
                                    if math.hypot(dx, dy) > 25.0:
                                        self._player_ema_cx = 0.04 * best_char[0] + 0.96 * self._player_ema_cx
                                        self._player_ema_cy = 0.04 * best_char[1] + 0.96 * self._player_ema_cy

                            cx, cy = int(self._player_ema_cx), int(self._player_ema_cy)
                        self._player_lost_frames = 0
                    else:
                        lost = getattr(self, '_player_lost_frames', 0) + 1
                        self._player_lost_frames = lost
                        if lost <= 45 and getattr(self, '_player_ema_cx', None) is not None:
                            cx = int(self._player_ema_cx)
                            cy = int(self._player_ema_cy)
                        else:
                            if getattr(self, '_player_ema_cx', None) is not None:
                                self._player_ema_cx = 0.02 * float(orig_w / 2.0) + 0.98 * self._player_ema_cx
                                self._player_ema_cy = 0.02 * float(orig_h / 2.0) + 0.98 * self._player_ema_cy
                                cx, cy = int(self._player_ema_cx), int(self._player_ema_cy)
                            else:
                                cx, cy = orig_w // 2, orig_h // 2
                except Exception:
                    cx, cy = orig_w // 2, orig_h // 2
            else:
                self._player_ema_cx = None
                self._player_ema_cy = None
                self._player_locked_cx = None
                self._player_locked_cy = None
                self._player_cand_cx = None
                self._player_cand_cy = None
                self._player_cand_frames = 0
                self._player_lost_frames = 0
                cx, cy = orig_w // 2, orig_h // 2

            x1 = max(0, min(orig_w - crop_w, cx - crop_w // 2))
            y1 = max(0, min(orig_h - crop_h, cy - crop_h // 2))
            x2 = min(orig_w, x1 + crop_w)
            y2 = min(orig_h, y1 + crop_h)

            cropped = frame[y1:y2, x1:x2]
            if cropped is None or cropped.size == 0:
                cropped = frame

            if hasattr(self, 'e_mirror_chk') and self.e_mirror_chk.isChecked():
                cropped = cv2.flip(cropped, 1)

            # 2. Split Gameplay Overlay (If Enabled)
            if is_gp_active:
                try:
                    split_ratio = float(self.e_gp_split_slider.value()) / 100.0 if hasattr(self, 'e_gp_split_slider') else 0.55
                    split_ratio = max(0.2, min(0.8, split_ratio))
                    target_w = 1080
                    top_h = int(1920 * split_ratio)
                    bottom_h = 1920 - top_h

                    top_resized = cv2.resize(cropped, (target_w, top_h), interpolation=cv2.INTER_LINEAR)
                    bottom_resized = None

                    if self.gameplay_cap is None:
                        self._init_gameplay_cap()

                    if self.gameplay_cap is not None and self.gameplay_cap.isOpened():
                        try:
                            gp_ret, gp_frame = self.gameplay_cap.read()
                            if not gp_ret or gp_frame is None or gp_frame.size == 0:
                                self.gameplay_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                                gp_ret, gp_frame = self.gameplay_cap.read()

                            if gp_ret and gp_frame is not None and gp_frame.size > 0:
                                g_h, g_w = gp_frame.shape[:2]
                                if g_h > 0 and g_w > 0:
                                    g_target_ar = float(target_w) / float(bottom_h)
                                    if (g_w / float(g_h)) > g_target_ar:
                                        g_cw = max(1, min(g_w, int(g_h * g_target_ar)))
                                        g_ch = g_h
                                        gx1 = max(0, min(g_w - g_cw, (g_w - g_cw) // 2))
                                        gy1 = 0
                                    else:
                                        g_cw = g_w
                                        g_ch = max(1, min(g_h, int(g_w / g_target_ar)))
                                        gx1 = 0
                                        y_offset_pct = max(0.0, min(1.0, float(self.e_gp_y_slider.value()) / 100.0 if hasattr(self, 'e_gp_y_slider') else 0.50))
                                        avail_y = max(0, g_h - g_ch)
                                        gy1 = max(0, min(avail_y, int(avail_y * y_offset_pct)))

                                    gp_crop = gp_frame[gy1 : gy1 + g_ch, gx1 : gx1 + g_cw]
                                    if gp_crop.size > 0 and gp_crop.shape[0] > 0 and gp_crop.shape[1] > 0:
                                        bottom_resized = cv2.resize(gp_crop, (target_w, bottom_h), interpolation=cv2.INTER_LINEAR)
                        except Exception:
                            bottom_resized = None

                    # Safe dark gradient fallback matte
                    if bottom_resized is None or bottom_resized.size == 0 or bottom_resized.shape[:2] != (bottom_h, target_w):
                        bottom_resized = np.zeros((bottom_h, target_w, 3), dtype=np.uint8)
                        for r in range(bottom_h):
                            prog = r / float(max(1, bottom_h))
                            bottom_resized[r, :] = (int(28 + 14 * prog), int(20 + 10 * prog), int(36 + 20 * prog))
                        cv2.putText(bottom_resized, "🎮 SPLIT GAMEPLAY OVERLAY", (max(10, target_w // 2 - 160), max(20, bottom_h // 2)),
                                    cv2.FONT_HERSHEY_DUPLEX, 0.65, (100, 116, 139), 1, cv2.LINE_AA)

                    # Explicit dimensions & types validation
                    if top_resized.shape[1] != target_w or top_resized.shape[0] != top_h:
                        top_resized = cv2.resize(top_resized, (target_w, top_h), interpolation=cv2.INTER_LINEAR)
                    if bottom_resized.shape[1] != target_w or bottom_resized.shape[0] != bottom_h:
                        bottom_resized = cv2.resize(bottom_resized, (target_w, bottom_h), interpolation=cv2.INTER_LINEAR)

                    # --- EXACT SPLIT BLEND IMPLEMENTATION ---
                    blend_h = 160
                    if top_h > blend_h and bottom_h > blend_h:
                        # Build a smooth Cosine S-curve gradient (1.0 at top down to 0.0 at bottom)
                        t = np.linspace(0.0, np.pi, blend_h, dtype=np.float32)
                        alpha = (0.5 * (1.0 + np.cos(t))).reshape(blend_h, 1, 1)

                        # Blend the bottom slice of top pane with the top slice of bottom pane
                        top_slice = top_resized[top_h - blend_h : top_h].astype(np.float32)
                        bottom_slice = bottom_resized[0 : blend_h].astype(np.float32)
                        feathered_zone = (top_slice * alpha + bottom_slice * (1.0 - alpha)).astype(np.uint8)

                        # Assemble the final composite frame
                        composite_frame = np.vstack((
                            top_resized[0 : top_h - blend_h],
                            feathered_zone,
                            bottom_resized[blend_h : bottom_h]
                        ))
                        if composite_frame.shape[0] != 1920:
                            composite_frame = cv2.resize(composite_frame, (target_w, 1920), interpolation=cv2.INTER_LINEAR)
                    else:
                        composite_frame = np.vstack((top_resized, bottom_resized))

                    cropped = composite_frame
                except Exception as gp_err:
                    if hasattr(self, 'e_console_log'):
                        self.e_console_log.appendPlainText(f"[Gameplay Live Warning] {gp_err}")

            # 3. Live Subtitle Overlay (Word-by-Word 1-3 Words Fast-Paced)
            if hasattr(self, 'e_caps_chk') and self.e_caps_chk.isChecked() and self.player_segments:
                try:
                    curr_sec = (self.player_start_frame + self.player_current_frame) / self.player_fps
                    preset = self.e_cap_style_combo.currentText() if hasattr(self, 'e_cap_style_combo') else "Hormozi Classic Pop"
                    
                    # Find active word chunk
                    chunk_words = []
                    active_word_idx = -1
                    
                    for seg in self.player_segments:
                        seg_st = float(seg.get("start", 0))
                        seg_et = float(seg.get("end", 0))
                        if seg_st <= curr_sec <= seg_et:
                            seg_words = seg.get("words", [])
                            if seg_words:
                                w_list = []
                                target_w_idx = 0
                                for wi, w in enumerate(seg_words):
                                    w_txt = w.get("word", "") if isinstance(w, dict) else getattr(w, "word", "")
                                    w_st = float(w.get("start", 0) if isinstance(w, dict) else getattr(w, "start", 0))
                                    w_et = float(w.get("end", 0) if isinstance(w, dict) else getattr(w, "end", 0))
                                    w_list.append(w_txt.strip())
                                    if w_st <= curr_sec <= w_et or (w_st <= curr_sec and wi == len(seg_words) - 1):
                                        target_w_idx = wi
                                
                                chunk_start = (target_w_idx // 2) * 2
                                chunk_words = w_list[chunk_start : chunk_start + 2]
                                active_word_idx = target_w_idx - chunk_start
                            else:
                                raw_words = seg.get("text", "").strip().split()
                                if raw_words:
                                    dur = max(0.2, seg_et - seg_st)
                                    prog = max(0.0, min(1.0, (curr_sec - seg_st) / dur))
                                    target_w_idx = min(len(raw_words) - 1, int(prog * len(raw_words)))
                                    chunk_start = (target_w_idx // 2) * 2
                                    chunk_words = raw_words[chunk_start : chunk_start + 2]
                                    active_word_idx = target_w_idx - chunk_start
                            break
                    
                    if chunk_words:
                        c_h, c_w = cropped.shape[:2]
                        
                        # Dynamic User Font Scale & Y-Placement
                        user_sz = float(self.e_cap_size_slider.value()) if hasattr(self, 'e_cap_size_slider') else 18.0
                        font_scale = max(0.35, (c_w / 620.0) * (user_sz / 18.0))
                        thickness = max(1, int(font_scale * 2.2))
                        
                        y_pct = float(self.e_cap_y_slider.value()) if hasattr(self, 'e_cap_y_slider') else 78.0
                        base_y = int(c_h * (y_pct / 100.0))
                        
                        p_low = preset.lower()
                        # Select font family per preset
                        if "matrix" in p_low:
                            font = cv2.FONT_HERSHEY_PLAIN
                            font_scale = font_scale * 1.5
                            thickness = max(1, int(font_scale * 1.6))
                        elif any(k in p_low for k in ("luxury", "serif", "cinematic", "velvet")):
                            font = cv2.FONT_HERSHEY_COMPLEX
                        else:
                            font = cv2.FONT_HERSHEY_DUPLEX
                        
                        # Format casing according to preset
                        if any(k in p_low for k in ("minimal", "ali", "smooth mint", "velvet", "serif", "cinematic")):
                            clean_chunk = [w.capitalize() if i == 0 else w.lower() for i, w in enumerate(chunk_words)]
                        else:
                            clean_chunk = [w.upper() for w in chunk_words]
                        
                        full_text = " ".join(clean_chunk)
                        sz_total = cv2.getTextSize(full_text, font, font_scale, thickness)[0]
                        base_x = max(10, (c_w - sz_total[0]) // 2)

                        # Render background container pills / boxes
                        if "yellow box" in p_low or "high-contrast" in p_low:
                            pad_x, pad_y = int(14 * font_scale), int(10 * font_scale)
                            x1 = max(0, base_x - pad_x)
                            y1 = max(0, base_y - sz_total[1] - pad_y)
                            x2 = min(c_w, base_x + sz_total[0] + pad_x)
                            y2 = min(c_h, base_y + pad_y)
                            cv2.rectangle(cropped, (x1, y1), (x2, y2), (0, 230, 255), -1) # Solid Neon Yellow Box
                        elif any(k in p_low for k in ("capcut", "ali", "pill", "box", "glow", "iman", "blackout", "gray pill")):
                            pad_x, pad_y = int(14 * font_scale), int(10 * font_scale)
                            x1 = max(0, base_x - pad_x)
                            y1 = max(0, base_y - sz_total[1] - pad_y)
                            x2 = min(c_w, base_x + sz_total[0] + pad_x)
                            y2 = min(c_h, base_y + pad_y)
                            
                            overlay = cropped.copy()
                            if "iman" in p_low or "blackout" in p_low:
                                bg_col = (10, 10, 10)
                                alpha = 0.85
                            elif "gray pill" in p_low or "minimal gray" in p_low:
                                bg_col = (45, 35, 30)
                                alpha = 0.75
                            elif "capcut" in p_low:
                                bg_col = (24, 18, 18)
                                alpha = 0.75
                            else:
                                bg_col = (15, 15, 15)
                                alpha = 0.65
                            cv2.rectangle(overlay, (x1, y1), (x2, y2), bg_col, -1)
                            cv2.addWeighted(overlay, alpha, cropped, 1.0 - alpha, 0, cropped)
                            cv2.rectangle(cropped, (x1, y1), (x2, y2), (60, 60, 75), 1)

                        # Word by word rendering with highlight
                        cur_x = base_x
                        for wi, word in enumerate(clean_chunk):
                            w_sz = cv2.getTextSize(word, font, font_scale, thickness)[0]
                            is_active = (wi == active_word_idx)
                            shadow_offset = 2
                            
                            # 1. Hormozi Classic Pop: Pure White with Vibrant Yellow Highlight
                            if "hormozi" in p_low or "viral" in p_low:
                                text_col = (0, 230, 255) if is_active else (255, 255, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 4
                            # 2. CapCut Neon Cyan Glow: White with Neon Cyan Highlight
                            elif "capcut" in p_low or "cyan" in p_low:
                                text_col = (255, 255, 0) if is_active else (255, 255, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 3
                            # 3. MrBeast Coral Punch: Yellow with Crimson Coral Highlight
                            elif "beast" in p_low or "coral" in p_low:
                                text_col = (48, 59, 255) if is_active else (0, 230, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 5
                            # 4. Ali Abdaal Clean Minimalist: Crisp Off-White with Slate Accent
                            elif "ali" in p_low or "abdaal" in p_low:
                                text_col = (192, 174, 160) if is_active else (250, 250, 250)
                                stroke_col = (25, 25, 25)
                                stroke_w = thickness + 1
                            # 5. Matrix Cyber Lime: White with High-Voltage Lime Green Highlight
                            elif "matrix" in p_low or "lime" in p_low:
                                text_col = (57, 255, 20) if is_active else (255, 255, 255)
                                stroke_col = (0, 35, 0)
                                stroke_w = thickness + 3
                            # 6. Luxury Velvet Gold: Soft Cream with Metallic Gold Highlight
                            elif "luxury" in p_low or "gold" in p_low or "velvet" in p_low:
                                text_col = (123, 192, 229) if is_active else (240, 240, 240)
                                stroke_col = (26, 36, 48)
                                stroke_w = thickness + 2
                            # 7. Bilingual Dual-Tone Purple: Soft White with Neon Violet Highlight
                            elif "bilingual" in p_low or "purple" in p_low or "dual" in p_low:
                                text_col = (239, 70, 217) if is_active else (255, 255, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 4
                            # 8. Tech Dark Amber (MKBHD): Ice Gray with Cyber Amber Highlight
                            elif "tech" in p_low or "amber" in p_low or "mkbhd" in p_low:
                                text_col = (0, 153, 255) if is_active else (240, 232, 226)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 3
                            # 9. Cinematic Clean Serif: Pure White with subtle cinematic contrast
                            elif "cinematic" in p_low or "serif" in p_low:
                                text_col = (255, 255, 255) if is_active else (224, 224, 224)
                                stroke_col = (20, 20, 20)
                                stroke_w = thickness + 1
                            # 10. Retro Neon 80s Synth: Electric Pink with Sky Blue Highlight
                            elif "retro" in p_low or "80s" in p_low or "synth" in p_low:
                                text_col = (56, 169, 224) if is_active else (239, 70, 217)
                                stroke_col = (64, 16, 16)
                                stroke_w = thickness + 3
                            # 11. Iman Gadzhi Luxury Blackout: Pure White with Emerald Green Highlight
                            elif "iman" in p_low or "gadzhi" in p_low or "blackout" in p_low:
                                text_col = (120, 200, 80) if is_active else (255, 255, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 2
                            # 12. Fast-Paced TikTok Flame: Blazing Orange with Pure Yellow Highlight
                            elif "flame" in p_low or "tiktok flame" in p_low:
                                text_col = (0, 255, 255) if is_active else (0, 102, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 4
                            # 13. Podcast Studio Sleek: Pure White with Sky Blue Accent
                            elif "podcast" in p_low or "sleek" in p_low:
                                text_col = (113, 113, 248) if is_active else (255, 255, 255)
                                stroke_col = (59, 41, 30)
                                stroke_w = thickness + 2
                            # 14. Comic Pop Red Outline: Pure White with Yellow Highlight & Punchy Red Stroke
                            elif "comic" in p_low or "pop red" in p_low:
                                text_col = (0, 255, 255) if is_active else (255, 255, 255)
                                stroke_col = (0, 0, 255)
                                stroke_w = thickness + 4
                            # 15. Midnight Shadow White: Pure White with Heavy Drop Shadow
                            elif "midnight" in p_low or "shadow" in p_low:
                                text_col = (255, 255, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = 0
                                shadow_offset = 6
                            # 16. Minimal Gray Pill: Pure White text in dark charcoal container
                            elif "gray pill" in p_low or "minimal gray" in p_low:
                                text_col = (255, 255, 255) if is_active else (240, 240, 240)
                                stroke_col = (20, 20, 20)
                                stroke_w = thickness + 1
                            # 17. Neon Vaporwave Lavender: Pastel Cyan with Soft Lavender Highlight
                            elif "vaporwave" in p_low or "lavender" in p_low:
                                text_col = (175, 184, 230) if is_active else (160, 240, 255)
                                stroke_col = (75, 21, 74)
                                stroke_w = thickness + 3
                            # 18. Bold Athletic Red: White with Ferrari Red Highlight
                            elif "athletic" in p_low or "bold athletic" in p_low:
                                text_col = (0, 0, 255) if is_active else (255, 255, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 4
                            # 19. Smooth Mint Minimal: Pure White with Fresh Mint Green Highlight
                            elif "mint" in p_low or "smooth mint" in p_low:
                                text_col = (208, 243, 167) if is_active else (255, 255, 255)
                                stroke_col = (30, 30, 30)
                                stroke_w = thickness + 1
                            # 20. High-Contrast Neon Yellow Box: Pure Black text on Yellow Box
                            elif "yellow box" in p_low or "high-contrast" in p_low:
                                text_col = (0, 0, 0)
                                stroke_col = (0, 0, 0)
                                stroke_w = 0
                            # Fallback Default
                            else:
                                text_col = (0, 230, 255) if is_active else (255, 255, 255)
                                stroke_col = (0, 0, 0)
                                stroke_w = thickness + 3
                            
                            # Drop shadow
                            if shadow_offset > 0:
                                cv2.putText(cropped, word, (cur_x + shadow_offset, base_y + shadow_offset), font, font_scale, (0, 0, 0), max(1, stroke_w), cv2.LINE_AA)
                            # Outer stroke
                            if stroke_w > 0:
                                cv2.putText(cropped, word, (cur_x, base_y), font, font_scale, stroke_col, stroke_w, cv2.LINE_AA)
                            # Primary text fill
                            cv2.putText(cropped, word, (cur_x, base_y), font, font_scale, text_col, thickness, cv2.LINE_AA)
                            
                            space_sz = cv2.getTextSize(" ", font, font_scale, thickness)[0][0]
                            cur_x += w_sz[0] + space_sz
                except Exception as sub_err:
                    if hasattr(self, 'e_console_log'):
                        self.e_console_log.appendPlainText(f"[Subtitle Live Warning] {sub_err}")

            # 4. Dynamic Canvas Viewport Scaling matching selected Aspect Ratio
            canvas_sz = self.e_video_canvas.size()
            canvas_w = max(60, canvas_sz.width() - 8)
            canvas_h = max(60, canvas_sz.height() - 8)
            c_h, c_w = cropped.shape[:2]

            if c_h > 0 and c_w > 0:
                aspect_text = self.e_aspect_combo.currentText() if hasattr(self, 'e_aspect_combo') else "9:16 (Portrait)"
                ar_crop = float(c_w) / float(c_h)
                ar_canvas = float(canvas_w) / float(canvas_h)

                if not is_gp_active and ("16:9" in aspect_text or "Landscape" in aspect_text or "21:9" in aspect_text or "4:3" in aspect_text):
                    # 16:9 Landscape / Widescreen: Dynamically maximize and fill the entire canvas container cleanly
                    if ar_crop > ar_canvas:
                        disp_w = canvas_w
                        disp_h = max(2, int(canvas_w / ar_crop))
                    else:
                        disp_h = canvas_h
                        disp_w = max(2, int(canvas_h * ar_crop))
                elif not is_gp_active and ("1:1" in aspect_text or "Square" in aspect_text):
                    # 1:1 Square framing centered in container
                    side = min(canvas_w, canvas_h)
                    disp_w = side
                    disp_h = side
                elif not is_gp_active and "4:5" in aspect_text:
                    # 4:5 Vertical Portrait
                    target_disp_w = int(canvas_h * (4.0 / 5.0))
                    disp_w = min(canvas_w, target_disp_w)
                    disp_h = max(2, int(disp_w / (4.0 / 5.0)))
                else:
                    # 9:16 Portrait vertical framing (or Gameplay Split 9:16)
                    target_disp_w = int(canvas_h * (9.0 / 16.0))
                    disp_w = min(canvas_w, target_disp_w)
                    disp_h = max(2, int(disp_w / (9.0 / 16.0)))

                preview_small = cv2.resize(cropped, (disp_w, disp_h), interpolation=cv2.INTER_LINEAR)
            else:
                preview_small = cropped

            rgb = cv2.cvtColor(preview_small, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb.shape
            bytes_per_line = ch * w
            q_img = QImage(rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
            pix = QPixmap.fromImage(q_img)
            self.e_video_canvas.setPixmap(pix)
        except Exception as frame_err:
            if hasattr(self, 'e_console_log'):
                self.e_console_log.appendPlainText(f"[Player Frame Error] {frame_err}")

    def _on_player_tick(self):
        try:
            if self.player_cap is None or not self.player_cap.isOpened():
                return

            needs_seek = False
            # Hardware Audio-Clock Frame Catch-Up (Drop-Frame Sync)
            if self.player_is_playing and hasattr(self, 'media_player') and self.media_player and self.media_player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
                audio_msec = self.media_player.position()
                target_abs_frame = int((audio_msec / 1000.0) * self.player_fps)
                target_clip_frame = target_abs_frame - self.player_start_frame

                if target_clip_frame >= self.player_total_clip_frames:
                    self.player_current_frame = 0
                    self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.player_start_frame)
                    start_ms = int((self.player_start_frame / self.player_fps) * 1000)
                    self.media_player.setPosition(start_ms)
                    self.media_player.play()
                    needs_seek = True
                elif target_clip_frame < 0:
                    self.player_current_frame = 0
                    self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.player_start_frame)
                    needs_seek = True
                else:
                    self.player_current_frame = target_clip_frame
                    curr_cap_frame = self.player_cap.get(cv2.CAP_PROP_POS_FRAMES)
                    # Resync only if video falls behind audio clock by > 4 frames
                    if abs(target_abs_frame - curr_cap_frame) > 4:
                        self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, target_abs_frame)
                        needs_seek = True
            else:
                self.player_current_frame += 1
                if self.player_current_frame >= self.player_total_clip_frames:
                    self.player_current_frame = 0
                    self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.player_start_frame)
                    needs_seek = True

            self._render_current_player_frame(seek=needs_seek)
            self.e_time_slider.blockSignals(True)
            self.e_time_slider.setValue(self.player_current_frame)
            self.e_time_slider.blockSignals(False)
            self._update_player_time_label()
        except Exception as tick_err:
            pass

    def _update_player_time_label(self):
        cur_sec = self.player_current_frame / self.player_fps if self.player_fps > 0 else 0
        tot_sec = self.player_total_clip_frames / self.player_fps if self.player_fps > 0 else 0
        cur_str = f"{int(cur_sec // 60):02d}:{int(cur_sec % 60):02d}"
        tot_str = f"{int(tot_sec // 60):02d}:{int(tot_sec % 60):02d}"
        self.e_time_lbl.setText(f"{cur_str} / {tot_str}")

    def action_player_toggle_play(self):
        if self.player_is_playing:
            self.player_timer.stop()
            self.player_is_playing = False
            self.media_player.pause()
            self.e_play_btn.setText("▶ Play")
            self.e_play_btn.setProperty("class", "primaryButton")
        else:
            if self.player_cap is None or not self.player_cap.isOpened():
                idx = self.e_clip_combo.currentIndex()
                if idx >= 0:
                    self._on_player_clip_changed(idx)
            if self.player_cap is not None and self.player_cap.isOpened():
                cur_pos_sec = (self.player_start_frame + self.player_current_frame) / self.player_fps
                self.media_player.setPosition(int(cur_pos_sec * 1000))
                self.media_player.play()
                interval = max(15, int(1000.0 / self.player_fps))
                self.player_timer.start(interval)
                self.player_is_playing = True
                self.e_play_btn.setText("⏸ Pause")
                self.e_play_btn.setProperty("class", "secondaryButton")

    def action_player_seek(self, value: int):
        if self.player_cap is not None and self.player_cap.isOpened():
            self.player_current_frame = max(0, min(value, self.player_total_clip_frames))
            target_f = self.player_start_frame + self.player_current_frame
            self.player_cap.set(cv2.CAP_PROP_POS_FRAMES, target_f)
            target_ms = int((target_f / self.player_fps) * 1000)
            self.media_player.setPosition(target_ms)
            self._render_current_player_frame(seek=True)
            self._update_player_time_label()

    def action_player_skip(self, seconds: float):
        if self.player_cap is not None and self.player_cap.isOpened():
            frames_to_skip = int(seconds * self.player_fps)
            new_f = max(0, min(self.player_current_frame + frames_to_skip, self.player_total_clip_frames - 1))
            self.action_player_seek(new_f)
            self.e_time_slider.setValue(new_f)

    def action_player_toggle_mute(self):
        muted = self.audio_output.isMuted()
        self.audio_output.setMuted(not muted)
        self.e_mute_btn.setText("🔇" if not muted else "🔊")

    # ═════════════════════════════════════════════════════════════════════════
    # TAB 4: FINAL VIDEO REVIEW PLAYER ENGINE WITH SYNCHRONIZED AUDIO
    # ═════════════════════════════════════════════════════════════════════════

    def _init_export_player(self):
        self.ex_player_cap = None
        self.ex_player_is_playing = False
        self.ex_player_current_frame = 0
        self.ex_player_total_frames = 0
        self.ex_player_fps = 30.0
        self.current_export_video_path = ""
        self.ex_player_timer = QTimer()
        self.ex_player_timer.timeout.connect(self._on_ex_player_tick)

        # Native QMediaPlayer for synchronized export review audio
        self.ex_media_player = QMediaPlayer()
        self.ex_audio_output = QAudioOutput()
        self.ex_media_player.setAudioOutput(self.ex_audio_output)
        self.ex_audio_output.setVolume(1.0)
        self.ex_media_player.setLoops(1)
        self.ex_media_player.mediaStatusChanged.connect(self._on_export_media_status_changed)

    def _on_export_media_status_changed(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self.ex_player_timer.stop()
            self.ex_player_is_playing = False
            self.ex_media_player.pause()
            self.ex_media_player.setPosition(0)
            self.ex_player_current_frame = 0
            if self.ex_player_cap is not None and self.ex_player_cap.isOpened():
                self.ex_player_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            self.ex_play_btn.setText("▶ Play")
            self.ex_play_btn.setProperty("class", "primaryButton")
            self.ex_time_slider.blockSignals(True)
            self.ex_time_slider.setValue(0)
            self.ex_time_slider.blockSignals(False)
            self._render_current_export_frame()
            self._update_ex_player_time_label()

    def _load_export_player(self, video_path: str, auto_play: bool = True):
        if not video_path or not Path(video_path).exists():
            return
        self.current_export_video_path = str(video_path)
        if self.ex_player_cap is not None:
            self.ex_player_cap.release()

        self.ex_player_cap = cv2.VideoCapture(self.current_export_video_path)
        if not self.ex_player_cap.isOpened():
            return

        fps = self.ex_player_cap.get(cv2.CAP_PROP_FPS)
        self.ex_player_fps = fps if fps and fps > 5.0 else 30.0
        self.ex_player_total_frames = max(1, int(self.ex_player_cap.get(cv2.CAP_PROP_FRAME_COUNT)))
        self.ex_player_current_frame = 0

        self.ex_time_slider.blockSignals(True)
        self.ex_time_slider.setRange(0, self.ex_player_total_frames)
        self.ex_time_slider.setValue(0)
        self.ex_time_slider.blockSignals(False)

        # Load audio source
        self.ex_media_player.setSource(QUrl.fromLocalFile(self.current_export_video_path))
        self.ex_media_player.setPosition(0)

        self._render_current_export_frame()
        self._update_ex_player_time_label()

        if auto_play:
            interval = max(15, int(1000.0 / self.ex_player_fps))
            self.ex_media_player.play()
            self.ex_player_timer.start(interval)
            self.ex_player_is_playing = True
            self.ex_play_btn.setText("⏸ Pause")
            self.ex_play_btn.setProperty("class", "secondaryButton")

    def _render_current_export_frame(self, seek: bool = False):
        if not hasattr(self, 'ex_player_cap') or self.ex_player_cap is None or not self.ex_player_cap.isOpened():
            return
        if seek:
            self.ex_player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.ex_player_current_frame)
        ret, frame = self.ex_player_cap.read()
        if not ret or frame is None:
            self.ex_player_current_frame = 0
            self.ex_player_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ret, frame = self.ex_player_cap.read()
            if not ret or frame is None:
                return

        canvas_sz = self.ex_video_canvas.size()
        target_h = max(100, canvas_sz.height() - 4)
        target_w = max(100, canvas_sz.width() - 4)
        f_h, f_w = frame.shape[:2]
        if f_h > 0 and f_w > 0:
            ar_frame = float(f_w) / float(f_h)
            ar_canvas = float(target_w) / float(target_h)
            if ar_frame > ar_canvas:
                disp_w = target_w
                disp_h = max(2, int(target_w / ar_frame))
            else:
                disp_h = target_h
                disp_w = max(2, int(target_h * ar_frame))
            disp_frame = cv2.resize(frame, (disp_w, disp_h), interpolation=cv2.INTER_LINEAR)
        else:
            disp_frame = frame

        rgb = cv2.cvtColor(disp_frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        q_img = QImage(rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pix = QPixmap.fromImage(q_img)
        self.ex_video_canvas.setPixmap(pix)

    def _on_ex_player_tick(self):
        if self.ex_player_cap is None or not self.ex_player_cap.isOpened():
            return

        if not self.ex_player_is_playing:
            return

        self.ex_player_current_frame += 1
        if self.ex_player_current_frame >= self.ex_player_total_frames:
            self.ex_player_timer.stop()
            self.ex_player_is_playing = False
            self.ex_player_current_frame = 0
            if self.ex_player_cap is not None and self.ex_player_cap.isOpened():
                self.ex_player_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            if hasattr(self, 'ex_media_player') and self.ex_media_player:
                self.ex_media_player.pause()
                self.ex_media_player.setPosition(0)
            self.ex_play_btn.setText("▶ Play")
            self.ex_play_btn.setProperty("class", "primaryButton")
            self.ex_time_slider.blockSignals(True)
            self.ex_time_slider.setValue(0)
            self.ex_time_slider.blockSignals(False)
            self._render_current_export_frame(seek=True)
            self._update_ex_player_time_label()
            return

        # Smooth audio sync drift correction
        if hasattr(self, 'ex_media_player') and self.ex_media_player and self.ex_media_player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            audio_sec = self.ex_media_player.position() / 1000.0
            video_sec = self.ex_player_current_frame / self.ex_player_fps
            drift = audio_sec - video_sec
            if abs(drift) > 0.4:
                self.ex_media_player.setPosition(int(video_sec * 1000.0))

        self._render_current_export_frame(seek=False)
        if not self.ex_time_slider.isSliderDown():
            self.ex_time_slider.blockSignals(True)
            self.ex_time_slider.setValue(self.ex_player_current_frame)
            self.ex_time_slider.blockSignals(False)
        self._update_ex_player_time_label()

    def _update_ex_player_time_label(self):
        cur_sec = self.ex_player_current_frame / self.ex_player_fps if self.ex_player_fps > 0 else 0
        tot_sec = self.ex_player_total_frames / self.ex_player_fps if self.ex_player_fps > 0 else 0
        cur_str = f"{int(cur_sec // 60):02d}:{int(cur_sec % 60):02d}"
        tot_str = f"{int(tot_sec // 60):02d}:{int(tot_sec % 60):02d}"
        self.ex_time_lbl.setText(f"{cur_str} / {tot_str}")

    def action_ex_player_toggle_play(self):
        if self.ex_player_is_playing:
            self.ex_player_timer.stop()
            self.ex_player_is_playing = False
            if hasattr(self, 'ex_media_player') and self.ex_media_player:
                self.ex_media_player.pause()
            self.ex_play_btn.setText("▶ Play")
            self.ex_play_btn.setProperty("class", "primaryButton")
        else:
            if not hasattr(self, 'ex_player_cap') or self.ex_player_cap is None or not self.ex_player_cap.isOpened():
                # Auto-find latest exported file or rendered clip
                export_dir = Path(WORK_DIR) / "exports"
                exports = sorted(export_dir.glob("*.mp4"), key=os.path.getmtime, reverse=True) if export_dir.exists() else []
                if exports:
                    self._load_export_player(str(exports[0]), auto_play=True)
                    return
                editor_dir = Path(WORK_DIR) / "editor"
                edited_clips = sorted(editor_dir.glob("clip_*/edited.mp4"), key=os.path.getmtime, reverse=True) if editor_dir.exists() else []
                if edited_clips:
                    self._load_export_player(str(edited_clips[0]), auto_play=True)
                    return
                return

            if self.ex_player_cap is not None and self.ex_player_cap.isOpened():
                interval = max(15, int(1000.0 / self.ex_player_fps))
                target_ms = int((self.ex_player_current_frame / self.ex_player_fps) * 1000)
                if hasattr(self, 'ex_media_player') and self.ex_media_player:
                    self.ex_media_player.setPosition(target_ms)
                    self.ex_media_player.play()
                self.ex_player_timer.start(interval)
                self.ex_player_is_playing = True
                self.ex_play_btn.setText("⏸ Pause")
                self.ex_play_btn.setProperty("class", "secondaryButton")

    def action_ex_player_seek(self, value: int):
        if self.ex_player_cap is not None and self.ex_player_cap.isOpened():
            self.ex_player_current_frame = max(0, min(value, self.ex_player_total_frames))
            self.ex_player_cap.set(cv2.CAP_PROP_POS_FRAMES, self.ex_player_current_frame)
            target_ms = int((self.ex_player_current_frame / self.ex_player_fps) * 1000)
            if hasattr(self, 'ex_media_player') and self.ex_media_player:
                self.ex_media_player.setPosition(target_ms)
            self._render_current_export_frame(seek=True)
            self._update_ex_player_time_label()

    def action_ex_player_skip(self, seconds: float):
        if self.ex_player_cap is not None and self.ex_player_cap.isOpened():
            frames_to_skip = int(seconds * self.ex_player_fps)
            new_f = max(0, min(self.ex_player_current_frame + frames_to_skip, self.ex_player_total_frames - 1))
            self.action_ex_player_seek(new_f)
            self.ex_time_slider.setValue(new_f)

    def action_ex_player_toggle_mute(self):
        muted = self.ex_audio_output.isMuted()
        self.ex_audio_output.setMuted(not muted)
        self.ex_mute_btn.setText("🔇" if not muted else "🔊")

    # ═════════════════════════════════════════════════════════════════════════
    # TAB 5: IN-APP OTA AUTO-UPDATER ENGINE
    # ═════════════════════════════════════════════════════════════════════════

    def action_check_updates(self):
        self.upd_check_btn.setEnabled(False)
        self.upd_status_lbl.setText("🔍 Checking for software updates...")
        self.upd_thread = CheckUpdateThread()
        self.upd_thread.sig_result.connect(self._on_update_check_result)
        self.upd_thread.sig_error.connect(self._on_update_check_error)
        self.upd_thread.start()

    def _on_update_check_result(self, res: dict):
        self.upd_check_btn.setEnabled(True)
        if res.get("update_available"):
            self.latest_update_info = res
            self.upd_status_lbl.setText(f"✨ Update available: v{res.get('latest_version')}")
            self.upd_badge_lbl.setText(f"✨ New Update Available: v{res.get('latest_version')}")
            self.upd_changelog_lbl.setText(f"Release Notes:\n{res.get('changelog', 'Bug fixes and performance improvements.')}")
            self.upd_container.setVisible(True)
        else:
            self.upd_status_lbl.setText(f"✅ {res.get('message', 'You have the latest version installed.')}")
            self.upd_container.setVisible(False)

    def _on_update_check_error(self, err: str):
        self.upd_check_btn.setEnabled(True)
        self.upd_status_lbl.setText(f"⚠️ Update check note: {err}")

    def action_start_update(self):
        if not hasattr(self, 'latest_update_info') or not self.latest_update_info.get("download_url"):
            self.upd_status_lbl.setText("⚠️ No update download URL configured.")
            return
        url = self.latest_update_info["download_url"]
        self.upd_apply_btn.setEnabled(False)
        self.upd_progress_bar.setVisible(True)
        self.upd_progress_bar.setValue(0)
        self.upd_status_lbl.setText("⬇️ Downloading update patch...")

        self.upd_dl_thread = DownloadUpdateThread(url)
        self.upd_dl_thread.sig_progress.connect(lambda p: self.upd_progress_bar.setValue(p))
        self.upd_dl_thread.sig_finished.connect(self._on_update_download_finished)
        self.upd_dl_thread.sig_error.connect(self._on_update_download_error)
        self.upd_dl_thread.start()

    def _on_update_download_finished(self, patch_file: str):
        self.upd_status_lbl.setText("🔄 Applying update and restarting NS Clipper...")
        updater.apply_patch_and_restart(patch_file)
        QApplication.quit()

    def _on_update_download_error(self, err: str):
        self.upd_apply_btn.setEnabled(True)
        self.upd_status_lbl.setText(f"❌ Update download failed: {err}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN EXECUTION ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("NS Clipper")
    app.setStyle("Fusion")
    
    icon_path = str(get_resource_path("launcher_icon.ico"))
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))

    window = NSClipperMainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
