"""
transcribe_groq.py — Groq API Transcription (Cloud, Free Tier)
===============================================================
Uses Groq's free API with whisper-large-v3-turbo at ~189x real-time speed.
A 14-minute video transcribes in ~4 seconds.

FREE TIER LIMITS (as of 2025):
  - 7,200 seconds of audio per hour
  - Files up to 25 MB (we auto-split larger files)
  - Rate limit: 20 requests/min

SETUP (one-time):
  1. Go to https://console.groq.com
  2. Sign up free (no credit card needed)
  3. Create an API key
  4. Paste it in the app's API Key box OR set env var GROQ_API_KEY

MODELS available on Groq:
  - whisper-large-v3-turbo  (default, fastest, great quality)
  - whisper-large-v3        (slower, highest quality)
  - distil-whisper-large-v3-en  (English-only, fastest)
"""

import os
import sys
import math
import subprocess
import json
from pathlib import Path
from typing import Optional

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

from transcribe import (
    TranscriptResult, Segment, WordToken,
    get_video_duration, extract_audio, fmt_time
)

GROQ_MAX_FILE_MB = 24       # API limit is 25 MB; keep margin
GROQ_CHUNK_SEC   = 600      # 10-minute chunks for large files


def _get_file_mb(path: str) -> float:
    return Path(path).stat().st_size / 1024 / 1024


def _split_audio(wav_path: str, work_dir: str, chunk_sec: int = GROQ_CHUNK_SEC) -> list[str]:
    """Split a WAV into chunks using FFmpeg. Returns list of chunk paths."""
    chunks = []
    duration = get_video_duration(wav_path)
    n_chunks = math.ceil(duration / chunk_sec)

    for i in range(n_chunks):
        start = i * chunk_sec
        out = Path(work_dir) / f"chunk_{i:03d}.wav"
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(start),
            "-i", wav_path,
            "-t", str(chunk_sec),
            "-acodec", "pcm_s16le",
            "-ar", "16000", "-ac", "1",
            str(out),
        ]
        subprocess.run(cmd, capture_output=True, creationflags=CREATE_NO_WINDOW)
        if out.exists() and out.stat().st_size > 1000:
            chunks.append(str(out))
    return chunks


def transcribe_video_groq(
    video_path: str,
    work_dir: str,
    api_key: str,
    model: str = "whisper-large-v3-turbo",
    language: Optional[str] = None,
    progress_cb=None,
) -> TranscriptResult:
    """
    Transcribe a video using the Groq API.
    Returns a TranscriptResult identical to the local Whisper output,
    so all downstream milestones work unchanged.
    """
    from groq import Groq
    import config as cfg

    def log(msg):
        print(msg)
        if progress_cb:
            progress_cb(msg)

    clean_key = cfg.sanitize_key(api_key)
    if not clean_key:
        raise ValueError("Invalid or empty Groq API Key.")
    client = Groq(api_key=clean_key)
    os.makedirs(work_dir, exist_ok=True)

    # 1. Duration
    log("[1/4] Probing video duration...")
    duration = get_video_duration(video_path)
    log(f"   Duration: {duration:.1f}s ({duration/60:.1f} min)")

    # 2. Extract audio
    log("[2/4] Extracting audio (16 kHz mono WAV)...")
    wav_path = extract_audio(video_path, work_dir)
    file_mb  = _get_file_mb(wav_path)
    log(f"   Audio size: {file_mb:.1f} MB")

    # 3. Split if > 24 MB
    if file_mb > GROQ_MAX_FILE_MB:
        log(f"   File > {GROQ_MAX_FILE_MB} MB — splitting into 10-min chunks...")
        chunks = _split_audio(wav_path, work_dir)
        log(f"   Split into {len(chunks)} chunks")
    else:
        chunks = [wav_path]

    # 4. Transcribe each chunk via Groq API
    log(f"[3/4] Sending to Groq API (model: {model})...")
    all_segments: list[Segment] = []
    seg_id   = 0
    time_offset = 0.0

    for ci, chunk_path in enumerate(chunks):
        if len(chunks) > 1:
            log(f"   Chunk {ci+1}/{len(chunks)} ({_get_file_mb(chunk_path):.1f} MB)...")

        with open(chunk_path, "rb") as f:
            response = client.audio.transcriptions.create(
                file=(Path(chunk_path).name, f, "audio/wav"),
                model=model,
                language=language,
                response_format="verbose_json",
                timestamp_granularities=["word", "segment"],
            )

        # Parse response — Groq returns same format as OpenAI Whisper API
        raw = response if not hasattr(response, "model_dump") else response.model_dump()
        if hasattr(raw, "__dict__"):
            raw = vars(raw)

        groq_segs = raw.get("segments", []) if isinstance(raw, dict) else []
        groq_words = raw.get("words", []) if isinstance(raw, dict) else []

        # Build word lookup by time for this chunk
        word_map: dict[tuple, WordToken] = {}
        for w in groq_words:
            key = (round(w.get("start", 0) + time_offset, 3),)
            word_map[key] = WordToken(
                word=w.get("word", ""),
                start=round(w.get("start", 0) + time_offset, 3),
                end=round(w.get("end", 0) + time_offset, 3),
                probability=round(w.get("probability", 1.0), 4),
            )

        for gs in groq_segs:
            seg_start = round(gs.get("start", 0) + time_offset, 3)
            seg_end   = round(gs.get("end", 0) + time_offset, 3)

            # Assign words to this segment
            seg_words = [
                wt for wt in word_map.values()
                if wt.start >= seg_start and wt.end <= seg_end + 0.1
            ]
            seg_words.sort(key=lambda x: x.start)

            all_segments.append(Segment(
                id=seg_id,
                start=seg_start,
                end=seg_end,
                text=gs.get("text", "").strip(),
                words=seg_words,
            ))
            seg_id += 1

        # If no segments (some models return flat words only)
        if not groq_segs and groq_words:
            chunk_text = " ".join(w.get("word","") for w in groq_words)
            all_segments.append(Segment(
                id=seg_id,
                start=time_offset,
                end=time_offset + _get_file_mb(chunk_path) * 8,
                text=chunk_text,
                words=list(word_map.values()),
            ))
            seg_id += 1

        chunk_dur = get_video_duration(chunk_path)
        time_offset += chunk_dur

    # Detect language from first chunk response
    detected_lang = "unknown"
    if isinstance(raw, dict):
        detected_lang = raw.get("language", "unknown")

    result = TranscriptResult(
        language=detected_lang,
        language_probability=1.0,
        duration=duration,
        segments=all_segments,
        audio_path=wav_path,
    )

    # 5. Save JSON
    log("[4/4] Saving transcript...")
    json_path = str(Path(work_dir) / "transcript.json")
    result.save_json(json_path)
    log(f"DONE! Language: {detected_lang} | {len(all_segments)} segments")
    log(f"Transcript saved -> {json_path}")

    return result
