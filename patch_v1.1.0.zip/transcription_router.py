"""
transcription_router.py — Unified transcription entry point
============================================================
Routes to Gemini Flash, Deepgram, Groq (cloud), or local Whisper based on model name.
Includes automatic fallback chains and cross-provider failover.
"""

import time
import json
import urllib.request
import urllib.parse
from pathlib import Path
import config as cfg
from viral_scorer_cloud import KeyRotator

_MAP = {
    # Gemini models
    "Gemini 2.5 Flash (Fastest ⚡)":                     ("gemini",   "gemini-2.5-flash"),
    "Gemini 2.0 Flash (Recommended)":                   ("gemini",   "gemini-2.0-flash"),
    "Gemini 1.5 Flash (Stable)":                        ("gemini",   "gemini-1.5-flash"),
    # Deepgram cloud models
    "Deepgram Nova-3 (Latest Flagship - Recommended)":   ("deepgram", "nova-3"),
    "Deepgram Nova-2 (Standard Batch)":                  ("deepgram", "nova-2"),
    # Groq cloud Whisper
    "Whisper Large V3 Turbo":                            ("groq",     "whisper-large-v3-turbo"),
    "Whisper Large V3":                                  ("groq",     "whisper-large-v3"),
    # Local Whisper (offline)
    "Whisper Medium (Offline)":                          ("local",    "medium"),
    "Whisper Small (Offline)":                           ("local",    "small"),
    "Whisper Tiny (Offline)":                            ("local",    "tiny"),
}

# Fallback chain when a Gemini model returns 503 / overloaded
_GEMINI_FALLBACK_CHAIN = [
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-flash",
    "gemini-1.5-flash-8b",
    "gemini-1.5-pro",
]

# Flat list for dropdowns — Gemini & Deepgram first
ALL_MODELS = list(_MAP.keys())


def _try_gemini_transcribe(video_path, language, api_model, api_key=None, log=None):
    """Try one Gemini model. Returns segments list or raises exception."""
    from gemini_service import transcribe_with_timing
    import gemini_service as _gs
    orig = _gs.GEMINI_MODEL
    try:
        _gs.GEMINI_MODEL = api_model
        return transcribe_with_timing(video_path, language, log=log, api_key=api_key)
    finally:
        _gs.GEMINI_MODEL = orig


def _try_deepgram_transcribe(video_path: str, session_dir: str, api_model: str = "nova-3", language: str = None, log=None):
    """Transcribe audio/video with Deepgram Nova API with detect_language/smart_format."""
    from transcribe import (
        TranscriptResult, Segment, WordToken,
        get_video_duration, extract_audio
    )

    dg_keys = cfg.get_deepgram_keys()
    if not dg_keys:
        raise ValueError("No Deepgram API key configured in Settings.")

    def _log(m):
        if log:
            try: log(str(m))
            except Exception: pass

    _log(f"[Deepgram] Extracting audio for {api_model}...")
    work_path = Path(session_dir) if session_dir else Path(video_path).parent
    work_path.mkdir(parents=True, exist_ok=True)
    wav_path = extract_audio(video_path, str(work_path))
    duration = get_video_duration(wav_path)

    params = {
        "model": api_model,
        "smart_format": "true",
        "punctuate": "true",
        "utterances": "true",
    }
    if language and language.strip().lower() not in ("auto", "auto detect", "none"):
        params["language"] = language.strip().lower()
    else:
        params["detect_language"] = "true"

    qs = urllib.parse.urlencode(params)
    url = f"https://api.deepgram.com/v1/listen?{qs}"

    rotator = KeyRotator(dg_keys)

    def _do_post(key):
        with open(wav_path, "rb") as f:
            audio_data = f.read()
        req = urllib.request.Request(
            url,
            data=audio_data,
            headers={
                "Authorization": f"Token {key}",
                "Content-Type": "audio/wav"
            },
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read().decode("utf-8"))

    _log(f"[Deepgram] Transcribing with Deepgram {api_model} (Language: {language or 'Auto Detect'})...")
    data = rotator.try_call(_do_post)

    results = data.get("results", {})
    channels = results.get("channels", [{}])
    detected_lang = channels[0].get("detected_language", language or "en") if channels else (language or "en")

    utterances = results.get("utterances", [])
    segs = []
    if utterances:
        for i, u in enumerate(utterances):
            words = [
                WordToken(
                    word=str(w.get("punctuated_word") or w.get("word", "")),
                    start=round(float(w.get("start", 0.0)), 3),
                    end=round(float(w.get("end", 0.0)), 3),
                    probability=round(float(w.get("confidence", 1.0)), 4)
                )
                for w in u.get("words", [])
            ]
            segs.append(Segment(
                id=i,
                start=round(float(u.get("start", 0.0)), 3),
                end=round(float(u.get("end", 0.0)), 3),
                text=str(u.get("transcript", "")).strip(),
                words=words
            ))
    else:
        alts = channels[0].get("alternatives", [{}])[0] if channels else {}
        words_raw = alts.get("words", [])
        if words_raw:
            curr_words = []
            curr_start = 0.0
            seg_id = 0
            for w in words_raw:
                wt = WordToken(
                    word=str(w.get("punctuated_word") or w.get("word", "")),
                    start=round(float(w.get("start", 0.0)), 3),
                    end=round(float(w.get("end", 0.0)), 3),
                    probability=round(float(w.get("confidence", 1.0)), 4)
                )
                curr_words.append(wt)
                if wt.end - curr_start >= 6.0 or any(p in wt.word for p in (".", "?", "!")):
                    seg_text = " ".join(x.word for x in curr_words)
                    segs.append(Segment(id=seg_id, start=curr_start, end=wt.end, text=seg_text, words=curr_words))
                    seg_id += 1
                    curr_words = []
                    curr_start = wt.end
            if curr_words:
                seg_text = " ".join(x.word for x in curr_words)
                segs.append(Segment(id=seg_id, start=curr_start, end=curr_words[-1].end, text=seg_text, words=curr_words))

    dur = segs[-1].end if segs else duration
    res = TranscriptResult(
        language=detected_lang,
        language_probability=1.0,
        duration=dur,
        segments=segs,
        audio_path=wav_path
    )
    if session_dir:
        s_path = Path(session_dir)
        s_path.mkdir(parents=True, exist_ok=True)
        res.save_json(str(s_path / "transcript.json"))
        res.save_srt(str(s_path / "transcript.srt"))
        res.save_txt(str(s_path / "transcript.txt"))
    _log(f"[Deepgram] [OK] Transcription complete: {len(segs)} segments ({dur:.1f}s)")
    return res


def auto_transcribe(video_path: str, session_dir: str,
                    model_name: str = "Gemini 3.5 Flash (Fastest ⚡)",
                    language: str = None, log=None):
    """Transcribe video, return TranscriptResult."""
    def _log(m):
        if log:
            try:
                log(str(m))
            except Exception:
                try:
                    log(str(m).encode('ascii', 'replace').decode('ascii'))
                except Exception:
                    pass

    backend, api_model = _MAP.get(model_name, ("gemini", "gemini-3.5-flash"))

    groq_keys = cfg.get_groq_keys()
    gem_keys = cfg.get_gemini_keys()
    dg_keys = cfg.get_deepgram_keys()

    # Smart Auto-Routing based on available keys
    if backend == "deepgram" and not dg_keys:
        if gem_keys:
            _log("[Info] No Deepgram key found -> Auto-routing to Gemini Flash ⚡...")
            backend, api_model = "gemini", "gemini-3.5-flash"
        elif groq_keys:
            _log("[Info] No Deepgram key found -> Auto-routing to Groq Whisper Turbo ⚡...")
            backend, api_model = "groq", "whisper-large-v3-turbo"
    elif backend == "groq" and not groq_keys:
        if gem_keys:
            _log("[Info] No Groq key found, but Gemini API key is active -> Auto-routing to Gemini Flash ⚡...")
            backend, api_model = "gemini", "gemini-3.5-flash"
        elif dg_keys:
            _log("[Info] No Groq key found -> Auto-routing to Deepgram Nova-3 ⚡...")
            backend, api_model = "deepgram", "nova-3"
    elif backend == "gemini" and not gem_keys:
        if dg_keys:
            _log("[Info] No Gemini key found -> Auto-routing to Deepgram Nova-3 ⚡...")
            backend, api_model = "deepgram", "nova-3"
        elif groq_keys:
            _log("[Info] No Gemini key found, but Groq API key is active -> Auto-routing to Groq Whisper Turbo ⚡...")
            backend, api_model = "groq", "whisper-large-v3-turbo"

    # ── Deepgram ───────────────────────────────────────────────────────────
    if backend == "deepgram":
        if dg_keys:
            try:
                return _try_deepgram_transcribe(video_path, session_dir, api_model, language, log=_log)
            except Exception as dge:
                _log(f"[Deepgram] [ERROR] {dge} -> Falling back to Gemini / Groq...")
                if gem_keys:
                    backend, api_model = "gemini", "gemini-2.5-flash"
                elif groq_keys:
                    backend, api_model = "groq", "whisper-large-v3-turbo"
                else:
                    backend, api_model = "local", "medium"
        else:
            backend = "gemini" if gem_keys else ("groq" if groq_keys else "local")

    # ── Gemini 2.5 Flash ───────────────────────────────────────────────────
    if backend == "gemini":
        keys = cfg.get_gemini_keys()
        if not keys:
            _log("[warn] No Gemini key configured -> Checking Groq / local Whisper...")
            backend = "groq"
        else:
            from transcribe import TranscriptResult, Segment, WordToken

            models_to_try = [api_model] + [
                m for m in _GEMINI_FALLBACK_CHAIN if m != api_model
            ]

            segments_raw = None
            for k_idx, gem_k in enumerate(keys):
                gem_k = str(gem_k).strip().replace("\r", "").replace("\n", "").replace('"', '').replace("'", "")
                if not gem_k:
                    continue
                for attempt_model in models_to_try:
                    try:
                        _log(f"[Gemini] Transcribing with {attempt_model} (Key {k_idx + 1}/{len(keys)})...")
                        segments_raw = _try_gemini_transcribe(
                            video_path, language, attempt_model, api_key=gem_k, log=log
                        )
                        _log(f"[Gemini] [OK] Success with {attempt_model}")
                        break
                    except Exception as e:
                        err_str = str(e)
                        if "503" in err_str or "overload" in err_str.lower() or "UNAVAILABLE" in err_str:
                            _log(f"[Gemini] [WARN] {attempt_model} overloaded (503) -> trying fallback model...")
                            time.sleep(1)
                            continue
                        elif "quota" in err_str.lower() or "429" in err_str:
                            _log(f"[Gemini] [WARN] {attempt_model} quota reached -> trying next key/model...")
                            continue
                        else:
                            _log(f"[Gemini] [ERROR] {attempt_model} error: {e}")
                            if any(x in err_str.lower() for x in ["api_key", "invalid", "401", "ssl", "certificate", "time"]):
                                _log("💡 Note: If your API key is correct, please ensure your Windows System Date & Time is perfectly synchronized with internet time (Click 'Sync Now' in Windows settings) to prevent Google/Groq SSL server certificate rejection.")
                            break
                if segments_raw is not None:
                    break

            if segments_raw is None:
                _log("[Gemini] Cloud transcription unavailable -> Checking Groq...")
                backend = "groq"
            else:
                segs = []
                for i, s in enumerate(segments_raw):
                    words = [
                        WordToken(w.get("word",""), float(w.get("start",0)), float(w.get("end",0)))
                        for w in s.get("words", [])
                    ]
                    segs.append(Segment(
                        id=i,
                        start=float(s.get("start", 0)),
                        end=float(s.get("end", 0)),
                        text=str(s.get("text", "")),
                        words=words,
                    ))
                dur = segs[-1].end if segs else 0.0
                res = TranscriptResult(
                    language=language or "auto",
                    language_probability=1.0,
                    duration=dur,
                    segments=segs,
                )
                if session_dir:
                    s_path = Path(session_dir)
                    s_path.mkdir(parents=True, exist_ok=True)
                    res.save_json(str(s_path / "transcript.json"))
                    res.save_srt(str(s_path / "transcript.srt"))
                    res.save_txt(str(s_path / "transcript.txt"))
                return res

    # ── Groq cloud Whisper ─────────────────────────────────────────────────
    if backend == "groq":
        keys = cfg.get_groq_keys()
        if not keys:
            if gem_keys and backend != "gemini":
                _log("[Info] Switching to Gemini Flash...")
                backend = "gemini"
                api_model = "gemini-2.5-flash"
            else:
                _log("[warn] No Cloud API keys found -> Falling back to offline CPU Whisper (takes several minutes)...")
                backend, api_model = "local", "medium"
        else:
            groq_model = "whisper-large-v3-turbo"
            from transcribe_groq import transcribe_video_groq
            groq_success = False
            for k_idx, groq_k in enumerate(keys):
                groq_k = str(groq_k).strip().replace("\r", "").replace("\n", "").replace('"', '').replace("'", "")
                if not groq_k:
                    continue
                try:
                    _log(f"[Groq] Transcribing with {groq_model} via Groq Cloud (Key {k_idx + 1}/{len(keys)})...")
                    res = transcribe_video_groq(video_path, session_dir,
                                                groq_k, groq_model, language, log)
                    groq_success = True
                    return res
                except Exception as e:
                    err_msg = str(e)
                    _log(f"[Groq] [ERROR] Key {k_idx + 1} Failed: {err_msg}")
                    if k_idx < len(keys) - 1:
                        _log(f"[Groq] Rotating to next failover Key {k_idx + 2}...")
                        time.sleep(0.5)
                        continue
                    if any(x in err_msg.lower() for x in ["api_key", "invalid", "401", "ssl", "certificate", "time"]):
                        _log("💡 Note: If your API key is correct, please ensure your Windows System Date & Time is perfectly synchronized with internet time (Click 'Sync Now' in Windows settings) to prevent Google/Groq SSL server certificate rejection.")

            if not groq_success:
                if gem_keys:
                    _log("[Info] Falling back to Gemini Flash...")
                    try:
                        return auto_transcribe(video_path, session_dir, "Gemini 2.5 Flash (Fastest ⚡)", language, log)
                    except Exception:
                        pass
                backend, api_model = "local", "medium"

    # ── Local Whisper (offline fallback) ──────────────────────────────────
    _log(f"[Local] Using offline CPU Whisper ({api_model})...")
    from transcribe import transcribe_video
    return transcribe_video(video_path, session_dir, api_model, language, log)
