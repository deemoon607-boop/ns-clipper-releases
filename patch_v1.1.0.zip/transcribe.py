"""
transcribe.py — Milestone 2
============================
Handles audio extraction from video and transcription via faster-whisper.
Produces word-level timestamps used by every later milestone (captions, B-roll, etc.)
"""

import os
import sys
import re
import json
import subprocess
import tempfile
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# ── Dynamic Runtime Path & Resource Resolver ─────────────────────────────────
def get_resource_path(relative_path: str) -> Path:
    """Finds resource relative_path across PyInstaller _MEIPASS, _internal, exe dir, or source dir."""
    if hasattr(sys, '_MEIPASS'):
        p = Path(sys._MEIPASS) / relative_path
        if p.exists():
            return p
    if getattr(sys, 'frozen', False):
        exe_dir = Path(sys.executable).parent
        p = exe_dir / "_internal" / relative_path
        if p.exists():
            return p
        p = exe_dir / relative_path
        if p.exists():
            return p
    p = Path(__file__).resolve().parent / relative_path
    return p


def get_ffmpeg_exe() -> str:
    """Returns absolute path to bundled ffmpeg.exe or 'ffmpeg'."""
    candidates = [
        get_resource_path("bin/ffmpeg.exe"),
        get_resource_path("ffmpeg.exe"),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return "ffmpeg"


def get_ffprobe_exe() -> str:
    """Returns absolute path to bundled ffprobe.exe or 'ffprobe'."""
    candidates = [
        get_resource_path("bin/ffprobe.exe"),
        get_resource_path("ffprobe.exe"),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return "ffprobe"


# Forcefully inject internal bundle directories to the top of PATH environment
extra_paths = []
if hasattr(sys, '_MEIPASS'):
    extra_paths.append(str(Path(sys._MEIPASS)))
    extra_paths.append(str(Path(sys._MEIPASS) / "bin"))
if getattr(sys, 'frozen', False):
    app_exe_dir = Path(sys.executable).parent
    extra_paths.append(str(app_exe_dir / "_internal"))
    extra_paths.append(str(app_exe_dir / "_internal" / "bin"))
    extra_paths.append(str(app_exe_dir))
    extra_paths.append(str(app_exe_dir / "bin"))
script_dir = Path(__file__).resolve().parent
extra_paths.append(str(script_dir))
extra_paths.append(str(script_dir / "bin"))

curr_path = os.environ.get("PATH", "")
for ep in extra_paths:
    if os.path.exists(ep) and ep not in curr_path:
        curr_path = ep + os.pathsep + curr_path
os.environ["PATH"] = curr_path


def format_professional_captions(text: str) -> str:
    """
    Format caption text using sentence-case capitalization:
    - Rule 1: Capitalize the very first word of any caption line or segment.
    - Rule 2: Capitalize the first letter of any word immediately following punctuation (.!?).
    """
    if not text:
        return ""
    
    # Trim whitespaces
    text = text.strip()
    
    # Rule 1: Capitalize the very first letter of the entire string
    text = text[0].upper() + text[1:] if len(text) > 1 else text.upper()
    
    # Rule 2: Capitalize the first letter after a dot, question mark, or exclamation followed by spaces
    text = re.sub(r'([.!?]\s+)([a-z])', lambda match: match.group(1) + match.group(2).upper(), text)
    
    return text

# ──────────────────────────────────────────────────────────────────────────────
# Data structures
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class WordToken:
    word: str
    start: float
    end: float
    probability: float

@dataclass
class Segment:
    id: int
    start: float
    end: float
    text: str
    words: list[WordToken] = field(default_factory=list)

@dataclass
class TranscriptResult:
    language: str
    language_probability: float
    duration: float          # total video duration in seconds
    segments: list[Segment] = field(default_factory=list)
    audio_path: str = ""     # path to extracted WAV

    def full_text(self) -> str:
        return " ".join(s.text.strip() for s in self.segments)

    def to_dict(self) -> dict:
        return asdict(self)

    def save_json(self, path: str):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)

    def to_srt(self) -> str:
        """Convert segments to SRT subtitle format with professional sentence-case formatting."""
        def _ts(sec: float) -> str:
            h  = int(sec // 3600)
            m  = int((sec % 3600) // 60)
            s  = int(sec % 60)
            ms = int(round((sec - int(sec)) * 1000))
            return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
        lines = []
        for i, seg in enumerate(self.segments, 1):
            text = format_professional_captions(seg.text.strip())
            if not text:
                continue
            lines.append(str(i))
            lines.append(f"{_ts(seg.start)} --> {_ts(seg.end)}")
            lines.append(text)
            lines.append("")
        return "\n".join(lines)

    def save_srt(self, path: str) -> str:
        """Write SRT file and return the path."""
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.to_srt())
        return path

    def save_txt(self, path: str) -> str:
        """Write plain transcript text to file and return the path."""
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.full_text())
        return path

    @classmethod
    def load_json(cls, path: str) -> "TranscriptResult":
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        segs = []
        for s in data["segments"]:
            words = [WordToken(**w) for w in s.get("words", [])]
            segs.append(Segment(s["id"], s["start"], s["end"], s["text"], words))
        return cls(
            language=data["language"],
            language_probability=data["language_probability"],
            duration=data["duration"],
            segments=segs,
            audio_path=data.get("audio_path", ""),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Audio extraction
# ──────────────────────────────────────────────────────────────────────────────

def extract_audio(video_path: str, out_dir: str) -> str:
    """
    Extract a 16 kHz mono WAV from *video_path* into *out_dir*.
    Returns the path to the WAV file.
    faster-whisper requires 16 kHz mono PCM — this handles any input format.
    """
    video_path = Path(video_path)
    wav_path   = Path(out_dir) / (video_path.stem + "_audio.wav")

    cmd = [
        get_ffmpeg_exe(), "-y", "-nostdin",
        "-i",  str(video_path),
        "-vn",                        # no video
        "-acodec", "pcm_s16le",       # 16-bit PCM
        "-ar",     "16000",           # 16 kHz (Whisper's native rate)
        "-ac",     "1",               # mono
        str(wav_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, creationflags=CREATE_NO_WINDOW)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg audio extraction failed:\n{result.stderr}")
    return str(wav_path)


def get_video_duration(video_path: str) -> float:
    """Return video duration in seconds using ffprobe."""
    cmd = [
        get_ffprobe_exe(), "-v", "quiet",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(video_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, creationflags=CREATE_NO_WINDOW)
    try:
        return float(result.stdout.strip())
    except ValueError:
        return 0.0


# ──────────────────────────────────────────────────────────────────────────────
# Transcription
# ──────────────────────────────────────────────────────────────────────────────

_model = None   # module-level singleton so we load the model only once

def get_model(model_size: str = "medium", device: str = "cuda", compute_type: str = "float16"):
    """
    Load (or return cached) WhisperModel using CTranslate2 inference engine.
    model_size   : "tiny" | "base" | "small" | "medium" | "large-v3"
    device       : "auto" | "cuda" | "cpu"
    compute_type : "default" | "float16" | "int8" | "float32"
    """
    global _model
    if _model is None:
        from faster_whisper import WhisperModel
        print(f"[Whisper] Loading '{model_size}' model with CTranslate2 engine (device={device})...")
        try:
            _model = WhisperModel(model_size, device=device, compute_type=compute_type)
        except Exception:
            try:
                _model = WhisperModel(model_size, device="cpu", compute_type="int8")
            except Exception:
                _model = WhisperModel(model_size, device="cpu", compute_type="float32")
        print("[Whisper] Model ready.")
    return _model


def transcribe_video(
    video_path: str,
    work_dir: str,
    model_size: str = "medium",
    language: Optional[str] = None,
    progress_cb=None,         # callable(message: str) for UI updates
) -> TranscriptResult:
    """
    Full pipeline: extract audio → transcribe → return TranscriptResult.

    progress_cb is called with status strings so Gradio can update a textbox
    in real time.
    """
    def log(msg):
        print(msg)
        if progress_cb:
            progress_cb(msg)

    os.makedirs(work_dir, exist_ok=True)

    # 1. Get duration
    log("[1/4] Probing video duration...")
    duration = get_video_duration(video_path)
    log(f"   Duration: {duration:.1f}s ({duration/60:.1f} min)")

    # 2. Extract audio
    log("[2/4] Extracting audio (16 kHz mono WAV)...")
    wav_path = extract_audio(video_path, work_dir)
    log(f"   Audio saved to: {wav_path}")

    # 3. Load model
    log(f"Loading Whisper '{model_size}' model via CTranslate2...")
    model = get_model(model_size=model_size, device="auto", compute_type="default")

    # 4. Transcribe
    log("[4/4] Transcribing... (this may take 1-5 min for a long video)")
    segments_gen, info = model.transcribe(
        wav_path,
        language=language,
        word_timestamps=True,       # critical for captions & B-roll
        vad_filter=True,            # skip silent sections automatically
        vad_parameters={"min_silence_duration_ms": 300},
        beam_size=1,                # greedy = 3-4x faster, near-identical quality
        best_of=1,
        condition_on_previous_text=False,  # faster, avoids compounding errors
    )

    # 5. Collect segments (generator must be consumed)
    segments = []
    for i, seg in enumerate(segments_gen):
        words = []
        if seg.words:
            for w in seg.words:
                words.append(WordToken(
                    word=w.word,
                    start=round(w.start, 3),
                    end=round(w.end, 3),
                    probability=round(w.probability, 4),
                ))
        segments.append(Segment(
            id=i,
            start=round(seg.start, 3),
            end=round(seg.end, 3),
            text=seg.text,
            words=words,
        ))
        # Live progress every 10 segments
        if (i + 1) % 10 == 0:
            log(f"   … processed {i+1} segments (up to {seg.end:.0f}s)")

    result = TranscriptResult(
        language=info.language,
        language_probability=round(info.language_probability, 4),
        duration=duration,
        segments=segments,
        audio_path=wav_path,
    )

    # 6. Save JSON (reused by later milestones)
    json_path = str(Path(work_dir) / "transcript.json")
    result.save_json(json_path)
    log(f"[Transcript saved -> {json_path}]")
    log(f"DONE! Detected language: {info.language} ({info.language_probability:.0%} confidence)")
    log(f"   {len(segments)} segments | {sum(len(s.words) for s in segments)} words")

    return result


# ──────────────────────────────────────────────────────────────────────────────
# Formatting helpers
# ──────────────────────────────────────────────────────────────────────────────

def fmt_time(seconds: float) -> str:
    """Format seconds as HH:MM:SS.mmm"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:06.3f}"


def transcript_to_display(result: TranscriptResult) -> str:
    """Render a human-readable transcript with timestamps for the Gradio textbox."""
    lines = []
    lines.append(f"Language: {result.language}  ({result.language_probability:.0%} confidence)")
    lines.append(f"Duration: {fmt_time(result.duration)}")
    lines.append(f"Segments: {len(result.segments)}   Words: {sum(len(s.words) for s in result.segments)}")
    lines.append("─" * 60)
    for seg in result.segments:
        ts = f"[{fmt_time(seg.start)} → {fmt_time(seg.end)}]"
        lines.append(f"{ts}  {seg.text.strip()}")
    return "\n".join(lines)
