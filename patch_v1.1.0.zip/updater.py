"""
updater.py — In-App Over-The-Air (OTA) Auto-Updater Engine
===========================================================
Enables lightweight patch updates (<10-30MB) without requiring
users to re-download the full 1.5GB application installer.
"""

import os
import sys
import json
import time
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from typing import Optional, Callable, Dict, Any

import httpx
import requests
import config as cfg

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def _parse_version(v_str: str) -> tuple:
    """Convert version string '1.2.3' to tuple (1, 2, 3) for safe comparison."""
    clean = v_str.strip().lstrip("vV")
    parts = []
    for p in clean.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def check_for_updates(current_version: str = None, manifest_url: str = None) -> Dict[str, Any]:
    """
    Query the remote manifest to check for software updates.
    Appends dynamic timestamp parameter & no-cache headers to bypass CDN/GitHub caching.
    Returns dictionary with update info and changelog.
    """
    curr_v = current_version or cfg.APP_VERSION
    url = manifest_url or getattr(cfg, "UPDATE_MANIFEST_URL", "")

    result = {
        "update_available": False,
        "current_version": curr_v,
        "latest_version": curr_v,
        "changelog": "",
        "download_url": "",
        "mandatory": False,
        "message": "You are on the latest version."
    }

    if not url:
        return result

    # Append a dynamic microsecond/second timestamp parameter to bust raw.githubusercontent cache
    sep = "&" if "?" in url else "?"
    cache_buster_url = f"{url}{sep}t={int(time.time() * 1000)}"

    headers = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
    }

    try:
        data = None
        status_code = 0
        try:
            with httpx.Client(timeout=10.0, follow_redirects=True, headers=headers) as client:
                resp = client.get(cache_buster_url)
                status_code = resp.status_code
                if status_code == 200:
                    data = resp.json()
        except Exception:
            # Fallback to requests if httpx encounters an issue
            resp = requests.get(cache_buster_url, timeout=10, headers=headers)
            status_code = resp.status_code
            if status_code == 200:
                data = resp.json()

        if status_code == 200 and isinstance(data, dict):
            latest_v = data.get("version") or data.get("latest_version") or curr_v
            result["latest_version"] = str(latest_v)
            result["changelog"] = data.get("changelog") or data.get("release_notes") or "No release notes provided."
            result["download_url"] = data.get("download_url", "")
            result["mandatory"] = data.get("mandatory", False)

            if _parse_version(str(latest_v)) > _parse_version(str(curr_v)):
                result["update_available"] = True
                result["message"] = f"New version v{latest_v} available!"
            else:
                result["message"] = "You have the latest version installed."
        else:
            result["message"] = f"Update server returned status {status_code}."
    except Exception as e:
        result["message"] = f"Could not check for updates: {e}"

    return result


def download_patch(
    download_url: str,
    dest_dir: str = None,
    progress_cb: Optional[Callable[[int, int], None]] = None
) -> str:
    """
    Download update patch zip with chunked progress reporting.
    Returns path to downloaded patch file.
    """
    if not dest_dir:
        dest_dir = tempfile.gettempdir()
    os.makedirs(dest_dir, exist_ok=True)
    out_file = os.path.join(dest_dir, "ns_clipper_patch.zip")

    try:
        with httpx.Client(timeout=120.0, follow_redirects=True) as client:
            with client.stream("GET", download_url) as resp:
                resp.raise_for_status()
                total_size = int(resp.headers.get("content-length", 0))
                downloaded = 0

                with open(out_file, "wb") as f:
                    for chunk in resp.iter_bytes(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if progress_cb and total_size > 0:
                                percent = int((downloaded / total_size) * 100)
                                progress_cb(min(100, percent), downloaded)
    except Exception:
        import requests
        with requests.get(download_url, stream=True, timeout=120, allow_redirects=True) as resp:
            resp.raise_for_status()
            total_size = int(resp.headers.get("content-length", 0))
            downloaded = 0
            with open(out_file, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if progress_cb and total_size > 0:
                            percent = int((downloaded / total_size) * 100)
                            progress_cb(min(100, percent), downloaded)

    return out_file


def apply_patch_and_restart(patch_zip_path: str, target_dir: str = None):
    """
    Generate and launch a standalone detached batch updater that:
    1. Waits for current app process to exit
    2. Unzips patch contents into target app directory
    3. Relaunches NS Clipper and cleans up patch files
    """
    if not target_dir:
        if getattr(sys, "frozen", False):
            target_dir = str(Path(sys.executable).parent)
            main_exe = sys.executable
        else:
            target_dir = str(Path(__file__).parent)
            main_exe = sys.executable  # python executable

    patch_path = os.path.abspath(patch_zip_path)
    target_path = os.path.abspath(target_dir)
    app_pid = os.getpid()

    # Create detached updater script in temp folder
    temp_dir = tempfile.gettempdir()
    bat_path = os.path.join(temp_dir, "ns_clipper_update_runner.bat")
    
    script_content = f"""@echo off
title NS Clipper OTA Updater
echo [NS Clipper Updater] Waiting for current process ({app_pid}) to close...
taskkill /PID {app_pid} /F >nul 2>&1
timeout /t 2 /nobreak >nul

:waitloop
tasklist /FI "PID eq {app_pid}" 2>nul | find "{app_pid}" >nul
if %ERRORLEVEL% equ 0 (
    timeout /t 1 /nobreak >nul
    goto waitloop
)

echo [NS Clipper Updater] Applying patch to: {target_path}
powershell -NoProfile -Command "$ErrorActionPreference = 'Stop'; for ($i = 0; $i -lt 15; $i++) {{ try {{ Expand-Archive -Path '{patch_path}' -DestinationPath '{target_path}' -Force; Write-Host 'Patch extracted successfully!'; break }} catch {{ Start-Sleep -Milliseconds 600 }} }}"

echo [NS Clipper Updater] Cleaning temporary patch files...
del /F /Q "{patch_path}" >nul 2>&1

echo [NS Clipper Updater] Launching updated NS Clipper...
"""
    if getattr(sys, "frozen", False):
        script_content += f"""start "" "{main_exe}"\n"""
    else:
        script_content += f"""start "" "{sys.executable}" "{os.path.join(target_path, 'main_desktop.py')}"\n"""

    script_content += """exit\n"""

    with open(bat_path, "w", encoding="utf-8") as f:
        f.write(script_content)

    # Launch detached process and exit python
    subprocess.Popen(
        ["cmd.exe", "/c", bat_path],
        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
        close_fds=True
    )
